from qgis.PyQt import QtWidgets, QtCore
import os
import tempfile

from qgis.PyQt.QtGui import QIcon


class SettingsDialog(QtWidgets.QDialog):
    """Settings dialog for KASUGAI Canvas integration configuration"""

    def __init__(self, parent=None):
        super(SettingsDialog, self).__init__(parent)
        self.setWindowTitle(QtCore.QCoreApplication.translate('geo_webview', "Settings"))
        self.setMinimumWidth(600)
        try:
            icon_path = os.path.join(os.path.dirname(__file__), 'icon', 'setting.png')
            if os.path.exists(icon_path):
                self.setWindowIcon(QIcon(icon_path))
        except Exception:  # nosec B110  # 設計上の許容
            pass

        # Initialize QSettings for persistent storage
        self.settings = QtCore.QSettings('GeoWebView', 'geo_webview')

        # Main layout
        layout = QtWidgets.QVBoxLayout()

        # Title
        title = QtWidgets.QLabel(QtCore.QCoreApplication.translate('geo_webview', "KASUGAI Canvas"))
        title.setStyleSheet("font-weight: bold; font-size: 12pt;")
        layout.addWidget(title)

        # KASUGAI Canvas install location (serverless export target)
        kasugai_group = QtWidgets.QGroupBox(QtCore.QCoreApplication.translate('geo_webview', "KASUGAI Canvas Install Location"))
        kasugai_layout = QtWidgets.QVBoxLayout()

        kasugai_path_layout = QtWidgets.QHBoxLayout()
        kasugai_path_label = QtWidgets.QLabel(QtCore.QCoreApplication.translate('geo_webview', "Install Path:"))
        self.kasugai_install_input = QtWidgets.QLineEdit()
        self.kasugai_install_input.setReadOnly(True)
        kasugai_path_layout.addWidget(kasugai_path_label)
        kasugai_path_layout.addWidget(self.kasugai_install_input)
        kasugai_layout.addLayout(kasugai_path_layout)

        kasugai_button_layout = QtWidgets.QHBoxLayout()
        btn_kasugai_browse = QtWidgets.QPushButton(QtCore.QCoreApplication.translate('geo_webview', "Browse..."))
        btn_kasugai_browse.clicked.connect(self._browse_kasugai_install)
        kasugai_button_layout.addWidget(btn_kasugai_browse)

        btn_kasugai_clear = QtWidgets.QPushButton(QtCore.QCoreApplication.translate('geo_webview', "Clear"))
        btn_kasugai_clear.setToolTip(QtCore.QCoreApplication.translate('geo_webview', "Export to the standalone output directory instead"))
        btn_kasugai_clear.clicked.connect(self._clear_kasugai_install)
        kasugai_button_layout.addWidget(btn_kasugai_clear)
        kasugai_button_layout.addStretch()
        kasugai_layout.addLayout(kasugai_button_layout)

        kasugai_info = QtWidgets.QLabel(
            QtCore.QCoreApplication.translate('geo_webview',
                                              "When set, KASUGAI export writes .kasc+canvas_data/ into "
                                              "<install>/QGIS_projects/<project>/ (kept separate from Canvas's own projects/) "
                                              "and registers it via the local API.")
        )
        kasugai_info.setWordWrap(True)
        kasugai_info.setStyleSheet("color: #666;")
        kasugai_layout.addWidget(kasugai_info)

        kasugai_group.setLayout(kasugai_layout)
        layout.addWidget(kasugai_group)

        # Hosted engine channel (kasugai-canvas-web)
        hosted_group = QtWidgets.QGroupBox(QtCore.QCoreApplication.translate('geo_webview', "Hosted Engine (kasugai-canvas-web)"))
        hosted_layout = QtWidgets.QVBoxLayout()
        hosted_row = QtWidgets.QHBoxLayout()
        hosted_label = QtWidgets.QLabel(QtCore.QCoreApplication.translate('geo_webview', "Channel:"))
        self.kasugai_hosted_combo = QtWidgets.QComboBox()
        self.kasugai_hosted_combo.setEditable(True)
        self.kasugai_hosted_combo.addItems(['stable', 'unstable'])
        self.kasugai_hosted_combo.setToolTip(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "Engine channel used when KASUGAI Canvas is not installed. "
                "'stable'/'unstable' or a custom base URL ending with '/'."))
        self.kasugai_hosted_combo.currentTextChanged.connect(
            self._hosted_channel_changed)
        hosted_row.addWidget(hosted_label)
        hosted_row.addWidget(self.kasugai_hosted_combo)
        hosted_layout.addLayout(hosted_row)
        hosted_info = QtWidgets.QLabel(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "Fallback when KASUGAI Canvas is not installed: the hosted "
                "engine reads .kasc+canvas_data/ served by this plugin's HTTP server."))
        hosted_info.setWordWrap(True)
        hosted_info.setStyleSheet("color: #666;")
        hosted_layout.addWidget(hosted_info)
        hosted_group.setLayout(hosted_layout)
        layout.addWidget(hosted_group)

        # Basemap group names (.kasc export)
        bm_group = QtWidgets.QGroupBox(
            QtCore.QCoreApplication.translate('geo_webview', "Basemap Groups"))
        bm_layout = QtWidgets.QVBoxLayout()
        bm_row = QtWidgets.QHBoxLayout()
        bm_label = QtWidgets.QLabel(
            QtCore.QCoreApplication.translate('geo_webview', "Additional names:"))
        self.kasugai_basemap_groups_input = QtWidgets.QLineEdit()
        self.kasugai_basemap_groups_input.setPlaceholderText(
            QtCore.QCoreApplication.translate(
                'geo_webview', "e.g. 背景, Basemaps, Base Map"))
        self.kasugai_basemap_groups_input.setToolTip(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "Comma-separated layer-tree group names treated as basemaps "
                "(in addition to the built-in 背景図 / ベースマップ / basemap)."))
        self.kasugai_basemap_groups_input.editingFinished.connect(
            self._basemap_groups_changed)
        bm_row.addWidget(bm_label)
        bm_row.addWidget(self.kasugai_basemap_groups_input)
        bm_layout.addLayout(bm_row)
        bm_info = QtWidgets.QLabel(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "XYZ tile layers inside a layer-tree group with one of these "
                "names are exported as basemap entries (base:) instead of "
                "regular layers. Sub-groups are kept for grouped display."))
        bm_info.setWordWrap(True)
        bm_info.setStyleSheet("color: #666;")
        bm_layout.addWidget(bm_info)
        bm_group.setLayout(bm_layout)
        layout.addWidget(bm_group)

        # Vector export format (.kasc)
        vf_group = QtWidgets.QGroupBox(
            QtCore.QCoreApplication.translate(
                'geo_webview', "Vector Export Format"))
        vf_layout = QtWidgets.QVBoxLayout()
        self.kasugai_vector_combo = QtWidgets.QComboBox()
        self.kasugai_vector_combo.addItem(
            QtCore.QCoreApplication.translate(
                'geo_webview', "native (reference as-is)"), 'native')
        self.kasugai_vector_combo.addItem(
            QtCore.QCoreApplication.translate(
                'geo_webview', "recommended (FlatGeobuf → canvas_data/)"),
            'recommended')
        self.kasugai_vector_combo.addItem(
            QtCore.QCoreApplication.translate(
                'geo_webview', "geojson (WEB interop → GeoJSON)"),
            'geojson')
        self.kasugai_vector_combo.setToolTip(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "Vector export format for .kasc output."))
        self.kasugai_vector_combo.currentIndexChanged.connect(
            self._vector_format_changed)
        vf_layout.addWidget(self.kasugai_vector_combo)
        vf_rules = QtWidgets.QLabel(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "<b>recommended:</b> gpkg / geojson / shp / csv / kml / "
                "wfs and other sources are converted to FlatGeobuf and "
                "written into canvas_data/ as flatgeobuf: lines (spatial index + "
                "bbox=auto range reads in Canvas). Sources already in "
                "FlatGeobuf/GeoParquet keep native references "
                "(flatgeobuf: / geoparquet: / duckdb:+format=parquet).<br>"
                "<b>native (default):</b> readable sources are "
                "referenced as-is (gpkg: / geojson: / shp: / wfs: / duckdb: "
                "lines); only non-native sources are converted. Layer "
                "filters (subset) and fields/where/limit are baked into "
                "the converted FlatGeobuf either way.<br>"
                "<b>geojson (WEB interop):</b> ALL vectors (including "
                "FlatGeobuf/GeoParquet sources) are converted to GeoJSON "
                "and written into canvas_data/ as geojson: lines, so other "
                "WebGIS and GIS tools can read canvas_data/ as-is."))
        vf_rules.setWordWrap(True)
        vf_rules.setStyleSheet("color: #666;")
        vf_layout.addWidget(vf_rules)
        # 非表示レイヤのデータ変換スキップ(パネルの同名チェックと
        # 同じ kasugai_visible_data_only を読み書き)
        self.kasugai_visible_only_check = QtWidgets.QCheckBox(
            QtCore.QCoreApplication.translate(
                'geo_webview', "Visible data only (faster)"))
        self.kasugai_visible_only_check.setToolTip(
            QtCore.QCoreApplication.translate(
                'geo_webview',
                "Only output visible layers — hidden layers are not "
                "written to the .kasc at all (basemap-group XYZ "
                "candidates keep their base: rows for the background "
                "selector, as before). Skipped layers cannot be turned "
                "on in Canvas. Uncheck to emit hidden layers as | off "
                "rows with all data converted (whole-project migration)"))
        self.kasugai_visible_only_check.toggled.connect(
            self._visible_only_toggled)
        vf_layout.addWidget(self.kasugai_visible_only_check)
        vf_group.setLayout(vf_layout)
        layout.addWidget(vf_group)

        layout.addStretch()

        # Close button
        btn_close = QtWidgets.QPushButton(QtCore.QCoreApplication.translate('geo_webview', "Close"))
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close)

        self.setLayout(layout)

        # Load saved settings
        self._load_settings()

    def showEvent(self, event):
        """Refresh settings when dialog is shown to reflect latest values"""
        super().showEvent(event)
        self._load_settings()

    def _load_settings(self):
        """Load saved settings from QSettings and display them dynamically"""
        # KASUGAI Canvas install location
        install_path = self.settings.value('kasugai_install_path', '') or ''
        install_path = str(install_path).strip()
        if install_path and install_path != '__default__' and os.path.isdir(install_path):
            self.kasugai_install_input.setText(install_path)
            self._kasugai_install_path = install_path
        else:
            # 設定未登録でもレジストリ(インストーラ登録)から検出できれば表示する
            detected = ''
            try:
                from . import kasugai_export
                detected = kasugai_export._registry_install_dir() or ''
            except Exception:  # nosec B110  # レジストリ自動検出は任意機能・失敗時は [Not set] 表示のみ
                pass
            if detected:
                self.kasugai_install_input.setText(
                    QtCore.QCoreApplication.translate('geo_webview', "[Auto-detected] {0}").format(detected))
            else:
                self.kasugai_install_input.setText(
                    QtCore.QCoreApplication.translate('geo_webview', "[Not set] export to output directory"))
            self._kasugai_install_path = ''
            if install_path and install_path != '__default__':
                self.settings.setValue('kasugai_install_path', '')

        # Hosted engine channel
        ch = str(self.settings.value('kasugai_hosted_channel', '')
                 or '').strip() or 'stable'
        self.kasugai_hosted_combo.setCurrentText(ch)

        # Additional basemap group names
        self.kasugai_basemap_groups_input.setText(
            str(self.settings.value('kasugai_basemap_groups', '') or ''))

        # Vector export format
        mode = str(self.settings.value('kasugai_vector_format', '')
                   or '').strip().lower()
        if mode not in ('native', 'recommended', 'geojson'):
            mode = 'native'
        idx = self.kasugai_vector_combo.findData(mode)
        self.kasugai_vector_combo.blockSignals(True)
        self.kasugai_vector_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.kasugai_vector_combo.blockSignals(False)

        # Visible data only (skip hidden-layer conversion)
        vdo = str(self.settings.value('kasugai_visible_data_only', '')
                  or '').strip().lower()
        checked = vdo not in ('0', 'false', 'off', 'no')
        self.kasugai_visible_only_check.blockSignals(True)
        self.kasugai_visible_only_check.setChecked(checked)
        self.kasugai_visible_only_check.blockSignals(False)

    def _vector_format_changed(self, index):
        """ベクター出力モード(native/recommended/geojson)を保存する。"""
        self.settings.setValue(
            'kasugai_vector_format',
            self.kasugai_vector_combo.itemData(index) or 'native')

    def _visible_only_toggled(self, checked):
        """非表示レイヤのデータ変換スキップ(高速化)を保存する。"""
        self.settings.setValue(
            'kasugai_visible_data_only', '1' if checked else '0')

    def _basemap_groups_changed(self):
        """追加のベースマップグループ名(カンマ区切り)を保存する。"""
        self.settings.setValue(
            'kasugai_basemap_groups',
            str(self.kasugai_basemap_groups_input.text() or '').strip())

    def _hosted_channel_changed(self, text):
        """ホスト版エンジンのチャンネル変更を保存する。"""
        self.settings.setValue(
            'kasugai_hosted_channel', str(text or '').strip() or 'stable')

    def _browse_kasugai_install(self):
        """Select KASUGAI Canvas install directory; export lands in <dir>/projects/."""
        folder = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            QtCore.QCoreApplication.translate('geo_webview', "Select KASUGAI Canvas Install Directory"),
            self._kasugai_install_path or tempfile.gettempdir()
        )
        if folder:
            self.kasugai_install_input.setText(folder)
            self._kasugai_install_path = folder
            self.settings.setValue('kasugai_install_path', folder)

    def _clear_kasugai_install(self):
        """Unset install dir: fall back to the standalone output directory."""
        self.kasugai_install_input.setText(
            QtCore.QCoreApplication.translate('geo_webview', "[Not set] export to output directory"))
        self._kasugai_install_path = ''
        self.settings.setValue('kasugai_install_path', '')
