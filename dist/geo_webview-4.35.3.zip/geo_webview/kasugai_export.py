# -*- coding: utf-8 -*-
"""KASUGAI Canvas 連携エクスポート。

QGIS プロジェクトの表示中ベクターレイヤーを GeoJSON + QGISスタイル(.qml)
として出力し、KASUGAI Canvas プロジェクト形式(.kasc + canvas_data/)を生成する。

KASUGAI Canvas は ``geojson: タイトル | canvas_data/x.geojson | on | style=canvas_data/x.qml``
形式の .kasc 行を読み、.qml の <renderer-v2> を Cesium 描画へコンパイルする。
ネイティブ参照できるソースは ``gpkg:``/``geojson:``/``geoparquet:``/
``flatgeobuf:``/``shp:``/``kml:``/``gpx:``/``topojson:``/``czml:``/
``esrijson:``/``geojsonl:``/``gml:``/``igc:``(Canvas が直接読むか
shared/vector-load.js で GeoJSON 正規化)、WFS レイヤは ``wfs:``、
CSV/TSV・フィルタ付きソースは ``duckdb:``、
3D Tiles レイヤは ``3dtiles:``、XYZ タイルは ``xyz:``/``base:`` 行になる。
直接参照できないベクターは FlatGeobuf(利用不可なら GeoParquet→GeoJSON)へ
EPSG:4326 で変換する。
ローカルサーバー版(port 8510)が起動していれば
``POST /api/projects/register {path: <kasc>}`` で外部プロジェクトとして
登録でき、そのまま ``?project=<id>`` で開ける(登録フォルダの canvas_data/ が
そのまま配信される)。``POST /api/command`` の switchProject で
起動中の画面を切り替えることもできる。
起動エンジンは ``/cesium/`` ``/maplibre/`` ``/openlayers/`` ``/leaflet/``
``/gsimaps/`` ``/navara/`` の実パスで直接指定できる(``?engine=``
リダイレクトへの
依存を避ける)。

このモジュールは PyQGIS 環境でのみ使用する(ユニットテスト不可)。
ネットワーク呼び出しは全て短いタイムアウト付きのベストエフォート。
"""

import json
import math
import os
import re
import shutil
import subprocess  # nosec B404  # kasugai_canvas.exe の連携起動用
import time
import urllib.error
import urllib.parse
import urllib.request

from .i18n_json import lang_code, translate_text

# KASUGAI Canvas ローカルサーバーの既定ポート(run.py _get_port と同じ)
DEFAULT_KASUGAI_PORT = 8510
SETTINGS_KEY_OUTPUT = 'kasugai_output_path'
SETTINGS_KEY_PORT = 'kasugai_port'

# KASUGAI Canvas の起動エンジン(web/index.html の engine パラメータと同じ)
VALID_ENGINES = ('cesium', 'maplibre', 'openlayers', 'leaflet', 'gsimaps',
                 'navara')
DEFAULT_ENGINE = 'cesium'

KASUGAI_EXE_NAME = 'kasugai_canvas.exe'
_KASUGAI_UNINSTALL_KEY = (
    r'Software\Microsoft\Windows\CurrentVersion\Uninstall\KASUGAI Canvas')

# ベースマップ候補群を表すレイヤツリーのグループ名(大小文字不問)。
# この名前のグループに入っている XYZ レイヤは base: 行として
# ベースマップ一覧へ登録する(グループ名自体はタイトルに含めず、
# 配下のサブグループは / 区切りのタイトルとして残し、
# Canvas 側のベースマップ選択でグループ化表示される)
# QSettings kasugai_basemap_groups(カンマ区切り)でユーザーが
# 追加名を登録できる(設定ダイアログの Basemap Groups)
BASEMAP_GROUP_NAMES = frozenset(
    ('背景図', 'ベースマップ', 'basemap'))
SETTINGS_KEY_BASEMAP_GROUPS = 'kasugai_basemap_groups'

# ベクターの .kasc 出力モード。'native'(既定)=gpkg/geojson 等をそのまま
# 参照、'recommended'=推奨形式(FlatGeobuf/GeoParquet)以外のベクターを
# FlatGeobuf へ変換して canvas_data/ へ配置、'geojson'=全ベクターを
# GeoJSON へ変換して canvas_data/ へ配置(WEB連携・他WebGISとの相互運用用)
# (設定ダイアログの Vector Export Format・/kasugai?fmt=・
# bridge vector_format=)
SETTINGS_KEY_VECTOR_FORMAT = 'kasugai_vector_format'
VECTOR_EXPORT_MODES = ('native', 'recommended', 'geojson')
SETTINGS_KEY_VISIBLE_DATA_ONLY = 'kasugai_visible_data_only'
# カスタムレイヤタブ(custom-layer)の有効化設定。
# ON のとき、レイヤツリーのグループをグループ名として ``site=<グループ>``
# をレイヤ行へ付け、custom-layer プラグインJSを canvas_data/ へ複製して
# ``plugin:`` 行を出力する(レイヤ customProperty ``kasugai_site`` /
# ``kasugai_order`` で個別上書き可)
SETTINGS_KEY_SITE_CONTROL = 'kasugai_site_control'

# ベクター→XYZ タイル焼き付け(高速表示モード)。大規模・複雑スタイルの
# ベクターを QGIS レンダラでタイル画像化して ``xyz:`` 行で出す
# (パネル/設定ダイアログの「XYZ tiles」チェックとズーム範囲と共有)
SETTINGS_KEY_XYZ_TILES = 'kasugai_xyz_tiles'
SETTINGS_KEY_XYZ_ZMIN = 'kasugai_xyz_zmin'
SETTINGS_KEY_XYZ_ZMAX = 'kasugai_xyz_zmax'
# ズーム範囲の既定(パネルのスピンと共有)
XYZ_TILES_ZOOM_DEFAULT = (1, 15)

# Filter タブ(QGIS WEBVIEW)の選択状態。panel.py が UI 変更のたび
# set_filter_panel_state() で同期し、plugin: 行の filter_* オプション
# として出力する(Canvas 側「フィルタ」タブの初期選択となる)
_filter_panel_state = None


def set_filter_panel_state(state):
    """Filter タブの選択状態を記録する(エクスポート時に plugin: 行へ反映)。

    ``{'site': str, 'field': str, 'multi': bool, 'op': str,
    'value': str, 'values': [str, ...]}`` または None を受ける。
    """
    global _filter_panel_state
    _filter_panel_state = dict(state) if state else None


# .kasc と同じ場所に出力するエンジン起動HTML(サーバレス配布用)。
# 各HTMLは ?kasc=<.kascの絶対URL> 付きでエンジンへ転送するだけの
# 自己完結ページ。エンジン本体(web/ の中身)は ./ ../ ../../ / の順に
# 自動探索し、見つからなければHTML内の CANVAS_BASE を編集してもらう
_LAUNCHER_ENGINES = (
    'cesium', 'maplibre', 'openlayers', 'leaflet', 'gsimaps', 'navara')

# 起動HTML内の __T_*__ トークン→英語ソースの対応表。
# i18n/<lang>.json の geo_webview.page コンテキストから
# QGISのUI言語へ翻訳して差し込む(未登録言語は英語のまま)。
_PAGE_CTX = 'geo_webview.page'
_PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))

_PAGE_STRINGS = {
    '__T_SEARCHING__':
        'Searching for the engine\u2026',
    '__T_NOTFOUND__':
        'The engine (contents of <code>web/</code>) was not found.',
    '__T_UPLOAD__':
        'Upload this folder (<code>__KASC__</code> and <code>canvas_data/</code>) '
        'together with the engine to the same web server. Locations checked:',
    '__T_CANVAS_BASE__':
        'If the engine is placed elsewhere, set its URL (with a trailing '
        '<code>/</code>) in <code>CANVAS_BASE</code> in this HTML.',
    '__T_NOSCRIPT__':
        'This page requires JavaScript.',
    '__T_LOCALHELP__':
        'Could not connect to the local KASUGAI Canvas '
        "(<a href='http://127.0.0.1:8510/'>127.0.0.1:8510</a>). "
        'Start the app and reload this page. '
        '(For use on an external web host, upload this folder and the '
        'engine to the same server.)',
    '__T_HOSTED_PH__':
        'Hosted engine URL (e.g. https://example.com/canvas/)',
    '__T_OPEN_HOSTED__':
        'Open in hosted engine',
    '__T_BROWSER_ONLY__':
        'Runs in the browser only (select this folder \u2192 ?kasc=local)',
    '__T_TITLE__':
        'KASUGAI Canvas project \u2014 __KASC__',
    '__T_H1__':
        'KASUGAI Canvas project \u2014 <code>__KASC__</code>',
    '__T_INTRO__':
        'This export (<code>.kasc</code>+<code>canvas_data/</code>, launcher HTMLs) '
        'can be viewed in three ways.',
    '__T_ROUTE1__':
        'Open in KASUGAI Canvas (main integrated player)',
    '__T_ROUTE1_NOTE__':
        'Registers the project with a running Canvas app (127.0.0.1:8510) '
        'and opens it. If the app is not running, start it and reload '
        'this page.',
    '__T_CONNECTING__':
        'Connecting to Canvas\u2026',
    '__T_ROUTE2__':
        'Instant view in the browser via local HTTP delivery',
    '__T_ROUTE2_NOTE__':
        "The QGIS plugin's HTTP server serves the installed Canvas "
        '<code>web/</code> and <code>canvas_data/</code> (requires Canvas '
        'installed + server running).',
    '__T_LOCALNOTE__':
        'Open this page via <code>http://localhost:8089/export-data/</code> '
        'to enable the links.',
    '__T_ROUTE3__':
        'Serverless web delivery',
    '__T_ROUTE3_NOTE__':
        'Opens in the hosted engine (GitHub Pages). Data is available only '
        'while the plugin server is running.<br />'
        'For permanent hosting, <b>upload this whole folder plus the '
        'engine (contents of web/) to the same static host</b> and use the '
        'launcher HTMLs below (the engine is auto-detected).',
    '__T_LAUNCHER_LIST__':
        'Launcher pages after deployment:',
    '__T_CANVASBASE2__':
        '(engine location can be set via <code>CANVAS_BASE</code> in each '
        'HTML)',
    '__T_PACKAGEZIP__':
        'Package ZIP',
    '__T_ZIPDESC__':
        'A ZIP of the whole export (<code>.kasc</code>+<code>canvas_data/</code>+'
        'launcher HTMLs). Useful for static-host deployment and Re:Earth '
        'geo_suite <code>qgis:</code> import.<br />'
        "When opened via the plugin's HTTP server, clicking generates it "
        'on the fly and downloads it.',
    '__T_ZIPDL__':
        'Download __ZIP_NAME__',
    '__T_ZIPDISABLED__':
        '(ZIP download is disabled on file:// \u2014 open via the HTTP '
        'server)',
    '__T_LABEL_CESIUM__':
        'Cesium (3D, default)',
    '__T_NOCONN__':
        '<li>Cannot connect to the Canvas app (not running). Start it and '
        'reload this page.</li>',
    '__T_LOCALDISABLED__':
        "<li>(disabled) Open via the plugin's HTTP server</li>",
    '__T_HOSTEDUNSET__':
        '<li>(hosted URL not set) Upload this folder and the engine to a '
        'static host</li>',
}


def _localize_page(html):
    """テンプレート内の __LANG__ / __T_*__ を現在のUI言語で置換する。"""
    html = html.replace('__LANG__', lang_code() or 'en')
    for token, source in _PAGE_STRINGS.items():
        html = html.replace(
            token, translate_text(_PLUGIN_DIR, _PAGE_CTX, source))
    return html


_ENGINE_LAUNCHER_HTML = '''<!DOCTYPE html>
<html lang="__LANG__">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>KASUGAI Canvas — __ENGINE__</title>
<style>
  body { font-family: system-ui,"Segoe UI","Yu Gothic",sans-serif; margin: 28px; line-height: 1.65; color: #1d2b35; }
  code { background: #eef2f5; padding: 1px 5px; border-radius: 4px; }
  #tried a { color: #2c5ea8; }
  .note { color: #52636d; font-size: 0.9em; }
</style>
</head>
<body>
<h1 style="font-size:1.15em">KASUGAI Canvas — __ENGINE__</h1>
<p id="status">__T_SEARCHING__</p>
<div id="notfound" hidden>
  <p>__T_NOTFOUND__<br />
  __T_UPLOAD__</p>
  <ul id="tried"></ul>
  <p class="note">__T_CANVAS_BASE__</p>
</div>
<noscript><p>__T_NOSCRIPT__</p></noscript>
<script>
(function () {
  "use strict";
  // Location of the KASUGAI Canvas engine (contents of web/).
  // Point to the directory containing cesium/ maplibre/ openlayers/
  // leaflet/ gsimaps/ navara/ shared/ with a trailing /
  // (e.g. "https://example.com/canvas/").
  // When left empty, __ENGINE__/index.html is probed under ./ ../ ../../ /
  var CANVAS_BASE = "";
  // URL of the hosted engine (trailing /, e.g. "https://example.com/canvas/").
  // When set, file:// launches offer an "open in hosted engine" option
  // (?kasc=local mode where the browser reads a local folder by itself)
  var HOSTED_BASE = "__HOSTED_BASE__";
  var ENGINE = "__ENGINE__";
  var KASC = "__KASC__";
  var kascUrl = new URL(KASC, location.href).href;
  var ENGINES = ["cesium", "maplibre", "openlayers", "leaflet", "gsimaps", "navara"];
  function engineBase(base) {
    // If the base ends with an engine directory, replace it; otherwise append ENGINE
    var u = new URL(base, location.href);
    u.search = ""; u.hash = "";
    var seg = u.pathname.replace(/[/]+$/, "").split("/").pop().toLowerCase();
    if (ENGINES.indexOf(seg) >= 0) {
      u.pathname = u.pathname.replace(/[^/]+[/]?$/, ENGINE + "/");
      return u.href;
    }
    return new URL(ENGINE + "/", u).href;
  }
  function target(base) {
    return engineBase(base) + "?kasc=" + encodeURIComponent(kascUrl);
  }
  // On file://, register the .kasc with the local KASUGAI Canvas
  // (127.0.0.1:8510) as an external project and forward to
  // /<engine>/?project=<id>. Browsers cannot fetch local files from
  // file:// pages, so no web probing is done (CANVAS_BASE wins if set)
  if (!CANVAS_BASE && location.protocol === "file:") {
    var kascPath = decodeURIComponent(new URL(KASC, location.href).pathname)
      .replace(/^\\/([A-Za-z]:)/, "$1").replace(/\\//g, "\\\\");
    function localHelp() {
      document.getElementById("status").innerHTML = "__T_LOCALHELP__";
      // "Open in hosted engine": works even without HOSTED_BASE preset.
      // The input is kept in localStorage (shared by all launchers on file://)
      var row = document.createElement("div");
      row.style.cssText = "margin-top:10px";
      var inp = document.createElement("input");
      inp.placeholder = "__T_HOSTED_PH__";
      inp.style.cssText = "width:65%;padding:4px";
      try {
        inp.value = HOSTED_BASE || localStorage.getItem("kasugai_hosted_base") || "";
      } catch (e) { inp.value = HOSTED_BASE; }
      var go = document.createElement("button");
      go.textContent = "__T_OPEN_HOSTED__";
      go.style.cssText = "padding:4px 10px;margin-left:4px";
      go.onclick = function () {
        var base = inp.value.trim();
        if (!base) return;
        if (!/[\\/]$/.test(base)) base += "/";
        try { localStorage.setItem("kasugai_hosted_base", base); } catch (e) {}
        // Pass this folder name as dirhint so the hosted UI can guide selection
        var dirName = "";
        try {
          dirName = decodeURIComponent(location.pathname.replace(/[/][^/]*$/, "")
            .split("/").filter(Boolean).pop() || "");
        } catch (e) {}
        location.href = engineBase(base) + "?kasc=local" +
          (dirName ? "&dirhint=" + encodeURIComponent(dirName) : "");
      };
      row.appendChild(inp); row.appendChild(go);
      var hint = document.createElement("div");
      hint.style.cssText = "font-size:11px;color:#667;margin-top:4px";
      hint.textContent = "__T_BROWSER_ONLY__";
      row.appendChild(hint);
      document.getElementById("status").appendChild(row);
    }
    fetch("http://127.0.0.1:8510/api/projects/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: kascPath })
    }).then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function (res) {
        if (res && res.id) {
          location.replace("http://127.0.0.1:8510/" + ENGINE + "/?project=" + encodeURIComponent(res.id));
        } else { localHelp(); }
      }).catch(localHelp);
    return;
  }
  if (CANVAS_BASE) {
    location.replace(target(new URL(CANVAS_BASE, location.href)));
    return;
  }
  var bases = ["./", "../", "../../", "/"];
  var i = 0;
  function next() {
    if (i >= bases.length) {
      document.getElementById("status").hidden = true;
      document.getElementById("notfound").hidden = false;
      // On http(s) delivery (e.g. geo_webview :8089) the .kasc already
      // lives on this server, so an absolute URL can forward straight
      // to the hosted engine
      if (HOSTED_BASE && location.protocol.indexOf("http") === 0) {
        var hp = document.createElement("p");
        var ha = document.createElement("a");
        ha.href = target(HOSTED_BASE);
        ha.textContent = "__T_OPEN_HOSTED__";
        hp.appendChild(ha);
        document.getElementById("notfound").appendChild(hp);
      }
      return;
    }
    var base = new URL(bases[i], location.href); i += 1;
    var probe = new URL(ENGINE + "/index.html", base).href;
    var li = document.createElement("li");
    var a = document.createElement("a");
    a.href = target(base); a.textContent = probe;
    li.appendChild(a);
    document.getElementById("tried").appendChild(li);
    fetch(probe, { method: "HEAD", cache: "no-store" })
      .then(function (r) { if (r.ok) location.replace(target(base)); else next(); })
      .catch(function () { next(); });
  }
  next();
})();
</script>
</body>
</html>
'''

_LAUNCHER_INDEX_HTML = '''<!DOCTYPE html>
<html lang="__LANG__">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>__T_TITLE__</title>
<style>
  body { font-family: system-ui,"Segoe UI","Yu Gothic",sans-serif; margin: 28px; line-height: 1.65; color: #1d2b35; max-width: 900px; }
  code { background: #eef2f5; padding: 1px 5px; border-radius: 4px; }
  section { border: 1px solid #d7dfe6; border-radius: 8px; padding: 10px 16px; margin: 14px 0; }
  h2 { font-size: 1em; margin: 0 0 6px; }
  ul { margin: 6px 0; padding-left: 20px; }
  li { margin: 3px 0; }
  a { color: #2c5ea8; }
  .note { color: #52636d; font-size: 0.88em; }
  .route-no { display: inline-block; background: #2c5ea8; color: #fff; border-radius: 50%;
    width: 1.5em; height: 1.5em; text-align: center; line-height: 1.5em; margin-right: 6px; font-size: 0.8em; }
</style>
</head>
<body>
<h1 style="font-size:1.15em">__T_H1__</h1>
<p>__T_INTRO__</p>

<section>
  <h2><span class="route-no">1</span>__T_ROUTE1__</h2>
  <p class="note">__T_ROUTE1_NOTE__</p>
  <ul id="canvas-links"><li>__T_CONNECTING__</li></ul>
</section>

<section>
  <h2><span class="route-no">2</span>__T_ROUTE2__</h2>
  <p class="note">__T_ROUTE2_NOTE__</p>
  <ul id="local-links"></ul>
  <p id="local-note" class="note" hidden>__T_LOCALNOTE__</p>
</section>

<section>
  <h2><span class="route-no">3</span>__T_ROUTE3__</h2>
  <p class="note">__T_ROUTE3_NOTE__</p>
  <ul id="hosted-links"></ul>
  <p class="note">__T_LAUNCHER_LIST__
    <a href="cesium.html">cesium.html</a> / <a href="maplibre.html">maplibre.html</a> /
    <a href="openlayers.html">openlayers.html</a> / <a href="leaflet.html">leaflet.html</a> /
    <a href="gsimaps.html">gsimaps.html</a> / <a href="navara.html">navara.html</a>
    __T_CANVASBASE2__</p>
</section>

<section>
  <h2>__T_PACKAGEZIP__</h2>
  <p class="note">__T_ZIPDESC__
  <span id="zip-note"></span></p>
  <p><a href="__ZIP_NAME__" download>__T_ZIPDL__</a></p>
</section>

<script>
(function () {
  "use strict";
  var KASC = "__KASC__";
  var HOSTED_BASE = "__HOSTED_BASE__";
  var ENGINES = ["cesium", "maplibre", "openlayers", "leaflet", "gsimaps", "navara"];
  var LABELS = { cesium: "__T_LABEL_CESIUM__", maplibre: "MapLibre GL", openlayers: "OpenLayers", leaflet: "Leaflet", gsimaps: "GSI Maps", navara: "Navara" };
  var kascUrl = new URL(KASC, location.href).href;
  var isHttp = /^https?:$/.test(location.protocol);
  if (!isHttp) {
    document.getElementById("zip-note").textContent = "__T_ZIPDISABLED__";
  }
  function links(el, make) {
    var ul = document.getElementById(el);
    ul.innerHTML = "";
    ENGINES.forEach(function (e) {
      var li = document.createElement("li");
      var a = document.createElement("a");
      a.href = make(e); a.textContent = LABELS[e];
      li.appendChild(a); ul.appendChild(li);
    });
  }
  // (1) KASUGAI Canvas (main integrated player): register the project on
  //     127.0.0.1:8510 and open it. file:// registers the local path,
  //     http(s) reuses the ?kasc= URL directly
  var cl = document.getElementById("canvas-links");
  var kascPath = "";
  try {
    kascPath = decodeURIComponent(new URL(KASC, location.href).pathname)
      .replace(/^[/]([A-Za-z]:)/, "$1");
  } catch (e) {}
  fetch("http://127.0.0.1:8510/health", { cache: "no-store" })
    .then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
    .then(function () {
      if (isHttp) {
        links("canvas-links", function (e) {
          return "http://127.0.0.1:8510/" + e + "/?kasc=" + encodeURIComponent(kascUrl);
        });
      } else {
        // file://: pass the local path to the register API and open ?project=
        return fetch("http://127.0.0.1:8510/api/projects/register", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ path: kascPath.replace(new RegExp("[/]", "g"), "\\\\") })
        }).then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
          .then(function (res) {
            links("canvas-links", function (e) {
              return "http://127.0.0.1:8510/" + e + "/?project=" + encodeURIComponent(res.id);
            });
          });
      }
    })
    .catch(function () {
      cl.innerHTML = "__T_NOCONN__";
    });
  // (2) Local HTTP delivery: only when this page is served over http(s)
  //     (e.g. opened via geo_webview :8089)
  if (isHttp) {
    links("local-links", function (e) {
      return location.origin + "/" + e + "/?kasc=" + encodeURIComponent(kascUrl);
    });
  } else {
    document.getElementById("local-links").innerHTML = "__T_LOCALDISABLED__";
    document.getElementById("local-note").hidden = false;
  }
  // (3) Serverless web delivery: absolute .kasc URL on http(s), or
  //     ?kasc=local (folder-pick mode of the hosted engine) on file://
  if (HOSTED_BASE) {
    links("hosted-links", function (e) {
      if (isHttp) {
        return HOSTED_BASE + e + "/?kasc=" + encodeURIComponent(kascUrl);
      }
      var dirName = "";
      try {
        dirName = decodeURIComponent(location.pathname.replace(/[/][^/]*$/, "")
          .split("/").filter(Boolean).pop() || "");
      } catch (e2) {}
      return HOSTED_BASE + e + "/?kasc=local" +
        (dirName ? "&dirhint=" + encodeURIComponent(dirName) : "");
    });
  } else {
    document.getElementById("hosted-links").innerHTML = "__T_HOSTEDUNSET__";
  }
})();
</script>
</body>
</html>
'''


def normalize_engine(engine):
    """engine 名を正規化。無効値は None を返す。"""
    e = str(engine or '').strip().lower()
    return e if e in VALID_ENGINES else None


def _qsettings():
    from qgis.PyQt.QtCore import QSettings
    return QSettings('GeoWebView', 'geo_webview')


def default_output_dir():
    """既定出力先: <ドキュメント>/kasugai_canvas_qgis。"""
    try:
        from qgis.PyQt.QtCore import QStandardPaths
        loc = getattr(
            getattr(QStandardPaths, 'StandardLocation', QStandardPaths),
            'DocumentsLocation')
        docs = QStandardPaths.writableLocation(loc)
        if docs:
            return os.path.join(docs, 'kasugai_canvas_qgis')
    except Exception:  # nosec B110  # 設計上の許容
        pass
    import tempfile
    return os.path.join(tempfile.gettempdir(), 'kasugai_canvas_qgis')


def get_output_dir():
    """QSettings の kasugai_output_path(空/'__default__'は既定)を返す。"""
    try:
        saved = _qsettings().value(SETTINGS_KEY_OUTPUT, '') or ''
        saved = str(saved).strip()
        if saved and saved != '__default__':
            return saved
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return default_output_dir()


def set_output_dir(path):
    """パネル等で選択した出力先を QSettings に保存する。

    空文字/'__default__' を渡すと既定(インストール先/ドキュメント)に戻る。
    """
    _qsettings().setValue(SETTINGS_KEY_OUTPUT, (path or '').strip())


def get_kasugai_install_dir():
    """QSettings の kasugai_install_path（KASUGAI Canvas インストール先）を返す。

    設定済みでディレクトリが存在する場合のみ返し、それ以外は None。
    空/'__default__' は未設定扱い。
    """
    try:
        saved = (_qsettings().value('kasugai_install_path', '') or '').strip()
        if saved and saved != '__default__' and os.path.isdir(saved):
            return saved
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return None


def _registry_install_dir():
    """Windows インストーラが登録するインストール先をレジストリから返す。

    HKCU\\...\\Uninstall\\KASUGAI Canvas\\InstallLocation。
    未登録・非 Windows は None。
    """
    if os.name != 'nt':
        return None
    try:
        import winreg
        with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, _KASUGAI_UNINSTALL_KEY) as key:
            loc = winreg.QueryValueEx(key, 'InstallLocation')[0]
        # ディレクトリが消えた/ファイルのみ欠落した中途半端な登録は
        # 未インストール扱いにする(exe の存在まで確認)
        if loc and os.path.isfile(os.path.join(loc, KASUGAI_EXE_NAME)):
            return loc
    except Exception:  # nosec B110  # レジストリ未登録は正常系
        pass
    return None


def detect_kasugai_install_dir():
    """KASUGAI Canvas のインストール先を特定して返す（見つからなければ None）。

    1) QSettings ``kasugai_install_path``（設定で明示登録）
    2) Windows インストーラのレジストリ InstallLocation（設定未登録でも
       インストール済みなら一体運用に使う）
    """
    return get_kasugai_install_dir() or _registry_install_dir()


def kasugai_projects_dir():
    """KASUGAI インストール先の projects/ ディレクトリを返す（未設定なら None）。

    <install>/projects/ を優先し、無ければ <install>/web/projects/、
    どちらも無ければ <install>/projects/ を作成して返す。
    """
    install = detect_kasugai_install_dir()
    if not install:
        return None
    for cand in (os.path.join(install, 'projects'),
                 os.path.join(install, 'web', 'projects')):
        if os.path.isdir(cand):
            return cand
    cand = os.path.join(install, 'projects')
    os.makedirs(cand, exist_ok=True)
    return cand


def kasugai_qgis_projects_dir():
    """QGIS 連携プロジェクト専用の ``<install>/QGIS_projects/`` を返す。

    Canvas 本体の ``projects/``（ユーザー管理）と分離し、QGIS 由来の
    エクスポートを専用フォルダに置く。Canvas への表示は
    ``/api/projects/register`` の外部プロジェクト登録経由。
    インストール先を検出できなければ None（設定未登録でもレジストリ
    検出で一体運用になる）。ディレクトリは必要時に作成する。
    """
    install = detect_kasugai_install_dir()
    if not install:
        return None
    cand = os.path.join(install, 'QGIS_projects')
    os.makedirs(cand, exist_ok=True)
    return cand


def preferred_output_dir(project_name=None):
    """QGIS 連携プロジェクトの出力先ディレクトリを決める。

    パネル等で出力先(kasugai_output_path)を明示している場合はそれを
    最優先で使う。未設定なら KASUGAI Canvas のインストール先が
    登録済みのとき ``<install>/QGIS_projects/<QGISプロジェクト名>/``
    （Canvas 本体の projects/ と分離した QGIS 連携専用フォルダ。
    Canvas への表示は外部プロジェクト登録経由）、未登録なら
    ``default_output_dir()``（``<Documents>/kasugai_canvas_qgis``）。

    project_name 未指定時は QgsProject.instance().baseName()。
    """
    try:
        saved = str(
            _qsettings().value(SETTINGS_KEY_OUTPUT, '') or '').strip()
        if saved and saved != '__default__':
            return saved
    except Exception:  # nosec B110  # 設計上の許容
        pass
    proj_dir = kasugai_qgis_projects_dir()
    if proj_dir:
        if not project_name:
            try:
                from qgis.core import QgsProject
                project_name = QgsProject.instance().baseName()
            except Exception:  # nosec B110  # 設計上の許容
                project_name = None
        return os.path.join(
            proj_dir, project_dir_slug(project_name or 'qgis_export'))
    return default_output_dir()


_last_export_dir = None


def last_export_dir():
    """直近のエクスポート出力先（/export-data/ の配信ルート）。

    セッション内で一度もエクスポートしていなければ preferred_output_dir()
    （実際の出力先と同じ規則: 設定→Canvasインストール先→Documents）。
    """
    return _last_export_dir or preferred_output_dir()


def existing_export(output_dir=None):
    """既にエクスポート済みの ``kasugai_canvas.kasc`` を探す。

    output_dir 未指定時は preferred_output_dir() と同じ規則で出力先を
    決める。見つかれば ``(dir, kasc_path)`` を返し、_last_export_dir も
    更新して /export-data/ の配信ルートとして使えるようにする。
    未エクスポートなら None。
    """
    global _last_export_dir
    out_dir = os.path.abspath(output_dir or preferred_output_dir())
    kasc = os.path.join(out_dir, 'kasugai_canvas.kasc')
    if not os.path.isfile(kasc):
        # link_files モードのプロジェクト隣接 .kasc も探す
        try:
            from qgis.core import QgsProject
            pdir = os.path.dirname(os.path.abspath(
                QgsProject.instance().fileName() or ''))
        except Exception:  # nosec B110  # 設計上の許容
            pdir = ''
        if pdir and pdir != out_dir:
            kasc = os.path.join(pdir, 'kasugai_canvas.kasc')
            if os.path.isfile(kasc):
                _last_export_dir = pdir
                return pdir, kasc
        return None
    _last_export_dir = out_dir
    return out_dir, kasc


def project_dir_slug(name):
    """プロジェクト名から projects/<id>/ 用の安全なスラッグを作る。"""
    import re as _re
    slug = _re.sub(r'[^A-Za-z0-9_-]+', '_', str(name or '').strip()).strip('_')
    return slug or 'qgis_export'


def get_kasugai_port():
    """QSettings の kasugai_port(未設定は8510)を返す。"""
    try:
        saved = _qsettings().value(SETTINGS_KEY_PORT, '') or ''
        if str(saved).strip():
            return int(str(saved).strip())
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return DEFAULT_KASUGAI_PORT


# ---- ベクター出力モード(native / recommended / geojson) ----

def get_vector_export_mode():
    """QSettings の kasugai_vector_format を返す。

    'native'(既定): gpkg/geojson/shp/csv/kml/wfs 等のソースを
    そのまま行タイプとして参照する。
    'recommended': 推奨形式(FlatGeobuf/GeoParquet 系)以外のベクターを
    すべて FlatGeobuf へ変換して canvas_data/ へ配置する。
    'geojson': 全ベクター(推奨形式ソース含む)を GeoJSON へ変換して
    canvas_data/ へ配置する(WEB連携・他 WebGIS との相互運用用)。
    """
    try:
        saved = str(_qsettings().value(
            SETTINGS_KEY_VECTOR_FORMAT, '') or '').strip().lower()
        if saved in VECTOR_EXPORT_MODES:
            return saved
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return 'native'


def set_vector_export_mode(mode):
    """ベクター出力モードを QSettings へ保存する(VECTOR_EXPORT_MODES)。"""
    m = str(mode or '').strip().lower()
    _qsettings().setValue(
        SETTINGS_KEY_VECTOR_FORMAT,
        m if m in VECTOR_EXPORT_MODES else 'native')


# ---- 非表示レイヤのデータ変換スキップ(高速化スイッチ) ----

def get_visible_data_only():
    """QSettings の kasugai_visible_data_only(未設定は True)を返す。

    パネルの「表示中のみ変換」チェックと共有される既定値。
    True なら ``| off`` で出力される非表示レイヤのデータ変換・
    コピーをスキップし、参照行のみ出力する。
    """
    try:
        v = _qsettings().value(SETTINGS_KEY_VISIBLE_DATA_ONLY, None)
        if v is not None and str(v).strip() != '':
            return str(v).strip().lower() not in (
                '0', 'false', 'off', 'no')
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return True


def set_visible_data_only(on):
    """非表示レイヤのデータ変換スキップを QSettings へ保存する。"""
    _qsettings().setValue(
        SETTINGS_KEY_VISIBLE_DATA_ONLY, '1' if on else '0')


# ---- ベクター→XYZ タイル焼き付け(高速表示モード) ----

def get_xyz_tiles_enabled():
    """QSettings の kasugai_xyz_tiles(未設定は True)を返す。

    パネルの「XYZ tiles (faster display)」チェックと共有される既定値。
    True なら大規模レイヤ・複雑スタイルのベクターを QGIS レンダラで
    XYZ タイルへ焼き付けて ``xyz:`` 行として出す
    (データ照会用のベクター行は ``| off`` で併記)。
    """
    try:
        v = _qsettings().value(SETTINGS_KEY_XYZ_TILES, None)
        if v is not None and str(v).strip() != '':
            return str(v).strip().lower() not in (
                '0', 'false', 'off', 'no')
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return True


def set_xyz_tiles_enabled(on):
    """XYZ タイル焼き付けの有効/無効を QSettings へ保存する。"""
    _qsettings().setValue(
        SETTINGS_KEY_XYZ_TILES, '1' if on else '0')


def get_xyz_zooms():
    """QSettings の XYZ 焼き付けズーム範囲 (zmin, zmax)。

    未設定時は XYZ_TILES_ZOOM_DEFAULT (1, 15)。パネルの
    ズーム範囲スピンと共有される。
    """
    dmin, dmax = XYZ_TILES_ZOOM_DEFAULT

    def _ival(key, default):
        try:
            v = _qsettings().value(key, None)
            if v is None or str(v).strip() == '':
                return default
            return max(0, min(22, int(float(str(v).strip()))))
        except Exception:  # nosec B110  # 設計上の許容
            return default

    zmin = _ival(SETTINGS_KEY_XYZ_ZMIN, dmin)
    zmax = _ival(SETTINGS_KEY_XYZ_ZMAX, dmax)
    if zmax < zmin:
        zmax = zmin
    return zmin, zmax


def set_xyz_zooms(zmin, zmax):
    """XYZ 焼き付けズーム範囲を QSettings へ保存する。"""
    zmin = max(0, min(22, int(zmin)))
    zmax = max(zmin, min(22, int(zmax)))
    _qsettings().setValue(SETTINGS_KEY_XYZ_ZMIN, str(zmin))
    _qsettings().setValue(SETTINGS_KEY_XYZ_ZMAX, str(zmax))


def get_site_control():
    """QSettings の kasugai_site_control(未設定は False)を返す。

    パネルの「カスタムレイヤタブ」チェックと共有される既定値。
    True ならレイヤツリーのグループ名を ``site=<グループ>`` として
    レイヤ行へ付け、custom-layer プラグインを canvas_data/ へ複製して
    ``plugin:`` 行を出力する(標準レイヤタブは全レイヤを表示したまま
    「システムレイヤ」に改称され、custom-layer タブが site ごとの
    一括 on/off を担う)。
    """
    try:
        v = _qsettings().value(SETTINGS_KEY_SITE_CONTROL, None)
        if v is not None and str(v).strip() != '':
            return str(v).strip().lower() not in (
                '0', 'false', 'off', 'no')
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return False


def set_site_control(on):
    """カスタムレイヤタブの有効化を QSettings へ保存する。"""
    _qsettings().setValue(
        SETTINGS_KEY_SITE_CONTROL, '1' if on else '0')


def _canvas_layer_opts_suffix(layer, groups, bm_idx, site_control):
    """レイヤ行へ付ける `` | site=`` / `` | order=`` / `` | list=off`` /
    追加オプションのオプション文字列を返す。

    レイヤ customProperty(パネルの Layers タブからも設定):
    - ``kasugai_site`` — カスタムタブのグループ名。未設定で site_control
      ON ならグループ階層(``A/B`` 連結)を自動付与。``-``/空文字で
      強制未割当(「その他」行・標準タブに残る)
    - ``kasugai_order`` — 同一 site 内の並び順(小さいほど最前面)
    - ``kasugai_list`` — ``off`` で標準レイヤ一覧から非表示(地図は描画)
    - ``kasugai_opts`` — 空白/``|`` 区切りの任意 ``key=value`` 列を
      そのまま追加(``opacity=0.5 heat=on`` 等)
      (``legend_order=asc|desc|reverse|ラベル列挙`` で
      カスタムタブの凡例順を変更可)
    ベースマップグループ内のレイヤは site= を付けない。
    """
    o = _canvas_layer_opts(layer, groups, bm_idx, site_control)
    out = ''
    if o['site']:
        out += ' | site={0}'.format(_kasc_escape(o['site']))
    if o['order']:
        out += ' | order={0}'.format(_kasc_escape(o['order']))
    if o['list'] == 'off':
        out += ' | list=off'
    for tok in o['opts']:
        out += ' | {0}'.format(_kasc_escape(tok))
    return out


def _canvas_layer_opts(layer, groups, bm_idx, site_control):
    """レイヤの .kasc 追加オプションを dict で返す(VIEW 表示・内部用)。

    戻り値 ``{'site': <箇所名>|None, 'order': <文字列>|None,
    'list': 'off'|None, 'opts': [<key=value>,...]}``。
    ``site`` は ``_canvas_layer_opts_suffix`` と同一の解決規則。
    """
    res = {'site': None, 'order': None, 'list': None, 'opts': []}
    try:
        site = layer.customProperty('kasugai_site', None)
    except Exception:  # nosec B110  # 設計上の許容
        site = None
    if site is None:
        site = ('/'.join([g for g in groups if g])
                if site_control and bm_idx is None else '')
    else:
        site = str(site).strip()
    if site and site != '-' and bm_idx is None:
        res['site'] = site
    try:
        order = layer.customProperty('kasugai_order', None)
    except Exception:  # nosec B110  # 設計上の許容
        order = None
    if order is not None and str(order).strip() != '':
        res['order'] = str(order).strip()
    try:
        lst = layer.customProperty('kasugai_list', None)
    except Exception:  # nosec B110  # 設計上の許容
        lst = None
    if str(lst or '').strip() == 'off':
        res['list'] = 'off'
    try:
        extra = layer.customProperty('kasugai_opts', None)
    except Exception:  # nosec B110  # 設計上の許容
        extra = None
    for tok in re.split(r'[|\s]+', str(extra or '')):
        if tok and ('=' in tok or tok in ('on', 'off')):
            res['opts'].append(tok)
    return res


def _copy_site_control_plugin(data_dir, warnings):
    """custom-layer プラグインJSを canvas_data/ へ複製する。

    バンドル元は geo_webview/assets/custom-layer.js で、正本は
    kasugai_canvas/web/cesium/PLUGIN/custom-layer/plugin.js
    (Canvas 側更新時は内容を同期する)。
    """
    src = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       'assets', 'custom-layer.js')
    dst = os.path.join(data_dir, 'custom-layer.js')
    try:
        if not os.path.isfile(dst) or not _same_data_copy(src, dst):
            import shutil
            shutil.copy2(src, dst)
        return True
    except Exception as e:
        warnings.append('custom-layer.js 複製失敗: {0}'.format(e))
        return False


def _recommended_source_kind(layer):
    """ソースが推奨形式(fgb/parquet)なら行タイプ、でなければ None。

    推奨形式モードの事前判定用。fgb/parquet 以外のソース(gpkg/geojson/
    shp/csv/kml/wfs 等)は ``_native_ref`` を呼ばず直接 FlatGeobuf 変換
    へ回す。``_native_ref`` はファイルを canvas_data/ へコピーしてから行タイプを
    返すため、捨てる参照のコピーを防ぐ目的もある。
    """
    path = _source_path(layer) or (layer.source() or '')
    low = path.split('?')[0].lower()
    if low.endswith(('.fgb', '.flatgeobuf')):
        return 'flatgeobuf'
    if low.endswith(('.parquet', '.geoparquet')):
        return 'geoparquet'
    return None


def _is_recommended_native(native):
    """``_native_ref`` の結果が推奨形式の行タイプかを返す。

    推奨形式モードで参照を維持するのは ``flatgeobuf:``・``geoparquet:``
    と、geoparquet ソース+subset が出す
    ``duckdb:+format=parquet`` 行のみ。それ以外(gpkg/geojson/shp/csv/
    kml/wfs/topojson 等)は FlatGeobuf 変換へ回す。
    """
    if not isinstance(native, dict):
        return False
    if native.get('type') in ('flatgeobuf', 'geoparquet'):
        return True
    return native.get('type') == 'duckdb' and \
        (native.get('opts') or {}).get('format') == 'parquet'


# ---- ホスト版エンジン(kasugai-canvas-web) ----

KASUGAI_WEB_HOST = (
    'https://yamamoto-ryuzo.github.io/kasugai-canvas-web/')
HOSTED_CHANNELS = ('stable', 'unstable')
SETTINGS_KEY_HOSTED_CHANNEL = 'kasugai_hosted_channel'
SETTINGS_KEY_HOSTED_VALUE = 'kasugai_hosted_value'


def get_hosted_channel():
    """QSettings の kasugai_hosted_channel(未設定は 'stable')を返す。

    'stable'/'unstable'、'canvas'(稼働中の Canvas アプリ :8510)、
    'custom'(カスタム供給元。実値は kasugai_hosted_value —
    http(s) URL なら自前ホスト、フォルダパスなら FILE モードで
    geo_webview サーバがそのツリーを /<engine>/ で静的配信)、
    'url'/'file'(旧トークン=custom 同値)、または直接書かれた
    URL/パス(旧形式互換)を取る。
    """
    v = (_qsettings().value(SETTINGS_KEY_HOSTED_CHANNEL, '') or '')
    return str(v).strip() or 'stable'


def get_hosted_value():
    """QSettings の kasugai_hosted_value(url/file モードの実値)を返す。

    url モードでは http(s) ベースURL、file モードでは web/ フォルダ
    パスを保持する。
    """
    v = (_qsettings().value(SETTINGS_KEY_HOSTED_VALUE, '') or '')
    return str(v).strip()


def _custom_channel_value(channel=None):
    """custom/url/file 系モードの実値を返す。それ以外はモード値そのまま。"""
    ch = str(channel if channel is not None
             else get_hosted_channel() or 'stable').strip()
    if ch.lower() in ('custom', 'url', 'file'):
        return get_hosted_value()
    return ch


def is_hosted_channel(channel=None):
    """モード値がホスト側供給(stable/unstable/カスタムURL)なら True。

    'canvas' や FILE(パス系)は False(=ローカル系)。custom/url/file
    トークンは実値が http(s) 始まりなら True。
    """
    ch = _custom_channel_value(channel)
    return ch.lower() in HOSTED_CHANNELS or ch.lower().startswith(
        ('http://', 'https://'))


def local_channel_web_dir(channel=None):
    """モード値が FILE 系ならその web/ ディレクトリを返す。

    custom/file トークンは kasugai_hosted_value のパス、それ以外は
    直接書かれたパス(旧形式)を使う。hosted 系や 'canvas'/'local'
    (legacy)なら None。存在する web/ ツリー(index.html 必須)のみ
    絶対パスで返す。
    """
    ch = _custom_channel_value(channel).strip().strip('"')
    if (not ch or ch.lower() in HOSTED_CHANNELS
            or ch.lower() in ('canvas', 'local')
            or ch.lower().startswith(('http://', 'https://'))):
        return None
    if os.path.isfile(os.path.join(ch, 'index.html')):
        return os.path.abspath(ch)
    return None


def export_zip_name(channel=None):
    """エクスポートZIPのファイル名を返す。

    CDNチャンネル(stable/unstable/カスタムURL)を
    ``kasugai_canvas_<tag>.zip`` として反映する。
    カスタムURLは末尾パス要素をタグ化する。
    """
    ch = str(channel if channel is not None
             else get_hosted_channel()).strip()
    if ch.lower() in ('custom', 'url', 'file'):
        ch = get_hosted_value() or 'stable'
    if ch.lower() in HOSTED_CHANNELS:
        tag = ch.lower()
    elif not is_hosted_channel(ch):
        tag = 'local'
    elif ch.lower().startswith(('http://', 'https://')):
        seg = urllib.parse.urlparse(ch).path.rstrip('/').rsplit('/', 1)[-1]
        tag = re.sub(r'[^A-Za-z0-9_.-]+', '_', seg) or 'custom'
    else:
        tag = 'custom'
    return 'kasugai_canvas_{0}.zip'.format(tag)


def _is_export_zip_name(name):
    """kasugai_canvas.zip / kasugai_canvas_<tag>.zip 形式なら True。"""
    return bool(re.match(r'kasugai_canvas(_[A-Za-z0-9_.-]+)?\.zip$',
                         os.path.basename(name or ''), re.IGNORECASE))


def hosted_engine_base(channel=None):
    """ホスト版エンジンのベースURL(末尾/付き)を返す。

    channel に http(s):// 始まりの値を渡すと自前ホストURLとして使う。
    未知の値は stable にフォールバックする。
    """
    ch = str(channel if channel is not None
             else get_hosted_channel()).strip()
    if ch.lower() in ('custom', 'url', 'file'):
        ch = get_hosted_value() or 'stable'
    if ch.lower().startswith(('http://', 'https://')):
        return ch if ch.endswith('/') else ch + '/'
    if ch.lower() not in HOSTED_CHANNELS:
        ch = 'stable'
    return '{0}{1}/'.format(KASUGAI_WEB_HOST, ch.lower())


def build_hosted_view_url(kasc_path, engine=None, port=None,
                          channel=None):
    """ホスト版エンジン + geo_webviewサーバのデータ配信で .kasc を開くURL。

    Canvas未インストール環境向けの最終フォールバック。
    ホスト版エンジンが /export-data/ 配下の .kasc+canvas_data/ を
    http://localhost:<port> から fetch する(サーバ側の
    OPTIONS/PNA対応が前提)。kasc_path が last_export_dir()
    配下に無い場合は None。
    """
    if not port:
        return None
    try:
        rel = os.path.relpath(kasc_path, last_export_dir())
    except ValueError:
        return None
    rel = rel.replace('\\', '/')
    if rel.startswith('..'):
        return None
    kasc_url = 'http://127.0.0.1:{0}/export-data/{1}'.format(
        int(port), urllib.parse.quote(rel))
    e = normalize_engine(engine) or DEFAULT_ENGINE
    return '{0}{1}/?kasc={2}'.format(
        hosted_engine_base(channel), e,
        urllib.parse.quote(kasc_url, safe=''))


def _slugify(name, used):
    """レイヤ名からcanvas_data/用の安全なファイル名(ASCII)を作る。"""
    slug = re.sub(r'[^A-Za-z0-9_\-]+', '_', str(name or '')).strip('_')
    if not slug:
        slug = 'layer'
    base = slug
    i = 2
    while slug.lower() in used:
        slug = '{0}_{1}'.format(base, i)
        i += 1
    used.add(slug.lower())
    return slug


def _kasc_escape(text):
    """.kasc 行の | 区切り・改行を壊さないようサニタイズする。"""
    return re.sub(r'[|\r\n]+', ' ', str(text or '')).strip()


def _kasc_layer_title(groups, leaf_name, exclusive_groups=None):
    """レイヤツリーのパンくずタイトルを返す。

    直系の親グループが相互排他(exclusive_groups に収集済み)なら
    親子間を ``//`` で繋ぐ(Canvas の排他グループ指定と同規則)。
    """
    parts = ([_kasc_escape(g) for g in groups if g] +
             [_kasc_escape(leaf_name)])
    if len(parts) > 1 and exclusive_groups is not None \
            and tuple(groups) in exclusive_groups:
        return '/'.join(parts[:-1]) + '//' + parts[-1]
    return '/'.join(parts)


def _project_maplayer_elements(project):
    """プロジェクトファイル(.qgs/.qgz)の <maplayer> 要素を id 引き辞書で返す。

    戻り値は ``(doc, {layer_id: QDomElement})``。doc は QDomElement の
    DOM 生存のために呼び出し側で保持する。取得不可時は ``(None, {})``。
    """
    from qgis.PyQt.QtXml import QDomDocument
    fname = project.fileName() or ''
    if not fname or not os.path.exists(fname):
        return None, {}
    try:
        if fname.lower().endswith('.qgz'):
            import zipfile
            with zipfile.ZipFile(fname) as zf:
                names = [n for n in zf.namelist()
                         if n.lower().endswith('.qgs')]
                if not names:
                    return None, {}
                data = zf.read(names[0])
        else:
            with open(fname, 'rb') as f:
                data = f.read()
        doc = QDomDocument()
        if not doc.setContent(data):
            return None, {}
        elems = {}
        lst = doc.elementsByTagName('maplayer')
        for i in range(lst.count()):
            el = lst.item(i).toElement()
            lid = el.namedItem('id').toElement().text()
            if lid:
                elems[lid] = el
        return doc, elems
    except Exception:  # nosec B110  # 設計上の許容
        return None, {}


# <maplayer> の type 属性 → レイヤクラス名(plugin/annotation/group は対象外)
_MAPLAYER_TYPE_CLS = {
    'vector': 'QgsVectorLayer',
    'raster': 'QgsRasterLayer',
    'mesh': 'QgsMeshLayer',
    'vector-tile': 'QgsVectorTileLayer',
    'point-cloud': 'QgsPointCloudLayer',
    'tiled-scene': 'QgsTiledSceneLayer',
}


def _layer_from_maplayer_elem(elem, context):
    """<maplayer> 要素から QgsMapLayer を再生成する。失敗時 None。"""
    import qgis.core as qc
    cls = getattr(qc, _MAPLAYER_TYPE_CLS.get(
        elem.attribute('type') or '', ''), None)
    if cls is None:
        return None
    try:
        lyr = cls()
        if lyr.readLayerXml(elem, context):
            return lyr
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return None


def _retry_invalid_layer(layer):
    """isValid()=False のレイヤへデータソース再解決を試みる。

    破損レイヤ(読込時にソース未達等)は id・スタイル・設定を保ったまま
    setDataSource で同一ソースを再オープンできる。成功時 True。
    """
    try:
        if layer.isValid():
            return True
    except Exception:  # nosec B110  # 設計上の許容
        return False
    try:
        src = layer.source() or ''
        prov = layer.providerType() or ''
        name = layer.name() or ''
        if not src:
            return False
        layer.setDataSource(src, name, prov)
        return bool(layer.isValid())
    except Exception:  # nosec B110  # 設計上の許容
        return False


def _load_unresolved_layer(project, node, maplayer_elems, context):
    """layer()=None のツリーノードをプロジェクトXML定義から再生成・再登録する。

    <maplayer> 要素を readLayerXml で読むため、スタイルやフィルタ等の
    プロジェクト設定も復元される。再登録に成功すれば
    layerTreeRegistryBridge が同 id の弱参照ノードへ自動解決する。
    """
    lid = ''
    try:
        lid = node.layerId() or ''
    except Exception:  # nosec B110  # 設計上の許容
        pass
    elem = maplayer_elems.get(lid)
    if elem is None:
        return None
    lyr = _layer_from_maplayer_elem(elem, context)
    if lyr is None or not lyr.isValid():
        return None
    project.addMapLayer(lyr)
    try:
        node.resolveReferences(project)
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return node.layer() or lyr


def _tree_layers(skipped=None, warnings=None, group_states=None,
                 exclusive_groups=None):
    """レイヤツリー順(上から)に (layer, group_path, visible) で返す。

    visible はノード自身のチェックと全祖先の表示状態の積(実効表示状態)。

    layer() が未解決のノード(ソース破損等でプロジェクトへ読み込まれ
    なかったレイヤ)は、プロジェクトファイルの <maplayer> 定義から
    再生成して再登録し、本来のツリー位置で出力する。解決不能なものは
    skipped へ「(未読込レイヤ)」として記録する。

    group_states に dict を渡すと、「 / 」連結のグループパスをキーに
    展開状態(True=expanded/False=collapsed)を収集する(#59)。
    exclusive_groups に set を渡すと、相互排他(チェックで1つだけ表示)な
    グループのパス(tuple)を収集する。直系のレイヤは ``//`` 区切りの
    排他グループタイトルとして出力する。
    """
    from qgis.core import (QgsProject, QgsReadWriteContext,
                           QgsPathResolver)
    project = QgsProject.instance()
    root = project.layerTreeRoot()
    entries = []

    def _walk(node, groups, visible):
        from qgis.core import QgsLayerTreeGroup, QgsLayerTreeLayer

        def _subtree_checked(gnode):
            """グループ配下の全レイヤノードのチェック状態を集約する
            (#63: グループの checked/unchecked/partial を再現するため)。"""
            states = []
            for ch in gnode.children():
                if isinstance(ch, QgsLayerTreeGroup):
                    states.extend(_subtree_checked(ch))
                elif isinstance(ch, QgsLayerTreeLayer):
                    try:
                        states.append(bool(ch.itemVisibilityChecked()))
                    except Exception:  # nosec B110  # 設計上の許容
                        states.append(True)
            return states

        excl = False
        if (exclusive_groups is not None
                and isinstance(node, QgsLayerTreeGroup)):
            try:
                excl = bool(node.isMutuallyExclusive())
            except Exception:  # nosec B110  # 設計上の許容
                excl = False
        for child in node.children():
            try:
                checked = child.itemVisibilityChecked()
            except Exception:
                checked = True
            eff = visible and bool(checked)
            if isinstance(child, QgsLayerTreeGroup):
                path = groups + [child.name()]
                if group_states is not None:
                    try:
                        expanded = bool(child.isExpanded())
                    except Exception:  # nosec B110  # 設計上の許容
                        expanded = True
                    _st = _subtree_checked(child)
                    _cs = ('checked' if all(_st)
                           else 'unchecked' if not any(_st) else 'partial')
                    group_states[' / '.join(path)] = (expanded, _cs)
                _walk(child, path, eff)
            elif isinstance(child, QgsLayerTreeLayer):
                entries.append((child, list(groups), eff))
                if excl:
                    exclusive_groups.add(tuple(groups))

    _walk(root, [], True)

    # 未読込レイヤがあればプロジェクトXMLを一度だけ読み、
    # <maplayer> 定義から再生成を試みる
    maplayer_elems = {}
    doc = None
    if any(node.layer() is None for node, _g, _v in entries):
        doc, maplayer_elems = _project_maplayer_elements(project)
    _ = doc  # QDomElement 生存のため DOM を保持するのみ
    context = QgsReadWriteContext()
    try:
        context.setPathResolver(QgsPathResolver(project.fileName()))
    except Exception:  # nosec B110  # 設計上の許容
        pass

    result = []
    for node, groups, eff in entries:
        lyr = node.layer()
        if lyr is None:
            lyr = _load_unresolved_layer(
                project, node, maplayer_elems, context)
            if warnings is not None and lyr is not None:
                warnings.append(
                    '{0}: 未読込レイヤを再読込'.format(lyr.name()))
            elif skipped is not None and lyr is None:
                skipped.append(
                    '{0} (未読込レイヤ)'.format(
                        node.name() or node.layerId()))
        else:
            try:
                valid = bool(lyr.isValid())
            except Exception:  # nosec B110  # 設計上の許容
                valid = True
            if not valid:
                # 破損レイヤ(読込時にソース未達等)は同一定義で再オープンを試みる
                if _retry_invalid_layer(lyr):
                    if warnings is not None:
                        warnings.append(
                            '{0}: 破損レイヤを再読込'.format(lyr.name()))
                elif skipped is not None:
                    skipped.append(
                        '{0} (破損レイヤ)'.format(lyr.name()))
                    continue
        if lyr is not None:
            result.append((lyr, groups, eff, node))
    return result


def _basemap_group_names():
    """ベースマップグループ名の集合(小文字)を返す。

    内蔵の BASEMAP_GROUP_NAMES に、QSettings
    ``kasugai_basemap_groups``(カンマ/読点/改行区切り)でユーザーが
    追加した名前を加えたもの。
    """
    names = set(BASEMAP_GROUP_NAMES)
    try:
        extra = _qsettings().value(SETTINGS_KEY_BASEMAP_GROUPS, '') or ''
    except Exception:  # nosec B110  # QSettings 非依存環境では空扱い
        extra = ''
    for part in re.split(r'[,;、，\n\r]+', str(extra)):
        part = part.strip().lower()
        if part:
            names.add(part)
    return names


def _basemap_group_index(groups, names=None):
    """groups 内でベースマップグループ名に一致する最外側の index を返す。

    names 省略時は _basemap_group_names() を使う。
    一致するグループが無ければ None。
    """
    names = names if names is not None else _basemap_group_names()
    for i, name in enumerate(groups or []):
        if (name or '').strip().lower() in names:
            return i
    return None


def _geo_equiv_crs(layer):
    """Canvas が再投影なしで扱える地理座標系か(4326 系・CRS84・JGD)。"""
    try:
        crs = layer.crs()
        if not crs or not crs.isValid():
            return False
        if crs.authid().upper() in ('EPSG:4326', 'EPSG:4269',
                                    'EPSG:4612', 'EPSG:6668'):
            return True
        return crs.isGeographic()
    except Exception:
        return False


def _source_path(layer):
    """ogr 系ソースの実ファイルパスを取り出す。なければ None。"""
    try:
        from qgis.core import QgsDataSourceUri
        db = QgsDataSourceUri(layer.source()).database()
    except Exception:
        db = ''
    cand = db or (layer.source() or '').split('|')[0]
    cand = urllib.parse.unquote(cand)
    if cand.startswith('file://'):
        cand = cand[7:]
    if re.match(r'^/[A-Za-z]:/', cand):
        cand = cand[1:]
    return cand if cand and os.path.exists(cand) else None


def _same_data_copy(src_abs, dest_abs):
    """canvas_data/ 内の既存コピーがソースと同一内容か(サイズ+mtime一致)。

    copy2 はソースの mtime を保持するため、過去エクスポートの複製は
    この条件に一致する。一致すれば再コピー不要(複製の蓄積防止)。
    """
    try:
        s, d = os.stat(src_abs), os.stat(dest_abs)
    except OSError:
        return False
    return s.st_size == d.st_size and s.st_mtime == d.st_mtime


# link_files モード(.kasc をプロジェクトファイル隣へ出力し原本を
# 相対参照で読む「複写なし」Web化)。export_kasugai_project が開始時に
# 設定する。変換物の置き場 data_dir はモードによらず 'canvas_data'
_LINK_FILES = False
_LINK_ROOT = None  # .kasc の出力先(プロジェクトdir)の絶対パス


def _link_ref(path):
    """link_files 時、原本 ``path`` を .kasc からの相対参照で返す。

    プロジェクト dir 配下または1階層上(ワークスペース相当。Canvas
    サーバの外部プロジェクト許可 depth)までのファイルは複写せず
    相対パスで参照する。それより外(深い親・別ドライブ)は None →
    呼び出し側が canvas_data/ へ複写する。スペース等は percent 化。
    """
    if not _LINK_FILES or _LINK_ROOT is None:
        return None
    try:
        rel = os.path.relpath(os.path.abspath(path), _LINK_ROOT)
    except ValueError:  # 別ドライブは相対化不能 → 複写へ
        return None
    parts = rel.split(os.sep)
    ups = 0
    for p in parts:
        if p == '..':
            ups += 1
        elif ups:
            # '..' の後に通常セグメント以外が来る形はあり得ない
            break
    if ups > 1:
        return None
    if any(p == '..' for p in parts[ups:]):
        return None
    return urllib.parse.quote('/'.join(parts), safe='/')


def _dref(data_dir, name):
    """data_dir 配下の参照文字列 'canvas_data/x' を返す。"""
    return '{0}/{1}'.format(os.path.basename(data_dir), name)


def _copy_to_data(src_path, data_dir, slug, copied, write=True):
    """ローカルファイルを canvas_data/<slug><ext> へコピーし 'canvas_data/...' を返す。

    宛先は常に固定名 ``<slug><ext>``。既存が同一内容なら再利用、
    異なる内容なら上書きする(旧仕様の ``<slug>_N<ext>`` 連番複製は
    エクスポート毎に canvas_data/ が肥大化するため廃止)。
    write=False(非表示 base: 候補の参照のみ出力)時は、既存の同一内容
    コピーがあればその参照を返し、コピーが必要な場合は None。
    """
    src_abs = os.path.abspath(src_path)
    if src_abs in copied:
        return copied[src_abs]
    ext = os.path.splitext(src_abs)[1]
    dest_abs = os.path.join(data_dir, slug + ext)
    same = False
    try:
        same = os.path.samefile(src_abs, dest_abs)
    except Exception:  # nosec B110  # 存在しない場合はコピー対象
        pass
    if not same and not _same_data_copy(src_abs, dest_abs):
        if not write:
            return None
        shutil.copy2(src_abs, dest_abs)
    rel = _dref(data_dir, os.path.basename(dest_abs))
    copied[src_abs] = rel
    return rel


# canvas_data/ へ複製するローカルディレクトリツリー(3D Tiles / ローカルXYZタイル)の上限
_LOCAL_TREE_MAX_BYTES = 1024 ** 3  # 1 GiB

# duckdb: 行へ回せる区切りテキストの拡張子(delimitedtext / ogr 共通)
_DUCKDB_TEXT_EXTS = ('.csv', '.tsv')


def _local_path(s):
    """file:///・/C:/ 形式・クエリ/パイプ付きURIからローカルパスを取り出す。"""
    p = urllib.parse.unquote((s or '').split('?')[0].split('|')[0])
    if p.startswith('file://'):
        p = p[7:]
    if re.match(r'^/[A-Za-z]:/', p):
        p = p[1:]
    return p


def _tree_bytes(path, cap):
    """ディレクトリ以下の合計バイト数。cap 超過で打ち切り。"""
    total = 0
    for _root, _dirs, files in os.walk(path):
        for fn in files:
            try:
                total += os.path.getsize(os.path.join(_root, fn))
            except OSError:
                pass
            if total > cap:
                return total
    return total


def _copy_tree_to_data(src_dir, data_dir, slug, copied, write=True):
    """ローカルディレクトリを canvas_data/<slug>/ へ複製し 'canvas_data/<slug>' を返す。

    既存の同名ディレクトリは(前回エクスポート産物として)置き換える。
    write=False(非表示 base: 候補の参照のみ出力)時は、既存の複製済み
    ディレクトリがあればその参照を再利用し、なければ None
    (ツリー内容の同一性確認は行わず前回出力物とみなす)。
    """
    src_abs = os.path.abspath(src_dir)
    if src_abs in copied:
        return copied[src_abs]
    dest_abs = os.path.join(data_dir, slug)
    same = False
    try:
        same = os.path.samefile(src_abs, dest_abs)
    except Exception:  # nosec B110  # 存在しない場合はコピー対象
        pass
    if not same:
        if not write:
            if not os.path.isdir(dest_abs):
                return None
        else:
            if os.path.isdir(dest_abs):
                shutil.rmtree(dest_abs)
            shutil.copytree(src_abs, dest_abs)
    rel = _dref(data_dir, slug)
    copied[src_abs] = rel
    return rel


def _subset_filter(layer):
    """レイヤのプロバイダフィルタ(subsetString)を where= 値として返す。

    ``where=`` は .kasc 行の最終オプション(値は行末まで)なので、
    ``||`` 連結や ``'a|b'`` リテラル等の ``|`` もそのまま出力できる。
    改行のみ空白へ潰す(``_kasc_escape`` は ``|`` を潰すため使わない)。
    """
    try:
        raw = (layer.subsetString() or '').strip()
    except Exception:  # nosec B110  # 設計上の許容
        return None
    if not raw:
        return None
    return re.sub(r'[\r\n]+', ' ', raw) or None


def _subset_raw(layer):
    """レイヤのプロバイダフィルタ(subsetString)を生文字列で返す。"""
    try:
        return (layer.subsetString() or '').strip()
    except Exception:  # nosec B110  # 設計上の許容
        return ''


# Canvas 側の where-eval.js(クライアント評価)が解釈できない構文の簡易検出。
# 引っかかった式は where= に載せず FlatGeobuf 変換でフィルタを焼き込む
# (パース失敗で全件表示になる回帰を防ぐための保守的ガード)。
# - IN(/NOT( と where-eval.js FUNCTION_NAMES 以外の「識別子+('
#   =未対応関数呼び出し・サブクエリ入口(許可関数名は where-eval.js と同期:
#   SUBSTR/CAST/CONCAT/HSTORE_GET_VALUE)
# - SELECT/JOIN キーワード(サブクエリ)
# - ~ / @ / $ / % / `(QGIS式の正規表現・変数・剰余・ジオメトリ関数・
#   識別子引用。% は LIKE パターンのリテラル内のみ許可で裸の % は非対応)
# - 単独の |(where-eval.js は || 連結のみ対応。奇数連の | はビット演算等の
#   ため GeoJSON 焼き込みへ回す。偶数連=|| 連結は許可。
#   文字列リテラル内の | はスクラブ済みで誤検出しない)
_EVAL_UNSAFE_RE = re.compile(
    r'[~@$%`]|(?<!\|)\|(?:\|\|)*(?!\|)|\bselect\b|\bjoin\b|'
    r'\b(?!in\b|not\b|substr\b|cast\b|concat\b|hstore_get_value\b)'
    r'[\w.]+\s*\(',
    re.IGNORECASE)
_STRING_OR_IDENT_RE = re.compile(
    r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"")


def _subset_eval_ok(raw):
    """where-eval.js(クライアント評価)が解釈できる subset 式か。

    geojson:/flatgeobuf:/geoparquet: 行の where= は Canvas 側で
    全件読み込み後にクライアント評価されるため、SQL エンジンへ投げる
    gpkg:/duckdb: 系より文法が狭い。非対応構文を含む式は False を返し
    (呼び出し側は GeoJSON 変換へ回す)。文字列/識別子リテラル内の
    記号は誤検出しないよう除去してから判定する。
    """
    if not raw:
        return False
    scrub = _STRING_OR_IDENT_RE.sub("''", raw)
    return not _EVAL_UNSAFE_RE.search(scrub)


def _csv_geom_hints(path):
    """ローカル CSV/TSV のヘッダ行からジオメトリ列・経度/緯度列を推定する。

    戻り値 (geom_col, lon_col, lat_col)。読めなければ (None,None,None)。
    列名は Canvas 側の自動検出(geometry/geom/wkb/the_geom・lon/lat 慣用名)
    より広く、明示指定に使える名前(wkt/x/y)も拾う。
    """
    try:
        with open(path, 'rb') as f:
            raw = f.read(131072)
    except Exception:  # nosec B110  # 設計上の許容
        return None, None, None
    lines = raw.decode('utf-8-sig', errors='replace').splitlines()
    if not lines:
        return None, None, None
    head = lines[0]
    delim = max((',', ';', '\t', '|'), key=lambda d: head.count(d))
    names = [c.strip().strip('"').strip("'") for c in head.split(delim)]
    lower = {n.lower(): n for n in names if n}
    geom = next((lower[k] for k in
                 ('geometry', 'geom', 'wkt', 'wkb', 'the_geom')
                 if k in lower), None)
    lon = next((lower[k] for k in
                ('lon', 'lng', 'longitude', 'x') if k in lower), None)
    lat = next((lower[k] for k in
                ('lat', 'latitude', 'y') if k in lower), None)
    return geom, lon, lat


def _delimited_params(layer):
    """delimitedtext プロバイダのソースを (パスorURL, クエリparams) に分解。"""
    src = layer.source() or ''
    if '?' in src:
        path, _, qs = src.partition('?')
        params = {k.lower(): v for k, v in
                  urllib.parse.parse_qsl(qs, keep_blank_values=True)}
    else:
        path, params = src, {}
    return path, params


def _is_tiled_scene(layer):
    """QgsTiledSceneLayer(QGIS 3.34+ の 3D Tiles レイヤ)か。"""
    try:
        from qgis.core import QgsTiledSceneLayer
        return isinstance(layer, QgsTiledSceneLayer)
    except Exception:
        # 旧バージョン・独自型はプロバイダ名で判定
        # (QGIS3=tiled_scene / QGIS4=tiledscene・cesiumtiles・esrii3s)
        try:
            return (layer.providerType() or '') in (
                'tiled_scene', 'tiledscene', 'cesiumtiles', 'esrii3s')
        except Exception:  # nosec B110  # 設計上の許容
            return False


def _tiledscene_ref(layer, slug, data_dir, copied, warnings, write=True):
    """3D Tiles レイヤの参照先を返す。解決できなければ None。

    - http(s)/vsicurl URL → そのまま参照
    - ローカルの tileset.json(またはそのディレクトリ) → ディレクトリツリーを
      canvas_data/<slug>/ へ複製して canvas_data/<slug>/<basename> を返す
    write=False(非表示 base: 候補の参照のみ出力)時はリンク参照または
    既存複製の再利用のみ行い、新規複製が必要なら None。
    """
    src = layer.source() or ''
    m = re.search(r'(?:^|&)url=([^&]+)', src)
    target = urllib.parse.unquote(m.group(1)) if m else src.strip()
    if not target:
        return None
    if target.startswith('/vsicurl/'):
        target = target[len('/vsicurl/'):]
    if re.match(r'https?://', target):
        # Cesium tileset.json のみ対応(Esri i3s 等の SceneServer URL は除外)
        if target.split('?')[0].lower().endswith('.json'):
            return target
        return None
    path = _local_path(target)
    if os.path.isdir(path):
        base_dir, ts_path = path, os.path.join(path, 'tileset.json')
    else:
        base_dir, ts_path = os.path.dirname(path) or path, path
    if not os.path.isfile(ts_path):
        return None
    link = _link_ref(ts_path)
    if link:
        return link
    if write and \
            _tree_bytes(base_dir, _LOCAL_TREE_MAX_BYTES) \
            > _LOCAL_TREE_MAX_BYTES:
        warnings.append(
            '{0}: 3dtiles ディレクトリが {1} 超のため複製を中止'.format(
                layer.name(), _LOCAL_TREE_MAX_BYTES))
        return None
    if not _copy_tree_to_data(base_dir, data_dir, slug, copied, write=write):
        return None
    return _dref(data_dir, '{0}/{1}'.format(slug, os.path.basename(ts_path)))


def _local_xyz_template(url, slug, data_dir, copied, warnings, write=True):
    """ローカル XYZ テンプレート(file:///.../{z}/{x}/{y}.png)を canvas_data/ へ複製。

    戻り値 'canvas_data/<slug>/{z}/{x}/{y}.png' 形式の参照テンプレート。解決不可・
    サイズ超過時は None。write=False(非表示 base: 候補の参照のみ出力)時は
    リンク参照または既存複製の再利用のみ行い、新規複製が必要なら None。
    """
    path = _local_path(url)
    if '{z}' not in path:
        return None
    base, _, rest = path.partition('{z}')
    base_dir = base.rstrip('/\\')
    template = '{z}' + rest
    if not os.path.isdir(base_dir):
        return None
    link = _link_ref(base_dir)
    if link:
        return '{0}/{1}'.format(link, template.replace(os.sep, '/'))
    if write and \
            _tree_bytes(base_dir, _LOCAL_TREE_MAX_BYTES) \
            > _LOCAL_TREE_MAX_BYTES:
        warnings.append(
            '{0}: ローカルタイルツリーが {1} 超のため複製を中止'.format(
                slug, _LOCAL_TREE_MAX_BYTES))
        return None
    if not _copy_tree_to_data(base_dir, data_dir, slug, copied, write=write):
        return None
    return _dref(data_dir, '{0}/{1}'.format(slug, template.replace(os.sep, '/')))


def _maplayer_opacity(layer):
    """レイヤ不透明度(0-1)。1.0 または取得不可なら None。"""
    try:
        op = float(layer.opacity())
        return op if 0.0 <= op < 0.999 else None
    except Exception:  # nosec B110  # 設計上の許容
        return None


# QPainter::CompositionMode の値 → 名前(警告表示用)。
# 0=SourceOver(通常)以外は Canvas で再現できない
_BLEND_MODE_NAMES = {
    0: 'SourceOver', 1: 'DestinationOver', 2: 'Clear', 3: 'Source',
    4: 'Destination', 5: 'SourceIn', 6: 'DestinationIn', 7: 'SourceOut',
    8: 'DestinationOut', 9: 'SourceAtop', 10: 'DestinationAtop',
    11: 'Xor', 12: 'Plus', 13: 'Multiply', 14: 'Screen', 15: 'Overlay',
    16: 'Darken', 17: 'Lighten', 18: 'ColorDodge', 19: 'ColorBurn',
    20: 'HardLight', 21: 'SoftLight', 22: 'Difference', 23: 'Exclusion',
}

# ベクターレンダラ種別 → Canvas 側オプション。
# ヒートマップ/クラスタは QML スタイル変換ではなく .kasc の
# heat=on/cluster=on へマッピングする(Canvas 側の専用描画機構を使う)
_RENDERER_OPT_MAP = {
    'heatmaprenderer': {'heat': 'on'},
    'pointcluster': {'cluster': 'on'},
    'pointdisplacement': {'cluster': 'on'},
}

# Canvas で再現できないレンダラ種別 → 警告用の説明
_UNSUPPORTED_RENDERER_NAMES = {
    'invertedpolygonrenderer': '反転ポリゴン',
    '25drenderer': '2.5D',
    'embeddedsymbol': '埋め込みシンボル',
    'mergedfeaturerenderer': '結合地物',
    'nullsymbol': 'null シンボル(地物非表示)',
    'interpolated': '補間',
    'geometrygenerator': 'ジオメトリジェネレータ',
}


def _blend_warning(layer, warnings):
    """レイヤ/地物ブレンドモードが非標準なら警告を出す。

    QGIS の multiply/screen/overlay 等は Canvas 側で再現できないため
    (概ね通常描画になる)、ユーザーが認識できるよう warnings へ記録する。
    """
    for meth, label in (('blendMode', 'ブレンドモード'),
                        ('featureBlendMode', '地物ブレンドモード')):
        try:
            fn = getattr(layer, meth, None)
            if fn is None:
                continue
            bm = fn()
            val = int(bm.value if hasattr(bm, 'value') else bm)
        except Exception:  # nosec B112  # 設計上の許容
            continue
        if val and val != 0:
            warnings.append('{0}: {1} {2} は未対応(近似描画)'.format(
                layer.name(), label,
                _BLEND_MODE_NAMES.get(val, str(val))))


def _temporal_opts(layer, warnings):
    """時間対応(temporal)設定 → ``time=``/``time_end=``/``time_span=``。

    QgsVectorLayerTemporalProperties の mode 別に変換する:
    - InstantFromField        → time=<開始フィールド>
    - StartAndEndFromFields   → time=<開始> + time_end=<終了>
    - StartAndDurationFromFields → time=<開始>(期間フィールドは未対応→警告)
    - FromExpressions / FixedRange / RedrawOnly → 変換不能(警告 or 無視)
    """
    opts = {}
    try:
        tp = layer.temporalProperties()
    except Exception:  # nosec B110  # 設計上の許容
        return opts
    try:
        if not tp or not tp.isActive():
            return opts
        from qgis.core import QgsVectorLayerTemporalProperties as _T
        mode = tp.mode()
        if mode == _T.ModeFeatureDateTimeInstantFromField:
            if tp.startField():
                opts['time'] = tp.startField()
            else:
                warnings.append(
                    '{0}: 時間フィールド未設定'.format(layer.name()))
        elif mode == _T.ModeFeatureDateTimeStartAndEndFromFields:
            if tp.startField():
                opts['time'] = tp.startField()
            if tp.endField():
                opts['time_end'] = tp.endField()
            if not opts:
                warnings.append(
                    '{0}: 時間フィールド未設定'.format(layer.name()))
        elif mode == getattr(
                _T, 'ModeFeatureDateTimeStartAndDurationFromFields',
                object()):
            if tp.startField():
                opts['time'] = tp.startField()
            warnings.append(
                '{0}: 地物ごとの期間(durationField)は未対応'.format(
                    layer.name()))
        elif mode == getattr(
                _T, 'ModeFeatureDateTimeStartAndEndFromExpressions',
                object()):
            warnings.append(
                '{0}: 式ベースの時間設定は未対応'.format(layer.name()))
        elif mode == _T.ModeFixedTemporalRange:
            warnings.append(
                '{0}: 固定時間範囲はタイムスライダーへ変換不可'.format(
                    layer.name()))
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return opts


def _renderer_opts(layer, warnings):
    """ベクターレンダラ種別 → Canvas オプション(heat=/cluster=)。

    変換不能なレンダラ(反転ポリゴン/2.5D/ジオメトリジェネレータ等)は
    「最も近い表現へのフォールバック」となるため warnings に記録する。
    """
    opts = {}
    try:
        r = layer.renderer()
        rtype = (r.type() or '').strip().lower() if r else ''
    except Exception:  # nosec B110  # 設計上の許容
        return opts
    if rtype in _RENDERER_OPT_MAP:
        opts.update(_RENDERER_OPT_MAP[rtype])
    elif rtype in _UNSUPPORTED_RENDERER_NAMES:
        warnings.append('{0}: {1}レンダラは未対応(近似描画)'.format(
            layer.name(), _UNSUPPORTED_RENDERER_NAMES[rtype]))
    # シンボルレイヤ単位の未対応要素(ジオメトリジェネレータ)を拾う
    try:
        syms = []
        if r and hasattr(r, 'symbol'):
            s = r.symbol()
            if s is not None:
                syms = [s]
        if not syms and r and hasattr(r, 'symbols'):
            try:
                from qgis.core import QgsRenderContext
                syms = list(r.symbols(QgsRenderContext()) or [])
            except Exception:  # nosec B110  # 設計上の許容
                syms = []
        for s in syms:
            if s is None:
                continue
            try:
                for i in range(s.symbolLayerCount()):
                    lt = (s.symbolLayer(i).layerType() or '').strip()
                    if lt == 'GeometryGenerator':
                        warnings.append(
                            '{0}: ジオメトリジェネレータは未対応'
                            '(近似描画)'.format(layer.name()))
                        raise StopIteration
            except StopIteration:
                break
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return opts


def _layer_3d_opts(layer, warnings):
    """ベクターの3Dレンダラ(立ち上げ) → ``extrude=<m>``/``z=<m>``(#60)。

    QgsVectorLayer3DRenderer のシンボル(ポリゴン/ライン)が持つ
    extrusionHeight(立ち上げ高さ)と height(基準高さオフセット)を
    Canvas の extrudedHeight/height へ橋渡しする。renderer3D を持たない
    レイヤ・シンボル無し・読み取り失敗時は空dict。2.5D(2D側)レンダラは
    _renderer_opts 側の warnings 対象のままとする。
    """
    opts = {}
    try:
        r3d = layer.renderer3D()
        sym = r3d.symbol() if r3d is not None else None
    except Exception:  # nosec B110  # 設計上の許容
        return opts
    if sym is None:
        return opts
    try:
        ext = float(sym.extrusionHeight())
        if ext > 0:
            opts['extrude'] = '{0:g}'.format(ext)
    except Exception:  # nosec B110  # 設計上の許容
        pass
    try:
        h = float(sym.height())
        if h:
            opts['z'] = '{0:g}'.format(h)
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return opts


def _vector_opts_suffix(layer, warnings):
    """ベクター行(geojson:/gpkg: 等)共通の追加オプション文字列を返す。

    - 時間対応 → `` | time=<f>``/`` | time_end=<f>``/`` | time_span=<s>``
    - レンダラ種別 → `` | heat=on``/`` | cluster=on``
    - 3Dレンダラ立ち上げ → `` | extrude=<m>``/`` | z=<m>``
    - レイヤ不透明度 → `` | opacity=<0-1>``
    """
    opts = {}
    opts.update(_temporal_opts(layer, warnings))
    opts.update(_renderer_opts(layer, warnings))
    opts.update(_layer_3d_opts(layer, warnings))
    _blend_warning(layer, warnings)
    op = _maplayer_opacity(layer)
    if op is not None:
        opts['opacity'] = '{0:g}'.format(op)
    out = ''
    for key, val in opts.items():
        out += ' | {0}={1}'.format(key, _kasc_escape(val))
    return out


def _scale_vis_opt(layer):
    """QGIS の縮尺表示設定を `` | minScale= | maxScale=`` オプションにする。

    QgsMapLayer::minimumScale() は引き側限界(分母が大きい方)、
    maximumScale() は寄り側限界(分母が小さい方・0 は無制限)。
    Canvas 側は minScale → ズーム下限、maxScale → ズーム上限として
    解釈する(QGIS と同じ命名方向)。未設定時は空文字。
    """
    try:
        if not layer.hasScaleBasedVisibility():
            return ''
        lo = float(layer.minimumScale() or 0)
        hi = float(layer.maximumScale() or 0)
    except Exception:
        return ''
    out = ''
    if lo > 0:
        out += ' | minScale={0:g}'.format(lo)
    if hi > 0:
        out += ' | maxScale={0:g}'.format(hi)
    return out


def _layer_extent_bbox(layer):
    """レイヤ範囲を EPSG:4326 の 'w,s,e,n' 文字列に。全域相当/失敗時 None。"""
    try:
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsProject)
        ext = layer.extent()
        if not ext or not ext.isFinite() or ext.isEmpty():
            return None
        crs = layer.crs()
        if crs and crs.isValid() and crs.authid() != 'EPSG:4326':
            tr = QgsCoordinateTransform(
                crs, QgsCoordinateReferenceSystem('EPSG:4326'),
                QgsProject.instance())
            ext = tr.transform(ext)
        w, s, e, n = (ext.xMinimum(), ext.yMinimum(),
                      ext.xMaximum(), ext.yMaximum())
        if e - w >= 350.0 or n - s >= 170.0:
            return None
        return '{0:.6f},{1:.6f},{2:.6f},{3:.6f}'.format(w, s, e, n)
    except Exception:
        return None


# skipped 記録用の種別名 → ユーザー向け理由(#50)。
# 対象外レイヤ種別をサイレントに捨てないよう、理由を明示する
_SKIP_REASON_BY_CLASS = {
    'QgsMeshLayer': 'メッシュレイヤ(未対応)',
    'QgsVectorTileLayer': 'ベクタータイル(ローカル/URL参照不可)',
    'QgsPointCloudLayer': '点群レイヤ(未対応)',
    'QgsAnnotationLayer': 'アノテーションレイヤ(未対応)',
    'QgsPluginLayer': 'プラグインレイヤ(未対応)',
    'QgsGroupLayer': 'グループレイヤ(未対応)',
}


def _skip_reason(layer):
    """skipped 記録用の種別文字列(クラス名+プロバイダ、既知種別は和訳)。"""
    cls_name = type(layer).__name__
    if cls_name in _SKIP_REASON_BY_CLASS:
        return _SKIP_REASON_BY_CLASS[cls_name]
    prov = ''
    try:
        prov = layer.providerType() or ''
    except Exception:  # nosec B110  # 設計上の許容
        pass
    cls = cls_name.replace('Qgs', '')
    return '{0}({1})'.format(cls, prov) if prov else cls


def _vectortile_source(layer):
    """QgsVectorTileLayer のプロバイダ接続文字列を解析し、Canvas の
    mvt:/pmtiles: 行へ引き渡せるタイルソースを返す(#50)。
    戻り値 {'kind','url','zmin','zmax'}。URL参照できない
    (ローカル .mbtiles 等)場合は None → 呼び出し側は skipped へ回す。"""
    try:
        from qgis.core import QgsVectorTileLayer
        if not isinstance(layer, QgsVectorTileLayer):
            return None
    except Exception:  # nosec B110  # 設計上の許容
        return None
    try:
        from urllib.parse import unquote
        src = layer.source() or ''
    except Exception:  # nosec B110  # 設計上の許容
        return None
    # vectortile プロバイダの接続文字列は type=xyz&url=...&zmin=..&zmax=.. 形式
    params = {}
    for part in src.split('&'):
        k, _, v = part.partition('=')
        if k:
            params[k.strip().lower()] = unquote(v.strip())
    url = params.get('url') or ''
    if not url or not re.match(r'https?://', url):
        return None  # ローカル .mbtiles・file:// 等は canvas_data 複製せず未対応

    def _zi(key):
        try:
            return int(params[key]) if params.get(key) else None
        except Exception:  # nosec B110  # 設計上の許容
            return None
    zmin, zmax = _zi('zmin'), _zi('zmax')
    if url.lower().endswith('.pmtiles') or params.get('type') == 'pmtiles':
        return {'kind': 'pmtiles', 'url': url, 'zmin': zmin, 'zmax': zmax}
    if '{z}' in url and '{x}' in url and '{y}' in url:
        return {'kind': 'mvt', 'url': url, 'zmin': zmin, 'zmax': zmax}
    if url.lower().endswith('.json'):
        # TileJSON: Canvas 側が tiles[] を解決する
        return {'kind': 'mvt', 'url': url, 'zmin': zmin, 'zmax': zmax}
    return None


def _legend_node_line(node, title):
    """QgsLayerTreeLayer の legend カスタムプロパティ → legendnode: 行(#63)。
    凡例ノード順(legendNodeOrder)・ユーザーラベル(legendNodeUserLabel)・
    凡例表示名(legend/title-label)が既定と異なる場合のみ行を返す。"""
    try:
        from qgis.core import QgsMapLayerLegendUtils
        order = list(QgsMapLayerLegendUtils.legendNodeOrder(node) or [])
        labels = {}
        for i in order:
            lbl = QgsMapLayerLegendUtils.legendNodeUserLabel(node, i)
            if lbl:
                labels[i] = lbl
        try:
            title_label = node.customProperty('legend/title-label') or ''
        except Exception:  # nosec B110  # 設計上の許容
            title_label = ''
        custom_order = bool(order) and any(
            i != o for o, i in enumerate(order))
        if not custom_order and not labels and not title_label:
            return None
        line = 'legendnode: {0}'.format(_kasc_escape(title))
        if custom_order:
            line += ' | order={0}'.format(
                ','.join(str(i) for i in order))
        for i in sorted(labels):
            line += ' | label{0}={1}'.format(i, _kasc_escape(labels[i]))
        if title_label:
            line += ' | title={0}'.format(_kasc_escape(title_label))
        return line
    except Exception:  # nosec B110  # 設計上の許容
        return None


def _duckdb_target_ref(target, slug, data_dir, copied, write=True):
    """duckdb: 参照用に target(URL or ローカルパス)を ref へ変換する。"""
    if re.match(r'https?://', target):
        return target
    path = _local_path(target)
    if not path or not os.path.exists(path):
        return None
    return _link_ref(path) or _copy_to_data(
        path, data_dir, slug, copied, write=write)


# geotiff: 行へ回せるラスタファイルの拡張子(GeoTIFF/COG)
_GEOTIFF_EXTS = ('.tif', '.tiff', '.gtif', '.gtiff')


def _geotiff_layer_ref(layer, slug, data_dir, copied, write=True):
    """QgsRasterLayer のソースが GeoTIFF/COG なら参照を返す。

    - http(s)/vsicurl の .tif 系 → URL をそのまま参照(COG 前提)
    - ローカルの .tif 系 → canvas_data/ へコピーして相対参照
    それ以外のラスタ(WMS/仮想等)やファイル不在は None。
    write=False(非表示 base: 候補の参照のみ出力)時はリンク参照または
    既存コピーの再利用のみ行い、新規コピーが必要なら None。
    """
    try:
        from qgis.core import QgsRasterLayer
        if not isinstance(layer, QgsRasterLayer):
            return None
    except Exception:  # nosec B110  # 設計上の許容
        return None
    if (layer.providerType() or '').lower() != 'gdal':
        return None
    src = layer.source() or ''
    url = src.replace('/vsicurl/', '')
    if re.match(r'https?://', url):
        low = url.split('?')[0].lower()
        return url if low.endswith(_GEOTIFF_EXTS) else None
    path = _local_path(src)
    if not path or not path.lower().endswith(_GEOTIFF_EXTS):
        return None
    if not os.path.exists(path):
        return None
    return _link_ref(path) or _copy_to_data(
        path, data_dir, slug, copied, write=write)


# Canvas が直接参照できるベクター形式(拡張子 → .kasc 行タイプ)。
# geojson:/gpkg:/geoparquet:/flatgeobuf: は無変換ネイティブ、
# shp:/gpx:/kml:/gml:/topojson:/czml:/geojsonl:/igc: は Canvas 側の
# shared/vector-load.js が GeoJSON 正規化して全エンジンで描画する
# (いずれもこちらで GeoJSON 変換するより参照の方が高速・忠実)
_NATIVE_KINDS = {
    '.gpkg': 'gpkg', '.geojson': 'geojson', '.json': 'geojson',
    '.geoparquet': 'geoparquet', '.parquet': 'geoparquet',
    '.fgb': 'flatgeobuf', '.flatgeobuf': 'flatgeobuf',
    '.shp': 'shp', '.gpx': 'gpx', '.kml': 'kml', '.kmz': 'kmz',
    '.gml': 'gml', '.topojson': 'topojson', '.czml': 'czml',
    '.geojsonl': 'geojsonl', '.ndjson': 'ndjson', '.jsonl': 'jsonl',
    '.jsonfg': 'geojson',
    '.fgseq': 'geojsonseq', '.geojsonseq': 'geojsonseq',
    '.jsonseq': 'geojsonseq',
    '.igc': 'igc', '.esrijson': 'esrijson', '.arcgis': 'arcgis',
}

# 形式の仕様上 WGS84(lon/lat)固定で CRS チェック不要な拡張子
_CRS_FREE_EXTS = ('.geojson', '.json', '.jsonfg', '.gpx', '.kml', '.kmz', '.czml',
                  '.fgseq', '.geojsonseq', '.jsonseq')

# Shapefile を参照する際に一式コピーする sidecar 拡張子
_SHP_SIDECARS = ('.shp', '.dbf', '.shx', '.prj', '.cpg', '.sbn', '.sbx',
                 '.qpj', '.fix', '.qix')


def _copy_shp_set(src_path, data_dir, slug, copied, write=True):
    """Shapefile と sidecar を canvas_data/<slug><ext> 一式でコピーする。

    Canvas の ``shp:`` 行は shpjs が sidecar(.dbf/.shx/.prj 等)を自動取得
    するため、同名の拡張子群をまとめて複製する。戻り値は .shp の参照。
    link_files 時は原本の場所(sidecar は .shp と同居)を相対参照する。
    write=False(非表示 base: 候補の参照のみ出力)時は、全 sidecar の
    同一内容コピーが既にあれば参照を返し、1つでもコピーが必要なら None。
    """
    link = _link_ref(src_path)
    if link:
        return link
    src_abs = os.path.abspath(src_path)
    if src_abs in copied:
        return copied[src_abs]
    base = os.path.splitext(src_abs)[0]
    ref = None
    for e in _SHP_SIDECARS:
        p = base + e
        if not os.path.isfile(p):
            continue
        dest_abs = os.path.join(data_dir, slug + e)
        same = False
        try:
            same = os.path.samefile(p, dest_abs)
        except Exception:  # nosec B110  # 宛先未作成ならコピー対象
            pass
        if not same and not _same_data_copy(p, dest_abs):
            if not write:
                return None
            shutil.copy2(p, dest_abs)
        if e == '.shp':
            ref = _dref(data_dir, os.path.basename(dest_abs))
    if ref:
        copied[src_abs] = ref
    return ref


def _wfs_ref(layer):
    """WFS プロバイダソース → ``wfs:`` 行用参照 ``{type,ref,opts}``。

    QgsWFS の source URI(url=/typename=/version=/srsname=)を分解して
    Canvas の GetFeature GET 行へ写像する。url/typename が取れない・
    地理座標系でない・subsetString(WFS Filter XML)がある場合は
    None(変換へ回す)。
    """
    try:
        from qgis.core import QgsDataSourceUri
        uri = QgsDataSourceUri(layer.source() or '')
        url = uri.param('url') or ''
        typename = uri.param('typename') or ''
        version = uri.param('version') or ''
    except Exception:  # nosec B110  # URI パース失敗は変換へ
        return None
    if not url or not typename or not re.match(r'https?://', url):
        return None
    if _subset_raw(layer):
        return None
    if not _geo_equiv_crs(layer):
        return None
    opts = {'typename': typename}
    if version:
        opts['version'] = version
    return {'type': 'wfs', 'ref': url, 'opts': opts}


# ネイティブ参照できないベクターの変換出力形式(優先順)。
# FlatGeobuf = 空間インデックス付きバイナリで GeoJSON より小さく
# ブラウザでのデコードも速い(Canvas 全エンジン 〇)。Parquet は最小だが
# ドライバ非搭載環境があるため第2候補、GeoJSON は最終手段
_FALLBACK_DRIVERS = (
    ('FlatGeobuf', '.fgb', 'flatgeobuf'),
    ('Parquet', '.parquet', 'geoparquet'),
    ('GeoJSON', '.geojson', 'geojson'),
)


def _fallback_driver():
    """利用可能な変換出力ドライバを返す ``(driver, ext, kasc_type)``。"""
    try:
        from osgeo import ogr
        for drv, ext, kind in _FALLBACK_DRIVERS:
            if ogr.GetDriverByName(drv):
                return drv, ext, kind
    except Exception:  # nosec B110  # osgeo 非搭載環境は GeoJSON 固定
        pass
    return 'GeoJSON', '.geojson', 'geojson'


def _native_ref(layer, slug, data_dir, copied, warnings, write=True,
                file_ref=None):
    """Canvas が直接参照できるソースなら参照辞書を返す。

    戻り値: ``{'type': <kasc行タイプ>, 'ref': <参照>, 'opts': {k: v}}``、
    または ``{'skip_reason': <理由>}``(表示不能と確定)、不可時は None
    (呼び出し側でフォールバック変換に回す)。
    write=False(非表示 base: 候補の参照のみ出力)時はローカルファイルの
    新規コピーを行わず、リンク参照・既存コピーの再利用・URL参照のみ
    解決する(コピーが必要なら None → 呼び出し側はスキップ判定へ)。
    file_ref(path)->ref を渡すとローカルファイルをコピーせずその
    呼び出し結果を参照に使う(/live/file 配信等・live kasc 用)。
    Shapefile sidecar も同一経路で解決される前提のため呼び出し側が
    sidecar へのアクセスも保証すること。

    - http(s) ソース: 拡張子に応じて URL をそのまま参照
    - ローカルファイル: canvas_data/<slug><ext> へコピーして相対参照
    - delimitedtext / .csv,.tsv → ``duckdb:``(lon=/lat=/geom= 付き)
    - subsetString → 全ネイティブ形式で ``where=``。gpkg:/duckdb: 系は
      SQL実行、geojson:/flatgeobuf:/geoparquet: は Canvas 側
      where-eval.js のクライアント評価(_subset_eval_ok が通る式のみ。
      非対応式は FlatGeobuf 変換でフィルタを焼き込む)
    地理座標系でない場合は None(フォールバック変換へ回す)。
    """
    src = layer.source() or ''
    subset = _subset_filter(layer)
    subset_raw = _subset_raw(layer)

    # delimitedtext プロバイダ(CSV/TSV等) → duckdb:
    if (layer.providerType() or '') == 'delimitedtext':
        path, params = _delimited_params(layer)
        geom = params.get('wktfield') or None
        lon = params.get('xfield') or None
        lat = params.get('yfield') or None
        if not geom and not (lon and lat):
            return {'skip_reason': 'ジオメトリ列なし(属性テーブル)'}
        if not _geo_equiv_crs(layer):
            return None  # 再投影が必要 → ベクター変換
        ref = file_ref(path) if file_ref else _duckdb_target_ref(
            path, slug, data_dir, copied, write=write)
        if not ref:
            return None
        opts = {'format': 'tsv' if path.lower().endswith('.tsv') else 'csv'}
        if geom:
            opts['geom'] = geom
        else:
            opts['lon'] = lon
            opts['lat'] = lat
        if subset:
            opts['where'] = subset
        return {'type': 'duckdb', 'ref': ref, 'opts': opts}

    # http(s)/vsicurl ソース → 拡張子で行タイプ決定
    if re.match(r'https?://', src) or src.startswith('/vsicurl/'):
        url = src.replace('/vsicurl/', '')
        low = url.split('?')[0].lower()
        kind, ext = None, None
        for e, k in (tuple(_NATIVE_KINDS.items()) +
                     (('.csv', 'duckdb'), ('.tsv', 'duckdb'))):
            if low.endswith(e):
                kind, ext = k, e
                break
        if not kind:
            return None
        opts = {}
        if kind == 'duckdb':
            opts['format'] = 'tsv' if ext == '.tsv' else 'csv'
        if subset:
            if kind not in ('gpkg', 'duckdb') \
                    and not _subset_eval_ok(subset_raw):
                # where-eval 非対応式 → FlatGeobuf 変換でフィルタを焼き込む
                warnings.append(
                    '{0}: フィルタ式が where= 非対応のためベクター変換'.format(
                        layer.name()))
                return None
            opts['where'] = subset
        return {'type': kind, 'ref': url, 'opts': opts}

    # WFS プロバイダ → wfs: 行(Canvas が GetFeature を直接発行)
    if (layer.providerType() or '').lower() == 'wfs':
        return _wfs_ref(layer)

    # ローカルファイルソース
    src_path = _source_path(layer)
    if not src_path:
        return None
    ext = os.path.splitext(src_path)[1].lower()

    # ogr の区切りテキスト → duckdb:(ヘッダからジオメトリ/経緯度列を推定。
    # ogr CSV は CRS 情報を持たないため値はそのまま=再投影なし)
    if ext in _DUCKDB_TEXT_EXTS:
        geom, lon, lat = _csv_geom_hints(src_path)
        if not geom and not (lon and lat):
            return None
        opts = {'format': 'tsv' if ext == '.tsv' else 'csv'}
        if geom:
            opts['geom'] = geom
        else:
            opts['lon'] = lon
            opts['lat'] = lat
        if subset:
            opts['where'] = subset
        return {'type': 'duckdb',
                'ref': file_ref(src_path) if file_ref else
                (_link_ref(src_path) or _copy_to_data(
                    src_path, data_dir, slug, copied, write=write)),
                'opts': opts}

    kind = _NATIVE_KINDS.get(ext)
    if ext == '.json':
        # .json は GeoJSON とは限らない。先頭を読んで Topology なら
        # topojson: 行へ(QGIS は OGR TopoJSON ドライバで読む)
        try:
            with open(src_path, 'rb') as f:
                head = f.read(4096)
            if b'"Topology"' in head.replace(b' ', b'') \
                    or b'"Topology"' in head:
                kind = 'topojson'
        except Exception:  # nosec B110  # 読めなければ geojson 扱い
            pass
    if not kind and ext == '.zip':
        # zip 内に .shp があれば shp: 行(shpjs が zip を直接読める)
        try:
            import zipfile
            with zipfile.ZipFile(src_path) as z:
                if any(n.lower().endswith('.shp') for n in z.namelist()):
                    kind = 'shp'
        except Exception:  # nosec B110  # zip 破損等は変換へ
            pass
    if not kind:
        return None
    # GeoJSON/GPX/KML 等は仕様上 lon/lat のため CRS 不明でも同等扱いとする
    if ext not in _CRS_FREE_EXTS and ext != '.zip' \
            and not _geo_equiv_crs(layer):
        return None
    if subset:
        if kind == 'geoparquet':
            kind = 'duckdb'
        elif kind != 'gpkg' and not _subset_eval_ok(subset_raw):
            # where-eval 非対応式 → FlatGeobuf 変換でフィルタを焼き込む
            warnings.append(
                '{0}: フィルタ式が where= 非対応のためベクター変換'.format(
                    layer.name()))
            return None
    if ext == '.shp':
        # Shapefile は sidecar(.dbf/.shx/.prj 等)を一式コピー
        # (link_files 時は _copy_shp_set 内で原本相対参照へ切替。
        # file_ref 指定時は原本パス参照のみ=sidecar も同一経路で解決)
        ref = file_ref(src_path) if file_ref else _copy_shp_set(
            src_path, data_dir, slug, copied, write=write)
    else:
        ref = file_ref(src_path) if file_ref else (
            _link_ref(src_path) or _copy_to_data(
                src_path, data_dir, slug, copied, write=write))
    if not ref:
        return None
    opts = {}
    if kind == 'duckdb':
        opts['format'] = 'parquet'
    if kind == 'gpkg':
        m = re.search(r'layername=([^|&]+)', src)
        if m:
            opts['table'] = urllib.parse.unquote(m.group(1))
    if subset:
        opts['where'] = subset
    return {'type': kind, 'ref': ref, 'opts': opts}


def _per_layer_opt(spec, layer):
    """fields/where/limit 指定をレイヤ毎に解決する。

    dict 指定は ``{レイヤ名 または layer.id(): 値}`` で、該当キーが
    無ければ None(未指定)。dict 以外は全ベクターレイヤへ共通適用する
    値としてそのまま返す。
    """
    if isinstance(spec, dict):
        for key in (layer.name(), layer.id()):
            if key in spec:
                return spec[key]
        return None
    return spec


def _fields_list(value):
    """fields 指定(列名list またはカンマ区切りstr)を列名listへ正規化。"""
    if value is None:
        return None
    if isinstance(value, str):
        names = [s.strip() for s in value.split(',') if s.strip()]
    else:
        names = [str(s).strip() for s in value if str(s).strip()]
    return names or None


def _export_vector(layer, path, fields=None, where=None, limit=None,
                   driver='GeoJSON'):
    """ベクターレイヤを EPSG:4326 の指定形式へ書き出す。

    driver: ``'FlatGeobuf'``/``'Parquet'``/``'GeoJSON'`` 等の
        QgsVectorFileWriter ドライバ名。
    fields: 出力する属性名のリスト(未指定=全列)。
    where: QgsExpression 互換の式で出力地物を絞る
        (プロバイダフィルタ subsetString とは AND 適用)。
    limit: 出力地物数の上限(1以上の整数)。
    where/limit 指定時は条件適用済みの地物を memory レイヤへ実体化
    (materialize)してから書き出すため、どのソース形式でも絞り込みが
    出力データへ確実に反映される。戻り値は出力対象地物数。
    """
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsExpression,
                           QgsFeature, QgsFeatureRequest, QgsFields,
                           QgsField, QgsMemoryProviderUtils, QgsProject,
                           QgsVectorFileWriter)
    src = layer
    if where or limit is not None:
        req = QgsFeatureRequest()
        if where:
            expr = QgsExpression(str(where))
            if expr.hasParserError():
                raise RuntimeError(
                    'where 式のパースエラー: {0}'.format(
                        expr.parserErrorString()))
            req.setFilterExpression(str(where))
        if limit is not None:
            lim = int(limit)
            if lim <= 0:
                raise RuntimeError(
                    'limit は 1 以上の整数: {0}'.format(limit))
            req.setLimit(lim)
        src = layer.materialize(req)
    if driver == 'GeoJSON':
        # GeoJSON にはフィールド幅の概念がないが、Writer はソースの
        # フィールド定義(幅/精度)をそのまま使うため、GPKG 由来の
        # VARCHAR(255) 定義で 255 文字超の値が書き込みエラーになる。
        # 幅を除いた memory レイヤへ実体化してから書き出す。
        flds = QgsFields()
        for f in src.fields():
            nf = QgsField(f)
            nf.setLength(0)
            nf.setPrecision(0)
            flds.append(nf)
        mem = QgsMemoryProviderUtils.createMemoryLayer(
            'export', flds, src.wkbType(), src.crs())
        mem.startEditing()
        mem.addFeatures(
            [QgsFeature(f) for f in src.getFeatures()])
        mem.commitChanges()
        src = mem
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = driver
    options.fileEncoding = 'UTF-8'
    if fields:
        idxs, missing = [], []
        for name in fields:
            i = src.fields().lookupField(name)
            (idxs if i >= 0 else missing).append(
                i if i >= 0 else name)
        if missing:
            raise RuntimeError(
                'fields に存在しない列: {0}'.format(','.join(missing)))
        options.attributes = idxs
    options.ct = QgsCoordinateTransform(
        src.crs(), QgsCoordinateReferenceSystem('EPSG:4326'),
        QgsProject.instance())
    if hasattr(QgsVectorFileWriter, 'writeAsVectorFormatV3'):
        err, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            src, path, QgsProject.instance().transformContext(), options)
    else:
        err, msg = QgsVectorFileWriter.writeAsVectorFormatV2(
            src, path, QgsProject.instance().transformContext(), options)
    if err != QgsVectorFileWriter.NoError:
        raise RuntimeError('{0} export failed: {1} ({2})'.format(
            driver, err, msg))
    return int(src.featureCount())


def _export_qml(layer, path):
    """レイヤの現在スタイルを .qml として保存する。"""
    msg, ok = layer.saveNamedStyle(path)
    if not ok:
        raise RuntimeError('qml save failed: {0}'.format(msg))
    return path


# ---------------------------------------------------------------------------
# ユーザー関数の組込み式展開
#
# geo_userfunc の式関数は Python 実装のため Canvas 側では評価できない。
# 関数側が docstring に "@expr: <式>" 宣言を持つ場合、エクスポート時に
# .qml 内の呼出しを宣言式へ書き換え、配布物を組込み関数のみにする。
# 宣言の無い関数呼出しはそのまま残る(Canvas 側は警告+フォールバック)。
# ---------------------------------------------------------------------------


def _user_func_expansions():
    """geo_userfunc bridge の expansions() で展開宣言済み関数の
    テーブルを返す({name_lower: {args:[...], expr:...}})。"""
    try:
        from qgis.utils import plugins
        b = getattr(plugins.get('geo_userfunc'), 'bridge', None)
        fn = getattr(b, 'expansions', None)
        if not callable(fn):
            return {}
        d = json.loads(fn())
        out = {}
        for name, e in (d.get('expansions') or {}).items():
            if isinstance(e, dict) and e.get('expr'):
                out[str(name).lower()] = e
        return out
    except Exception:
        return {}


def _expr_line_offsets(src):
    off = [0]
    i = src.find('\n')
    while i >= 0:
        off.append(i + 1)
        i = src.find('\n', i + 1)
    return off


def _scan_expr_call(src, name_end):
    """関数名トークン直後の位置 name_end から ``(...)`` を走査し、
    ``(開き括弧index, 閉じ括弧の次位置, [(引数start,end), ...])`` を返す。
    文字列リテラル(''/"")・行/ブロックコメント・括弧ネストを考慮する。
    見つからない/閉じられない場合は None。
    """
    n = len(src)
    i = name_end
    while i < n and src[i] in ' \t\r\n':
        i += 1
    if i >= n or src[i] != '(':
        return None
    open_i = i
    i += 1
    depth = 1
    arg_spans = []
    arg_start = i
    while i < n:
        ch = src[i]
        if ch == "'" or ch == '"':
            q = ch
            i += 1
            while i < n:
                if src[i] == q:
                    if src[i + 1:i + 2] == q:
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
            continue
        if ch == '-' and src[i + 1:i + 2] == '-':
            j = src.find('\n', i)
            i = n if j < 0 else j + 1
            continue
        if ch == '/' and src[i + 1:i + 2] == '*':
            j = src.find('*/', i + 2)
            i = n if j < 0 else j + 2
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0:
                arg_spans.append((arg_start, i))
                return open_i, i + 1, arg_spans
        elif ch == ',' and depth == 1:
            arg_spans.append((arg_start, i))
            arg_start = i + 1
        i += 1
    return None


def _expand_user_func_expr(src, expansions, _depth=0):
    """式文字列 src 内の展開宣言済みユーザー関数呼出しを組込み式へ展開する。

    QgsExpression のノードスパンで関数名の位置を特定し、呼出し全体と
    引数区切りは _scan_expr_call で文字列走査する(ノードスパンは
    関数名トークンしか返さないため)。未宣言関数・パース失敗・
    位置不一致時はその箇所をそのまま残す。
    """
    from qgis.core import QgsExpression, QgsExpressionNode
    e = QgsExpression(src)
    if not e.isValid() or e.hasParserError():
        return src
    root = e.rootNode()
    if root is None:
        return src
    funcs = QgsExpression.Functions()
    line_off = _expr_line_offsets(src)

    def name_span(n):
        """関数ノードの名前トークンスパン(start, end) を src オフセットで返す。
        parserFirst/LastColumn は行内1始まり・last は排他端。
        スパン未取得ノード(0,0,0,0)は None。"""
        fl, fc, ll, lc = (n.parserFirstLine, n.parserFirstColumn,
                          n.parserLastLine, n.parserLastColumn)
        if fl < 1 or fc < 1 or ll > len(line_off) or fl > len(line_off):
            return None
        s = line_off[fl - 1] + fc - 1
        t = line_off[ll - 1] + lc - 1
        if s < 0 or t > len(src) or s >= t:
            return None
        return s, t

    def node_children(n):
        nt = n.nodeType()
        kids = []
        try:
            if nt == QgsExpressionNode.ntUnaryOperator:
                kids = [n.operand()]
            elif nt == QgsExpressionNode.ntBinaryOperator:
                kids = [n.opLeft(), n.opRight()]
            elif nt == QgsExpressionNode.ntInOperator:
                kids = [n.node()]
                if n.list() is not None:
                    kids += n.list().list()
            elif nt == QgsExpressionNode.ntCondition:
                for w in (n.conditions() or []):
                    for nm in ('whenExp', 'conditionExp', 'when'):
                        c = getattr(w, nm, None)
                        if callable(c):
                            try:
                                kids.append(c())
                            except Exception:  # nosec B110
                                pass
                            break
                    for nm in ('thenExp', 'thenExpression', 'value', 'then'):
                        c = getattr(w, nm, None)
                        if callable(c):
                            try:
                                kids.append(c())
                            except Exception:  # nosec B110
                                pass
                            break
                kids.append(n.elseExp())
            elif nt == QgsExpressionNode.ntIndexOperator:
                kids = [n.container(), n.index()]
            elif nt == QgsExpressionNode.ntBetweenOperator:
                kids = [n.node(), n.lowerBound(), n.higherBound()]
        except Exception:  # nosec B110  # 未知ノード型は子走査を諦めるだけ
            pass
        return [k for k in kids if k is not None]

    repl = []  # (start, end, new_text) src 上の絶対位置

    def walk(n):
        if n.nodeType() == QgsExpressionNode.ntFunction:
            try:
                name = funcs[n.fnIndex()].name()
            except Exception:  # nosec B110
                name = ''
            exp = expansions.get(str(name).lower())
            sp = name_span(n)
            call = _scan_expr_call(src, sp[1]) if sp else None
            args = n.args().list() if n.args() is not None else []
            if exp is not None and sp is not None and call is not None:
                # 名前位置の健全性: スパン文字列が関数名と一致するか
                frag_name = src[sp[0]:sp[1]].strip()
                arg_spans = call[2]
                if (len(arg_spans) == 1 and args
                        and not src[arg_spans[0][0]:arg_spans[0][1]].strip()):
                    arg_spans = []  # f() の空スパン
                if (frag_name.lower() == str(name).lower()
                        and len(arg_spans) == len(args)):
                    vals = [_expand_user_func_expr(
                        src[a:b], expansions, _depth + 1)
                        for a, b in arg_spans]
                    tmpl = str(exp.get('expr') or '')
                    for i, p in enumerate(exp.get('args') or []):
                        v = vals[i] if i < len(vals) else 'NULL'
                        tmpl = tmpl.replace('{' + str(p) + '}', v)
                    repl.append((sp[0], call[1], tmpl))
                    return
            # 展開しない/できない呼出し → 引数内の別関数だけ処理
            for a in args:
                walk(a)
            return
        for ch in node_children(n):
            walk(ch)

    walk(root)
    if not repl:
        return src
    out = src
    for s, t, v in sorted(repl, reverse=True):
        out = out[:s] + v + out[t:]
    # 展開式自身が別のユーザー関数を含む場合に備え反復
    if _depth < 4:
        nxt = _expand_user_func_expr(out, expansions, _depth + 1)
        if nxt != out:
            return nxt
    return out


def _xml_attr_escape(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;')
             .replace('>', '&gt;').replace('"', '&quot;')
             .replace('\r', '&#xd;').replace('\n', '&#xa;'))


# .qml 内の式を持つ属性: (タグ正規表現, 必要マーカー, 式属性名)
#   Option name="expression" — DD プロパティ/GeometryGenerator 等の式
#   Option name="geometryModifier" — ジオメトリジェネレータの式
#   rule filter="..." — ルールベースレンダラのフィルタ式
#   text-style fieldName + isExpression="1" — ラベル本文の式
#   heatmaprenderer weight_expression — ヒートマップ重み式
_QML_EXPR_TAGS = (
    (re.compile(r'<Option\b[^>]*>'),
     ('name="expression"', 'name="geometryModifier"'), 'value'),
    (re.compile(r'<rule\b[^>]*>'), None, 'filter'),
    (re.compile(r'<text-style\b[^>]*>'), ('isExpression="1"',), 'fieldName'),
    (re.compile(r'<heatmaprenderer\b[^>]*>', re.I), None, 'weight_expression'),
)


def _expand_user_funcs_in_qml(qml_path, warnings=None):
    """保存済み .qml 内の式属性を走査し、展開宣言済みユーザー関数呼出しを
    組込み式へ書き換える。geo_userfunc 未導入・宣言なしなら何もしない。"""
    expansions = _user_func_expansions()
    if not expansions:
        return
    try:
        with open(qml_path, 'r', encoding='utf-8') as f:
            xml = f.read()
    except OSError:
        return
    import html as _html
    state = {'n': 0}

    def patch(tag, attr):
        m = re.search(r'\b' + attr + r'="([^"]*)"', tag)
        if not m:
            return tag
        raw = _html.unescape(m.group(1))
        new = _expand_user_func_expr(raw, expansions)
        if new == raw:
            return tag
        state['n'] += 1
        return tag[:m.start(1)] + _xml_attr_escape(new) + tag[m.end(1):]

    for tag_re, markers, attr in _QML_EXPR_TAGS:
        def sub(m, ms=markers, a=attr):
            t = m.group(0)
            if ms is None:
                return patch(t, a)
            for mk in ms:
                if mk in t:
                    return patch(t, a)
            return t
        xml = tag_re.sub(sub, xml)

    if state['n']:
        with open(qml_path, 'w', encoding='utf-8') as f:
            f.write(xml)
        if warnings is not None:
            warnings.append(
                '{0}: ユーザー関数を組込み式へ展開({1}箇所)'.format(
                    os.path.basename(qml_path), state['n']))


# .qml 内で画像ファイルを参照するシンボルレイヤ。
# キーは class 属性値(小文字)、値はファイル参照を持つ prop 名(小文字)。
# QGIS 内蔵シンボルは transport/… 等の相対名や QGIS インストール先の
# 絶対パスのまま書き出され、canvas_data/ に実体が無いと Canvas 側は解決
# できない(円・単色へフォールバック)ため、複製して参照を書き換える
_QML_ASSET_KEYS = {
    'svgmarker': ('name', 'path'),
    'rastermarker': ('imagefile', 'file', 'path'),
    'svgfill': ('svgfile', 'file'),
    'rasterfill': ('imagefile', 'file'),
    'imagefill': ('imagefile', 'file'),
}

# ローカルファイル化できない参照(file: スキームは _local_path で処理する)
_REMOTE_ASSET_RE = re.compile(
    r'^(?:https?|data|base64|url|blob)[:;]', re.IGNORECASE)


def _qml_asset_props(layer_el, keys):
    """<layer> 要素内のファイル参照 prop を (element, value_attr) で yield。

    QGIS 3.28+/4 の ``<Option type="Map"><Option name= value=>`` 形式と
    旧形式 ``<prop k= v=>`` の両方に対応する。
    """
    keys = set(keys)
    for child in layer_el:
        if child.tag == 'Option':
            if (child.get('type') or '').strip().lower() == 'map':
                for opt in child:
                    if (opt.tag == 'Option' and
                            (opt.get('name') or '').strip().lower() in keys):
                        yield opt, 'value'
            elif (child.get('name') or '').strip().lower() in keys:
                yield child, 'value'
        elif (child.tag == 'prop' and
                (child.get('k') or '').strip().lower() in keys):
            yield child, 'v'


def _qgis_svg_search_paths():
    """QGIS の SVG 検索ディレクトリ一覧(内蔵+ユーザー登録)。"""
    from qgis.core import QgsApplication
    return [p for p in (QgsApplication.svgPaths() or []) if p]


def _resolve_svg_file(name):
    """SVG 参照名を実ファイルの絶対パスへ解決する。失敗時 None。

    svgSymbolNameToPath(name, resolver) が SVG 検索パス
    (内蔵+ユーザー登録)を探し、未解決時は入力名をそのまま返す
    (QGIS 4.0 実測)ため、isfile で実在を確定させる。
    """
    from qgis.core import QgsPathResolver, QgsSymbolLayerUtils
    full = QgsSymbolLayerUtils.svgSymbolNameToPath(name, QgsPathResolver())
    if full and os.path.isfile(full):
        return os.path.abspath(full)
    return None


def _resolve_asset_file(value, qml_dir, svg_dirs):
    """シンボルの画像参照値をローカルの実ファイルへ解決する。

    絶対パスはそのまま、相対名はプロジェクト dir → qml dir →
    SVG 検索パスの順で探す。見つからなければ None。
    """
    from qgis.core import QgsProject
    v = urllib.parse.unquote(str(value or '').strip())
    if not v:
        return None
    p = _local_path(v)
    if os.path.isabs(p):
        return os.path.abspath(p) if os.path.isfile(p) else None
    dirs = []
    proj_dir = QgsProject.instance().absolutePath()
    if proj_dir:
        dirs.append(proj_dir)
    dirs.append(qml_dir)
    dirs.extend(svg_dirs or [])
    for base in dirs:
        cand = os.path.normpath(os.path.join(base, p))
        if os.path.isfile(cand):
            return os.path.abspath(cand)
    return _resolve_svg_file(p)


def _export_qml_assets(qml_path, layer_slug, data_dir, used_names, copied,
                       warnings):
    """.qml が参照するシンボル画像(SVG/ラスタ)を canvas_data/ へ複製し参照を書き換える。

    QGIS 内蔵 SVG シンボルやユーザーのローカル画像は .qml に
    生パスのまま残り、Canvas 側は .qml のある canvas_data/ からしか解決
    できない。ここで参照ファイルを canvas_data/ へ複製し、.qml の値を
    canvas_data/ 内のファイル名へ書き換える。
    戻り値: 複製したファイル数。
    """
    # defusedxml を vendored 同梱し利用(実体宣言/外部参照をパーサ層で拒否)
    try:
        from .defusedxml import ElementTree as ET
    except ImportError:
        # スタンドアロン実行時(プラグインディレクトリを sys.path に追加)用
        from defusedxml import ElementTree as ET
    with open(qml_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()
    m = re.search(r'<!DOCTYPE[^>]*>', raw_text)
    doctype = m.group(0) if m else ''
    root = ET.fromstring(raw_text)
    qml_dir = os.path.dirname(qml_path)
    svg_dirs = None
    count = 0
    changed = False
    for layer_el in root.iter('layer'):
        keys = _QML_ASSET_KEYS.get(
            (layer_el.get('class') or '').strip().lower())
        if not keys:
            continue
        for el, attr in _qml_asset_props(layer_el, keys):
            raw = (el.get(attr) or '').strip()
            if not raw or _REMOTE_ASSET_RE.match(raw):
                continue
            if svg_dirs is None:
                svg_dirs = _qgis_svg_search_paths()
            src = _resolve_asset_file(raw, qml_dir, svg_dirs)
            if not src:
                warnings.append(
                    '{0}: シンボル画像が見つかりません: {1}'.format(
                        os.path.basename(qml_path), raw))
                continue
            slug = _slugify('{0}_{1}'.format(
                layer_slug,
                os.path.splitext(os.path.basename(src))[0]), used_names)
            rel = _copy_to_data(src, data_dir, slug, copied)
            el.set(attr, os.path.basename(rel))
            changed = True
            count += 1
    if changed:
        body = ET.tostring(root, encoding='unicode')
        with open(qml_path, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            if doctype:
                f.write(doctype + '\n')
            f.write(body)
    return count


def _xyz_layer_info(layer):
    """XYZタイル系ラスタレイヤなら (url, zmin, zmax) を返す。

    source URI は ``key=value&key=value`` 形式で url 値は
    パーセントエンコード済み(&を含まない)。値だけをunquoteすることで
    url内の ``x={x}&y={y}&z={z}`` を保持する。
    """
    try:
        if layer.providerType() not in ('wms',):
            return None
        src = layer.source() or ''
        if 'type=xyz' not in src and 'type%3Dxyz' not in src.lower():
            return None
        params = {}
        for part in src.split('&'):
            if '=' not in part:
                continue
            key, val = part.split('=', 1)
            params[key.strip().lower()] = urllib.parse.unquote(val.strip())
        url = params.get('url')
        if not url:
            return None

        def _num(name):
            try:
                return int(params[name])
            except Exception:
                return None
        return url, _num('zmin'), _num('zmax')
    except Exception:
        return None


def _wms_layer_info(layer):
    """QGIS の WMS ラスタレイヤ(type=xyz 以外)なら
    (base_url, layers_csv, styles_csv, format, version) を返す。

    source URI は ``key=value&key=value`` 形式で、layers=/styles= は
    繰り返し出る(レイヤ順を保持)。値はパーセントエンコード済み。
    ``wms:`` 行は GetMap を 256px タイルへ分解して参照するため、
    エンドポイントURLは生で渡し、レイヤ指定はオプションとして出す。
    """
    try:
        if layer.providerType() not in ('wms',):
            return None
        src = layer.source() or ''
        if 'type=xyz' in src or 'type%3Dxyz' in src.lower():
            return None
        params = {}
        lists = {}
        for part in src.split('&'):
            if '=' not in part:
                continue
            key, val = part.split('=', 1)
            key = key.strip().lower()
            val = urllib.parse.unquote(val.strip())
            if key in ('layers', 'styles'):
                lists.setdefault(key, []).append(val)
            else:
                params[key] = val
        url = params.get('url')
        if not url or not re.match(r'https?://', url):
            return None
        return (url,
                ','.join(lists.get('layers', [])),
                ','.join(lists.get('styles', [])),
                params.get('format') or '',
                params.get('version') or '')
    except Exception:
        return None


def _wmts_layer_info(layer):
    """QGIS の WMTS ラスタレイヤなら
    (url, layers_csv, styles_csv, tilematrixset, format, tilesize) を返す。

    WMS(GetMap) と違い、tileMatrixSet を持つソースは ``wmts:`` 行へ
    出力する(Canvas 側が KVP GetTile または RESTful テンプレートへ展開)。
    """
    try:
        if layer.providerType() not in ('wms',):
            return None
        src = layer.source() or ''
        if 'type=xyz' in src or 'type%3Dxyz' in src.lower():
            return None
        params = {}
        lists = {}
        for part in src.split('&'):
            if '=' not in part:
                continue
            key, val = part.split('=', 1)
            key = key.strip().lower()
            val = urllib.parse.unquote(val.strip())
            if key in ('layers', 'styles'):
                lists.setdefault(key, []).append(val)
            else:
                params[key] = val
        tms = params.get('tilematrixset')
        if not tms:
            return None
        url = params.get('url')
        if not url or not re.match(r'https?://', url):
            return None
        try:
            tilesize = int(params.get('tiledimensions') or 0) or None
        except Exception:  # nosec B110  # 設計上の許容
            tilesize = None
        return (url,
                ','.join(lists.get('layers', [])),
                ','.join(lists.get('styles', [])),
                tms, params.get('format') or '', tilesize)
    except Exception:
        return None


# 焼き付け PNG(レンダラ再現フォールバック)の長辺上限
_RASTER_BAKE_MAX_PX = 4096


def _raster_needs_bake(layer):
    """再現に「QGIS で描画済み PNG への焼き付け」が必要なラスタか。

    - multibandcolor: ``bands=`` で表現できるため対象外
    - singlebandgray: コントラスト強調(ストレッチ)ありなら焼き付け
    - paletted: パレット色は geotiff 参照で再現されないため焼き付け
    - それ以外(疑似カラー/ヒルシェード/等高線/未知のレンダラ): 焼き付け
    """
    try:
        r = layer.renderer()
        rtype = (r.type() or '').strip().lower() if r else ''
        if rtype in ('multibandcolor', ''):
            return False
        if rtype == 'singlebandgray':
            try:
                ce = r.contrastEnhancement()
                return (ce is not None and
                        int(ce.contrastEnhancementAlgorithm()) != 0)
            except Exception:  # nosec B110  # 設計上の許容
                return False
        return True
    except Exception:  # nosec B110  # 設計上の許容
        return False


def _raster_bands_opt(layer):
    """multibandcolor レンダラの band 選択 → 'r,g,b'。標準(1,2,3)なら None。"""
    try:
        r = layer.renderer()
        if not r or (r.type() or '').strip().lower() != 'multibandcolor':
            return None
        bands = [r.redBand(), r.greenBand(), r.blueBand()]
        if min(bands) < 1 or bands == [1, 2, 3]:
            return None
        return ','.join(str(b) for b in bands)
    except Exception:  # nosec B110  # 設計上の許容
        return None


def _render_raster_png(layer, png_path, warnings):
    """ラスタレイヤを現在の表示状態のまま PNG(透過)へ焼き付ける。

    レンダラ(疑似カラー・ヒルシェード・ストレッチ・パレット)・
    ブレンド・描画効果を含めて QGIS の見た目をそのまま保存し、
    ``image:`` 行で参照できるようにする。戻り値は EPSG:4326 の
    'w,s,e,n' bbox 文字列、失敗時 None。
    """
    try:
        from qgis.core import (QgsMapRendererSequentialJob,
                               QgsMapSettings)
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtGui import QColor
        ext = layer.extent()
        if not ext or not ext.isFinite() or ext.isEmpty():
            return None
        w_px = int(layer.width() or 0)
        h_px = int(layer.height() or 0)
        if w_px <= 0 or h_px <= 0:
            w_px, h_px = 1024, 1024
        scale = _RASTER_BAKE_MAX_PX / float(max(w_px, h_px))
        if scale < 1.0:
            w_px = max(1, int(w_px * scale))
            h_px = max(1, int(h_px * scale))
            warnings.append('{0}: 焼き付けPNGを {1}px 以内へ縮小'.format(
                layer.name(), _RASTER_BAKE_MAX_PX))
        settings = QgsMapSettings()
        settings.setLayers([layer])
        crs = layer.crs()
        if crs and crs.isValid():
            settings.setDestinationCrs(crs)
        settings.setExtent(ext)
        settings.setOutputSize(QSize(w_px, h_px))
        settings.setBackgroundColor(QColor(0, 0, 0, 0))
        job = QgsMapRendererSequentialJob(settings)
        job.start()
        job.waitForFinished()
        img = job.renderedImage()
        if img.isNull() or not img.save(png_path, 'PNG'):
            return None
        return _raster_bbox_str(layer)
    except Exception as e:
        warnings.append('{0}: ラスタ焼き付け失敗: {1}'.format(
            layer.name(), e))
        return None


def _raster_bbox_str(layer):
    """レイヤ範囲の EPSG:4326 'w,s,e,n' 文字列(焼き付けPNGのbboxと同値)。

    差分エクスポートで既存PNGを再利用する際に bbox= を再計算せずに
    復元するために使う(描画は行わない)。
    """
    try:
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsProject)
        ext = layer.extent()
        if not ext or not ext.isFinite() or ext.isEmpty():
            return None
        crs = layer.crs()
        if crs and crs.isValid() and crs.authid() != 'EPSG:4326':
            tr = QgsCoordinateTransform(
                crs, QgsCoordinateReferenceSystem('EPSG:4326'),
                QgsProject.instance())
            ext = tr.transformBoundingBox(ext)
        return '{0:.6f},{1:.6f},{2:.6f},{3:.6f}'.format(
            ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum())
    except Exception:  # nosec B110  # 設計上の許容
        return None


# ---- ベクター → XYZ タイル焼き付け ------------------------------------
# 大規模レイヤ・複雑スタイル(パターン系/ラスタ系/GeometryGenerator 等)は
# ブラウザ側の QML 再現で一致しきれないため、QGIS のレンダラで
# Web メルカトル XYZ タイルへ焼き付けて ``xyz:`` 行として出す。
# 照会・ベクタ表示用のデータ行(geojson: 等)は ``| off`` で併記する。
# レイヤ customProperty 'kasugai_render' で強制指定:
#   'xyz'    = 必ずタイル化 / 'vector' = タイル化しない
# 縮尺連動(hasScaleBasedVisibility)はズーム範囲へ変換し、
# 範囲内タイル数が _VECTOR_XYZ_TILE_CAP を超える間は maxZoom を下げる。

# featureCount がこの値以上ならタイル化対象(大規模レイヤ)
_VECTOR_XYZ_MIN_FEATURES = 2000
# 1レイヤの焼き付けズーム上限決定に使う「範囲内タイル数」の目安
_VECTOR_XYZ_TILE_CAP = 320
# 絶対上限(安全網)
_VECTOR_XYZ_TILE_HARD_CAP = 1500
# ブラウザ QML 再現が近似的なシンボルレイヤ → タイル化対象
_VECTOR_XYZ_SYM_COMPLEX = {
    'GeometryGenerator', 'VectorField', 'LinearReferencing', 'MaskMarker',
    'AnimatedMarker', 'RasterMarker',
    'LinePatternFill', 'PointPatternFill', 'RandomMarkerFill',
    'CentroidFill', 'GradientFill', 'ShapeburstFill',
    'SVGFill', 'RasterFill',
    'RasterLine', 'InterpolatedLine', 'Lineburst',
}
# ブラウザ再現が近似的なレンダラ(小文字比較) → タイル化対象
_VECTOR_XYZ_REN_COMPLEX = {
    'heatmaprenderer', 'pointcluster', 'pointdisplacement',
    'mergedfeaturerenderer', 'embeddedsymbol', '25drenderer',
    'invertedpolygonrenderer',
}


def _vector_needs_xyz(layer, feat_count):
    """ベクターレイヤを XYZ タイル焼き付けで出すべきか。

    パネルの「XYZ tiles」チェック(QSettings kasugai_xyz_tiles)が OFF
    なら常に False。レイヤ customProperty ``kasugai_render`` で
    ``xyz``/``vector`` の個別強制指定ができる。
    """
    try:
        mode = str(layer.customProperty(
            'kasugai_render', '') or '').strip().lower()
        if mode == 'vector':
            return False
        if mode == 'xyz':
            return True
    except Exception:  # nosec B110  # 設計上の許容
        pass
    if not get_xyz_tiles_enabled():
        return False
    try:
        if feat_count is not None and \
                int(feat_count) >= _VECTOR_XYZ_MIN_FEATURES:
            return True
    except Exception:  # nosec B110  # 設計上の許容
        pass
    try:
        r = layer.renderer()
    except Exception:  # nosec B110  # 設計上の許容
        r = None
    if not r:
        return False
    try:
        if (r.type() or '').strip().lower() in _VECTOR_XYZ_REN_COMPLEX:
            return True
    except Exception:  # nosec B110  # 設計上の許容
        pass
    found = set()

    def _walk_sym(sym):
        if not sym:
            return
        try:
            for sl in sym.symbolLayers():
                try:
                    found.add(sl.layerType())
                    _walk_sym(sl.subSymbol())
                except Exception:  # nosec B110  # 設計上の許容
                    pass
        except Exception:  # nosec B110  # 設計上の許容
            pass

    def _walk_rule(rule):
        if not rule:
            return
        try:
            _walk_sym(rule.symbol())
            for c in rule.children() or []:
                _walk_rule(c)
        except Exception:  # nosec B110  # 設計上の許容
            pass

    try:
        from qgis.core import QgsRenderContext
        for s in r.symbols(QgsRenderContext()) or []:
            _walk_sym(s)
    except Exception:  # nosec B110  # 設計上の許容
        pass
    try:
        _walk_rule(r.rootRule())
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return bool(found & _VECTOR_XYZ_SYM_COMPLEX)


def _scale_to_zoom(scale_denom):
    """縮尺分母 → Web メルカトルのズームレベル(0.28mm 物理ピクセル換算)。"""
    import math
    try:
        d = float(scale_denom or 0)
        if d <= 0:
            return None
        res = d * 0.00028
        return max(0.0, min(24.0, math.log2(156543.03392 / res)))
    except Exception:  # nosec B110  # 設計上の許容
        return None


def _vector_xyz_zooms(layer, ext3857, warnings=None):
    """焼き付けズーム範囲 (zmin, zmax)。

    基本はパネル設定の手動範囲(kasugai_xyz_zmin/zmax、既定 1-15)。
    レイヤの縮尺連動があればその範囲でさらに絞る(手動範囲との交差)。
    範囲内タイル数が _VECTOR_XYZ_TILE_CAP を超える間は zmax を下げる
    (削減した場合は warnings へ通知)。
    """
    import math
    zmin, zmax = get_xyz_zooms()
    try:
        if layer.hasScaleBasedVisibility():
            zs = _scale_to_zoom(layer.minimumScale())
            if zs is not None:
                zmin = max(zmin, int(math.floor(zs)))
            zi = _scale_to_zoom(layer.maximumScale())
            if zi is not None:
                zmax = min(zmax, int(math.ceil(zi)))
            if zmax < zmin:
                zmax = zmin
    except Exception:  # nosec B110  # 設計上の許容
        pass
    zmin = max(0, min(22, zmin))
    zmax = max(zmin, min(22, zmax))
    world = 2 * 20037508.3427892
    w = ext3857.xMaximum() - ext3857.xMinimum()
    h = ext3857.yMaximum() - ext3857.yMinimum()

    def _count(z):
        ts = world / (2 ** z)
        return (max(1, int(math.ceil(w / ts))) *
                max(1, int(math.ceil(h / ts))))

    zmax0 = zmax
    while zmax > zmin and _count(zmax) > _VECTOR_XYZ_TILE_CAP:
        zmax -= 1
    if zmax < zmax0 and warnings is not None:
        warnings.append(
            '{0}: タイル数上限のため焼き付けズームを z{1} まで縮小 '
            '(高ズーム側は未生成)'.format(layer.name(), zmax))
    return zmin, zmax


def _img_blank(img):
    """QImage が完全透明かを判定する(空タイルの保存スキップ用)。"""
    try:
        bits = img.constBits()
        if bits is not None:
            arr = bits.asarray(img.sizeInBytes())
            if not any(arr[3::4]):  # ARGB32: 4バイト目がアルファ
                return True
            return False
    except Exception:  # nosec B110  # 設計上の許容
        pass
    try:
        w, h = img.width(), img.height()
        for y in range(0, h, max(1, h // 16)):
            for x in range(0, w, max(1, w // 16)):
                if img.pixelColor(x, y).alpha():
                    return False
        return True
    except Exception:  # nosec B110  # 設計上の許容
        return False


def _render_vector_xyz(layer, slug, data_dir, warnings, zooms=None):
    """ベクターレイヤを QGIS レンダラで XYZ PNG タイルへ焼き付ける。

    戻り値は (urlテンプレート, zmin, zmax, bbox4326文字列, タイル数)、
    失敗時 None。完全透明タイルは保存しない。ラベル・データ定義・
    ペイント効果を含めた見た目がそのまま焼き付く。
    ベクター以外の QgsMapLayer(ラスタ/WMS 等)でも同じ経路で描画できる。

    zooms=(zmin, zmax) を渡すとズーム範囲を固定する。None(既定)は
    _vector_xyz_zooms(パネル設定+縮尺連動+タイル数上限)で決める。

    タイルを1枚ずつ描画すると遅いため、ズーム段ごとに
    最大 16x16 タイル(4096px)のチャンクで1回レンダリングして
    スライスする。縮尺依存の評価はズーム段ごとの画像に正しく効く。
    """
    import math
    try:
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform,
                               QgsLabelingEngineSettings,
                               QgsMapRendererSequentialJob,
                               QgsMapSettings,
                               QgsProject, QgsRectangle)
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtGui import QColor
    except Exception as e:
        warnings.append(
            '{0}: XYZ焼き付けの準備失敗: {1}'.format(layer.name(), e))
        return None
    ext = layer.extent()
    if not ext or not ext.isFinite() or ext.isEmpty():
        return None
    crs3857 = QgsCoordinateReferenceSystem('EPSG:3857')
    try:
        tr = QgsCoordinateTransform(
            layer.crs(), crs3857, QgsProject.instance())
        ext = tr.transformBoundingBox(ext)
    except Exception as e:
        warnings.append(
            '{0}: 範囲の EPSG:3857 変換失敗: {1}'.format(layer.name(), e))
        return None
    if zooms is not None:
        zmin, zmax = int(zooms[0]), int(zooms[1])
        zmin = max(0, min(22, zmin))
        zmax = max(zmin, min(22, zmax))
    else:
        zmin, zmax = _vector_xyz_zooms(layer, ext, warnings)
    out_root = os.path.join(data_dir, slug)
    world = 2 * 20037508.3427892
    rendered = 0
    stop = False
    for z in range(zmin, zmax + 1):
        if stop:
            break
        ts = world / (2 ** z)
        x0 = max(0, int(math.floor((ext.xMinimum() + world / 2) / ts)))
        x1 = min(2 ** z - 1,
                 int(math.floor((ext.xMaximum() + world / 2) / ts)))
        y0 = max(0, int(math.floor((world / 2 - ext.yMaximum()) / ts)))
        y1 = min(2 ** z - 1,
                 int(math.floor((world / 2 - ext.yMinimum()) / ts)))
        # 16x16 タイル(4096px)チャンク単位で一括描画→スライス
        for bx0 in range(x0, x1 + 1, 16):
            if stop:
                break
            bx1 = min(x1, bx0 + 15)
            for by0 in range(y0, y1 + 1, 16):
                if stop:
                    break
                by1 = min(y1, by0 + 15)
                wpx = (bx1 - bx0 + 1) * 256
                hpx = (by1 - by0 + 1) * 256
                xmin = bx0 * ts - world / 2
                ymin = world / 2 - (by1 + 1) * ts
                settings = QgsMapSettings()
                settings.setLayers([layer])
                settings.setDestinationCrs(crs3857)
                settings.setExtent(
                    QgsRectangle(xmin, ymin, xmin + (bx1 - bx0 + 1) * ts,
                                 ymin + (by1 - by0 + 1) * ts))
                settings.setOutputSize(QSize(wpx, hpx))
                settings.setBackgroundColor(QColor(0, 0, 0, 0))
                try:
                    settings.setLabelingEngineSettings(
                        QgsLabelingEngineSettings())
                except Exception:  # nosec B110  # 設計上の許容
                    pass
                # 大量地物レイヤ(メッシュ等)の低ズーム描画を速くする:
                # QGIS の描画簡略化(地物簡約+マージ)をチャンク描画へ有効化。
                # 見た目は QGIS キャンバスの既定簡略化と同等。
                try:
                    from qgis.core import Qgis
                    settings.setFlag(
                        Qgis.MapSettingsFlag.UseRenderingOptimization,
                        True)
                except Exception:  # nosec B110  # 設計上の許容
                    pass
                job = QgsMapRendererSequentialJob(settings)
                job.start()
                job.waitForFinished()
                img = job.renderedImage()
                if img.isNull() or _img_blank(img):
                    continue
                for tx in range(bx0, bx1 + 1):
                    if rendered >= _VECTOR_XYZ_TILE_HARD_CAP:
                        stop = True
                        break
                    for ty in range(by0, by1 + 1):
                        tile = img.copy((tx - bx0) * 256,
                                        (ty - by0) * 256, 256, 256)
                        if tile.isNull() or _img_blank(tile):
                            continue
                        d = os.path.join(out_root, str(z), str(tx))
                        if not os.path.isdir(d):
                            os.makedirs(d)
                        if tile.save(os.path.join(
                                d, str(ty) + '.png'), 'PNG'):
                            rendered += 1
                            if rendered >= _VECTOR_XYZ_TILE_HARD_CAP:
                                stop = True
                                break
    if not rendered:
        return None
    url = _dref(data_dir, '{0}/{{z}}/{{x}}/{{y}}.png'.format(slug))
    return url, zmin, zmax, _layer_extent_bbox(layer), rendered


def _write_xyz_index(data_dir, slug, zmin, zmax, bbox=None,
                     title=None):
    """焼き付けタイルを単体確認できる最小 Leaflet index.html を
    <slug>/index.html へ出力する(未生成の場合のみ。file:// 直開き・
    /export-data/ 配信のどちらでも動く相対参照)。
    戻り値: 書き込んだ場合 True。"""
    path = os.path.join(data_dir, slug, 'index.html')
    if os.path.isfile(path):
        return False
    t = title or slug
    if bbox and len(bbox) == 4:
        w, s, e, n = bbox
        fit = ('map.fitBounds([[{s},{w}],[{n},{e}]]);'
               .format(s=s, w=w, n=n, e=e))
    else:
        fit = ('map.setView([35.681, 139.767], {zmax});'
               .format(zmax=zmax))
    html = """<!doctype html>
<html><head><meta charset="utf-8">
<title>{t} — XYZ tile check</title>
<link rel="stylesheet"
 href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>html,body,#map{{height:100%;margin:0}}</style></head>
<body><div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var map = L.map('map');
L.tileLayer('./{{z}}/{{x}}/{{y}}.png', {{
  minZoom: {zmin}, maxZoom: {zmax},
  tms: false, attribution: 'QGIS-rendered XYZ bake: {t}'
}}).addTo(map);
{fit}
</script></body></html>
""".format(t=t, zmin=zmin, zmax=zmax, fit=fit)
    try:
        d = os.path.dirname(path)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html)
        return True
    except Exception:  # nosec B110  # 設計上の許容
        return False


def _dir_has_pngs(path):
    """ディレクトリ配下に .png が1枚以上あるか(焼き付け済み判定)。"""
    try:
        for _r, _d, files in os.walk(path):
            if any(f.lower().endswith('.png') for f in files):
                return True
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return False


def _reuse_vector_xyz(layer, slug, data_dir):
    """既存タイルツリーから (url,zmin,zmax,bbox,タイル数) を再構成する。

    差分エクスポート/再実行で未変更レイヤの焼き付けを省略する際に使う
    (描画は行わない)。
    """
    import re as _re
    out_root = os.path.join(data_dir, slug)
    zs, n = set(), 0
    try:
        for zname in os.listdir(out_root):
            if not _re.match(r'^\d+$', zname):
                continue
            zdir = os.path.join(out_root, zname)
            if not os.path.isdir(zdir):
                continue
            zs.add(int(zname))
            for _r, _d, files in os.walk(zdir):
                n += sum(1 for f in files if f.lower().endswith('.png'))
    except Exception:  # nosec B110  # 設計上の許容
        return None
    if not zs or not n:
        return None
    url = _dref(data_dir, '{0}/{{z}}/{{x}}/{{y}}.png'.format(slug))
    return url, min(zs), max(zs), _layer_extent_bbox(layer), n


# ---- 指定レイヤのみの XYZ 焼き付け(独立機能) ----------------------------
# パネルの XYZ タブ「Standalone XYZ export」が使う。.kasc 出力とは独立に
# チェックしたレイヤだけを <出力先>/xyz_tiles/<slug>/ へ焼き付け、
# 確認用 index.html を付ける。出力先は /export-data/ の配信ルート
# (last_export_dir=preferred_output_dir)配下なので、HTTP サーバ稼働時は
# /export-data/xyz_tiles/<slug>/index.html でブラウザ確認もできる。

def xyz_tiles_dir():
    """独立 XYZ 出力の既定ルート ``<preferred_output_dir()>/xyz_tiles/``。"""
    return os.path.join(preferred_output_dir(), 'xyz_tiles')


def export_layers_xyz(layers, out_dir=None, zmin=None, zmax=None,
                      add_to_project=False, progress_cb=None):
    """指定レイヤだけを QGIS レンダラで XYZ PNG タイルへ焼き付ける。

    ``.kasc`` エクスポートの自動焼き付け(_vector_needs_xyz 判定)とは
    独立した手動経路で、チェックしたレイヤを強制的にタイル化する
    (ベクター以外のラスタ/WMS レイヤも同じ経路で再焼き付けできる)。

    引数:
        layers: 焼き付け対象の QgsMapLayer リスト(空なら何もしない)。
        out_dir: 出力ルート。None(既定)は xyz_tiles_dir()
            (``<preferred_output_dir()>/xyz_tiles/``)。各レイヤは
            ``<root>/<slug>/{z}/{x}/{y}.png`` + ``index.html`` へ出力。
        zmin/zmax: 両方指定するとズーム範囲を固定。None なら
            _vector_xyz_zooms(パネルの Zoom 設定+縮尺連動+タイル数上限)。
        add_to_project: True なら焼き付けたタイルツリーを
            ``type=xyz`` の file:// ラスタレイヤとしてプロジェクトへ追加
            (結果を地図キャンバスで即確認できる)。
        progress_cb: ``progress_cb(done, total, name)``。各レイヤの
            処理開始時に呼ぶ(エクスポートと同じ契約)。
            ExportCancelled で中断できる。

    戻り値: {"root", "layers": [{name, slug, dir, url, zmin, zmax, bbox,
             tiles, index}], "skipped": [{name, reason}],
             "warnings": [...]}
    """
    warnings = []
    layers = [lyr for lyr in (layers or []) if lyr is not None]
    root = os.path.abspath(out_dir or xyz_tiles_dir())
    if not layers:
        return {'root': root, 'layers': [], 'skipped': [],
                'warnings': warnings}
    if not os.path.isdir(root):
        os.makedirs(root)
    zooms = None
    try:
        if zmin is not None and zmax is not None:
            zooms = (int(zmin), int(zmax))
    except Exception:  # nosec B110  # 不正値は自動範囲へフォールバック
        zooms = None
    used = set()
    total = len(layers)
    out_layers = []
    skipped = []
    for i, layer in enumerate(layers):
        if progress_cb is not None:
            progress_cb(i, total, layer.name())
        slug = _slugify(layer.name(), used)
        info = _render_vector_xyz(layer, slug, root, warnings,
                                  zooms=zooms)
        if not info:
            skipped.append({
                'name': layer.name(),
                'reason': 'render produced no tiles (empty extent or '
                          'all tiles transparent)'})
            continue
        url, rzmin, rzmax, bb, n_tiles = info
        # 完全透明タイルは保存しない仕様のため url テンプレートと
        # 実ディレクトリは一致する(slug 直下に {z}/{x}/{y}.png)
        entry = {
            'name': layer.name(), 'slug': slug,
            'dir': os.path.join(root, slug),
            'url': url, 'zmin': rzmin, 'zmax': rzmax,
            'bbox': bb, 'tiles': n_tiles,
        }
        # 単体確認用の最小 Leaflet ページ(既存は温存)
        try:
            _bb = [float(v) for v in str(bb or '').split(',')]
            if _write_xyz_index(root, slug, rzmin, rzmax,
                                _bb if len(_bb) == 4 else None,
                                title=layer.name()):
                entry['index'] = os.path.join(root, slug, 'index.html')
        except Exception:  # nosec B110  # 表示用HTMLの失敗は無視
            pass
        out_layers.append(entry)
        if add_to_project:
            try:
                _add_xyz_to_project(layer, entry)
            except Exception as e:  # nosec B110  # 追加失敗は警告のみ
                warnings.append(
                    '{0}: XYZ レイヤのプロジェクト追加失敗: {1}'.format(
                        layer.name(), e))
    if progress_cb is not None:
        progress_cb(total, total, '')
    return {'root': root, 'layers': out_layers, 'skipped': skipped,
            'warnings': warnings}


def _add_xyz_to_project(src_layer, entry):
    """焼き付けたタイルツリーを type=xyz ラスタレイヤとして追加する。

    file:// テンプレートのため移動・配布はできないが、QGIS 上で
    焼き付け結果をそのまま重ねて確認できる。元レイヤ名の末尾に
    ' (XYZ)' を付けて追加する。
    """
    from qgis.core import QgsProject, QgsRasterLayer
    path = entry['dir'].replace('\\', '/')
    uri = ('type=xyz&url=file:///{0}/{{z}}/{{x}}/{{y}}.png'
           '&zmin={1}&zmax={2}').format(
               path, entry['zmin'], entry['zmax'])
    rl = QgsRasterLayer(
        uri, '{0} (XYZ)'.format(src_layer.name()), 'wms')
    if not rl.isValid():
        raise RuntimeError('invalid xyz layer uri')
    QgsProject.instance().addMapLayer(rl)


def _camera_line(iface, height_hint_scale=None):
    """現在キャンバスから cam: 行を作る。失敗時 None。"""
    try:
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsPointXY,
                               QgsProject)
        canvas = iface.mapCanvas()
        ext = canvas.extent()
        crs = canvas.mapSettings().destinationCrs()
        tr = QgsCoordinateTransform(
            crs, QgsCoordinateReferenceSystem('EPSG:4326'),
            QgsProject.instance())
        c = tr.transform(QgsPointXY(ext.center().x(), ext.center().y()))
        scale = float(canvas.scale() or 10000)
        # 概算: 画面高~800px * 0.28mm/px * scale を地上高、
        # Cesium fov60° より h ≒ 地上高/1.15 → scale*0.2
        h = max(120.0, scale * 0.2)
        line = 'cam:QGIS|{0:.6f}|{1:.6f}|h={2:.0f}|p=-90'.format(
            c.y(), c.x(), h)
        try:
            rot = float(canvas.rotation())
            if abs(rot) > 0.01:
                line += '|d={0:.1f}'.format(rot % 360)
        except Exception:  # nosec B110  # 設計上の許容
            pass
        return line
    except Exception:
        return None


def _project_xml_root(project):
    """プロジェクトファイル(.qgs/.qgz)を ElementTree root で返す。"""
    fname = project.fileName() or ''
    if not fname or not os.path.exists(fname):
        return None
    try:
        if fname.lower().endswith('.qgz'):
            import zipfile
            with zipfile.ZipFile(fname) as zf:
                names = [n for n in zf.namelist()
                         if n.lower().endswith('.qgs')]
                if not names:
                    return None
                data = zf.read(names[0])
        else:
            with open(fname, 'rb') as f:
                data = f.read()
        try:
            from .defusedxml import ElementTree as ET
        except ImportError:
            from defusedxml import ElementTree as ET
        return ET.fromstring(data)
    except Exception:  # nosec B110  # 設計上の許容
        return None


def _qgis3d_color_hex(value):
    """QGIS 色文字列 'r,g,b,a,rgb:…' / '#rrggbb' → '#RRGGBB'(失敗時 None)。"""
    if not value:
        return None
    value = str(value).strip()
    if value.startswith('#'):
        return value[:7]
    try:
        parts = [int(float(p.strip())) for p in value.split(',')[:3]]
        if len(parts) == 3 and all(0 <= p <= 255 for p in parts):
            return '#{0:02X}{1:02X}{2:02X}'.format(*parts)
    except (TypeError, ValueError):
        pass
    return None


# ---- 3Dビュー(ローカル/グローブ) → cam:/fly_geojson: 行 ----------------

_WGS84_A = 6378137.0
_WGS84_E2 = (1.0 / 298.257223563) * (2.0 - 1.0 / 298.257223563)


def _ecef_to_geodetic(x, y, z):
    """ECEF(m) → (lat_deg, lon_deg, 楕円体高 m)。WGS84 閉形式+反復。"""
    p = math.hypot(x, y)
    if p < 1e-9:
        return (math.copysign(90.0, z), 0.0,
                abs(z) - _WGS84_A * math.sqrt(1.0 - _WGS84_E2))
    lon = math.atan2(y, x)
    lat = math.atan2(z, p * (1.0 - _WGS84_E2))
    for _ in range(5):
        n = _WGS84_A / math.sqrt(1.0 - _WGS84_E2 * math.sin(lat) ** 2)
        lat = math.atan2(z + _WGS84_E2 * n * math.sin(lat), p)
    n = _WGS84_A / math.sqrt(1.0 - _WGS84_E2 * math.sin(lat) ** 2)
    return math.degrees(lat), math.degrees(lon), p / math.cos(lat) - n


def _camera_offset_enu(dist, pitch_deg, yaw_deg):
    """QGIS 3Dカメラ姿勢 → 注視点からカメラへの ENU オフセット (E,N,U) m。

    ``QgsCameraPose::updateCamera``(ローカル)/``updateCameraGlobe``(グローブ)
    の分解: 高さ成分は ``dist*cos(pitch)``、水平成分は ``dist*sin(pitch)``、
    カメラは注視点から見て方位 ``(180-yaw)``° に位置する
    (``E=g*sin(yaw), N=-g*cos(yaw)``)。pitch: 0=真上俯瞰, 90=水平。
    """
    p, h = math.radians(pitch_deg), math.radians(yaw_deg)
    g = dist * math.sin(p)
    return g * math.sin(h), -g * math.cos(h), dist * math.cos(p)


def _camera_geodetic(x, y, z, dist, pitch, yaw, wgs3, globe):
    """注視点(シーン座標)+姿勢 → カメラの (lat, lon, h)。失敗時 None。"""
    e, n, u = _camera_offset_enu(dist, pitch, yaw)
    if not globe:
        return wgs3(x + e, y + n, z + u)
    lat_c, lon_c, _h_c = wgs3(x, y, z)
    clat, clon = math.radians(lat_c), math.radians(lon_c)
    # 注視点でのローカル ENU 基底(ECEF での単位ベクトル)
    up = (math.cos(clat) * math.cos(clon),
          math.cos(clat) * math.sin(clon), math.sin(clat))
    east = (-math.sin(clon), math.cos(clon), 0.0)
    north = (-math.sin(clat) * math.cos(clon),
             -math.sin(clat) * math.sin(clon), math.cos(clat))
    cx = x + e * east[0] + n * north[0] + u * up[0]
    cy = y + e * east[1] + n * north[1] + u * up[1]
    cz = z + e * east[2] + n * north[2] + u * up[2]
    return _ecef_to_geodetic(cx, cy, cz)


def _cam_3d_line(name, lat, lon, h, pitch, yaw):
    """cam:QGIS3D 行。h=楕円体高, p=QGIS pitch→Cesium pitch(pitch-90),
    d=視線方位(360-yaw)。QGIS yaw は反時計回り(数学的正方向)のため
    視線方位は ``-yaw`` になる(updateCamera* の ENU 分解より)。"""
    return ('cam:QGIS3D {0}|{1:.6f}|{2:.6f}|h={3:.0f}'
            '|p={4:.1f}|d={5:.1f}').format(
                _kasc_escape(name), lat, lon, max(1.0, h),
                pitch - 90.0, (-yaw) % 360.0)


def _scene_crs_authid(view):
    """<view><qgis3d><crs> 要素からシーンCRS の authid を取る。"""
    crs_el = view.find('qgis3d/crs')
    if crs_el is None:
        return None
    for el in crs_el.iter():
        if el.tag == 'authid' and el.text and el.text.strip():
            return el.text.strip()
    return None


def _scene_transformer(view, project, warnings):
    """ビューのシーン座標→測地変換 ``wgs3(x,y,z)->(lat,lon,h)`` と
    グローブ(地心系)フラグを返す。

    - シーンCRSが地心系(グローブ: EPSG:4978 等) → ECEF→測地(WGS84
      閉形式。非WGS84系は QgsCoordinateTransform→EPSG:4979)
    - EPSG:4326 → 恒等
    - その他ローカルシーン → QgsCoordinateTransform(シーンCRS→4326)
      で (x,y) 変換、z は高さとしてそのまま返す
    """
    authid = _scene_crs_authid(view)
    has_qgis = False
    try:
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsPoint,
                               QgsPointXY, Qgis)
        has_qgis = True
    except Exception:  # nosec B110  # qgis 無し環境(単体テスト)の許容
        pass
    scene_crs = None
    if has_qgis:
        try:
            scene_crs = (QgsCoordinateReferenceSystem(authid)
                         if authid else project.crs())
            if scene_crs is not None and not scene_crs.isValid():
                scene_crs = None
        except Exception:  # nosec B110  # 設計上の許容
            scene_crs = None
    globe = False
    if scene_crs is not None:
        try:
            globe = scene_crs.type() == Qgis.CrsType.Geocentric
        except Exception:  # nosec B110  # 設計上の許容
            globe = False
    if not globe and (authid or '').upper() == 'EPSG:4978':
        globe = True  # qgis 無し/判定失敗時のフォールバック
    if globe:
        if not has_qgis or scene_crs is None \
                or (authid or '').upper() == 'EPSG:4978':
            return _ecef_to_geodetic, True
        try:
            tr = QgsCoordinateTransform(
                scene_crs,
                QgsCoordinateReferenceSystem('EPSG:4979'), project)

            def f(x, y, z):
                pt = tr.transform(QgsPoint(x, y, z))
                return pt.y(), pt.x(), pt.z()
            return f, True
        except Exception as e:
            warnings.append('3Dビュー: ECEF変換失敗({0})、'
                            'WGS84近似で処理: {1}'.format(authid, e))
            return _ecef_to_geodetic, True
    if (authid or '').upper() == 'EPSG:4326':
        return (lambda x, y, z: (y, x, z)), False
    if not has_qgis:
        if not authid:
            return (lambda x, y, z: (y, x, z)), False
        warnings.append('3Dビュー: qgis 未検出のためシーンCRS {0} を'
                        '4326とみなします'.format(authid))
        return (lambda x, y, z: (y, x, z)), False
    try:
        if scene_crs is None:
            scene_crs = QgsCoordinateReferenceSystem(authid)
        tr = QgsCoordinateTransform(
            scene_crs, QgsCoordinateReferenceSystem('EPSG:4326'), project)

        def f(x, y, z):
            try:
                pt = tr.transform(QgsPoint(x, y, z))
                return pt.y(), pt.x(), pt.z()
            except Exception:
                pt = tr.transform(QgsPointXY(x, y))
                return pt.y(), pt.x(), z
        return f, False
    except Exception as e:
        warnings.append('3Dビュー: シーンCRS {0} の変換を'
                        '作成できず座標をそのまま使います: {1}'.format(
                            authid or project.crs().authid(), e))
        return (lambda x, y, z: (y, x, z)), False


def _anim3d_fly_line(view, name, wgs3, globe, data_dir, used_names,
                     warnings):
    """<animation3d><keyframe> 列 → fly_geojson: 行 + canvas_data/*.geojson。

    キーフレームは ``lookingAtMapPoint``(注視点・シーン座標)+姿勢で保持
    されるため、各キーフレームのカメラ位置を _camera_geodetic で求めて
    フライパス(カメラ軌道)にする。speed はカメラ軌道の3D総延長を
    アニメーション時間で割った m/s。キーフレーム2未満は行を返さない。
    """
    anim = view.find('animation3d')
    if anim is None:
        return None
    keyframes = anim.findall('keyframes/keyframe')
    if len(keyframes) < 2:
        return None
    coords, times = [], []
    for kf in keyframes:
        try:
            x = float(kf.get('x'))
            y = float(kf.get('y'))
            z = float(kf.get('z') or 0.0)
            dist = float(kf.get('dist') or 0)
            pitch = float(kf.get('pitch') or 0)
            yaw = float(kf.get('yaw') or 0)
            t = float(kf.get('time') or 0)
        except (TypeError, ValueError):
            continue
        if dist <= 0:
            continue
        try:
            lat, lon, h = _camera_geodetic(
                x, y, z, dist, pitch, yaw, wgs3, globe)
        except Exception:  # nosec B112  # 設計上の許容
            continue
        coords.append([round(lon, 6), round(lat, 6),
                       int(round(max(1.0, h)))])
        times.append(t)
    if len(coords) < 2:
        return None
    legs = []
    for i in range(len(coords) - 1):
        a, b = coords[i], coords[i + 1]
        legs.append(math.hypot(_fly_leg_dist_m(a, b), b[2] - a[2]))
    total = sum(legs)
    duration = max(times) - min(times)
    speed = (total / duration) if duration > 0.5 and total > 0 else None
    if speed is None or speed <= 0 or speed > 10000:
        speed = _fly_auto_speed_ms(total)
    speed = round(speed, 1)
    step = int(round(total / max(1, len(coords) - 1))) or 100
    title = 'QGIS3D {0}'.format(name)
    slug = _slugify('anim3d_{0}'.format(name), used_names)
    gj = {
        'type': 'FeatureCollection',
        'features': [{
            'type': 'Feature',
            'properties': {
                'name': title,
                'source': 'qgis3dAnimation',
                'view': name,
                'keyframes': len(coords),
                'duration': round(duration, 2),
                'heightReference': 'MSL',
                'fly': {
                    'speed': speed, 'height': 0, 'step': step,
                    'loop': False, 'view': 'camera',
                },
            },
            'geometry': {
                'type': 'LineString',
                'coordinates': coords,
            },
        }],
    }
    path = os.path.join(data_dir, slug + '.geojson')
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(gj, f, ensure_ascii=False)
    except Exception as e:
        warnings.append('3Dビュー {0}: アニメgeojson書込失敗: {1}'.format(
            name, e))
        return None
    return ('fly_geojson: {0} | ' + _dref(data_dir, '{1}.geojson') + ' | speed={2} '
            '| view=camera | step={3}').format(
                _kasc_escape(title), slug, speed, step)


def _threed_lines(project, warnings, data_dir=None, used_names=None):
    """保存済み3Dビュー(<mapViewDocks3D><view>) → cam:/terrain:/scene3d:/light:/fly_geojson: 行一覧。

    3D カメラは注視点(xMap,yMap,zMap=シーンCRS, dist=視線距離, pitch,
    yaw)で保持される。カメラ位置は注視点からの ENU オフセット
    (E=dist*sin(p)*sin(yaw), N=-dist*sin(p)*cos(yaw), U=dist*cos(p))
    で求め ``cam:QGIS3D <名前>|lat|lon|h=|p=|d=`` として出力する
    (2D の cam: と分離するため名前を前置)。シーンCRSはビューごとの
    <qgis3d><crs> を使い、地心系(グローブ・QGIS4)は ECEF→測地変換する。
    地形設定は ``terrain:`` 行、シーン画面設定(背景色/スカイボックス/
    影/SSAO/EDL・グローブ時は globe=on)は ``scene3d:`` 行、平行光源は
    ``light:`` 行(シーン座標の光源方向ベクトル→方位/仰角)。
    <animation3d> キーフレームはカメラ軌道を ``fly_geojson:`` 行 +
    canvas_data/anim3d_*.geojson として出力する(#60)。
    """
    out = []
    root = _project_xml_root(project)
    if root is None:
        return out
    try:
        for view in root.iter('view'):
            name = view.get('name') or '3D'
            cam_el = view.find('camera')
            if cam_el is None:
                continue
            try:
                x = float(cam_el.get('xMap'))
                y = float(cam_el.get('yMap'))
                z = float(cam_el.get('zMap') or 0)
                dist = float(cam_el.get('dist') or 0)
                pitch = float(cam_el.get('pitch') or 0)
                yaw = float(cam_el.get('yaw') or 0)
            except (TypeError, ValueError):
                continue
            if dist <= 0:
                continue
            wgs3, globe = _scene_transformer(view, project, warnings)
            try:
                lat, lon, h = _camera_geodetic(
                    x, y, z, dist, pitch, yaw, wgs3, globe)
                out.append(_cam_3d_line(name, lat, lon, h, pitch, yaw))
            except Exception as e:
                warnings.append(
                    '3Dビュー {0}: カメラ変換失敗: {1}'.format(name, e))
            if data_dir is not None and used_names is not None:
                try:
                    line = _anim3d_fly_line(
                        view, name, wgs3, globe, data_dir, used_names,
                        warnings)
                    if line:
                        out.append(line)
                except Exception as e:
                    warnings.append(
                        '3Dビュー {0}: アニメ出力失敗: {1}'.format(name, e))
            qgis3d = view.find('qgis3d')
            if qgis3d is None:
                continue
            # 地形(ジェネレータ/垂直誇張/オフセット/陰影) → terrain: 行。
            # 既定(dem・誇張1・オフセット0・陰影off)と同じ内容は出さない
            terr = qgis3d.find('terrain')
            if terr is not None:
                try:
                    opts = []
                    gen = terr.find('generator')
                    gtype = (gen.get('type') or '').strip() \
                        if gen is not None else ''
                    try:
                        ex = float(terr.get('exaggeration') or 1.0)
                    except (TypeError, ValueError):
                        ex = 1.0
                    try:
                        off = float(terr.get('elevation-offset') or 0.0)
                    except (TypeError, ValueError):
                        off = 0.0
                    if abs(ex - 1.0) > 0.001:
                        opts.append('exaggeration={0:g}'.format(ex))
                    if abs(off) > 0.001:
                        opts.append('offset={0:g}'.format(off))
                    if terr.get('shading-enabled') == '1':
                        opts.append('shading=on')
                    if gtype and (gtype != 'dem' or opts):
                        opts.insert(0, 'generator={0}'.format(gtype))
                    if opts:
                        out.append('terrain: qgis | {0}'.format(
                            ' | '.join(opts)))
                except (TypeError, ValueError):
                    pass
            # 画面設定(背景色/スカイボックス/影/SSAO/EDL) → scene3d: 行。
            # 既定(QGIS 初期状態)と同じ内容は出さない
            sopts = []
            if globe:
                sopts.append('globe=on')
            # background は先頭に出す(Canvas が背景色適用時に空を隠すため、
            # skybox=on を後ろに置いて有効な SkyBox を復帰させる)
            color_el = qgis3d.find('color')
            if color_el is not None:
                bg = _qgis3d_color_hex(color_el.get('background'))
                if bg and bg.upper() != '#FFFFFF':
                    sopts.append('background={0}'.format(bg))
            sky_el = qgis3d.find('skybox')
            if sky_el is not None and sky_el.get('skybox-enabled') == '1':
                sopts.append('skybox=on')
            shadow_el = qgis3d.find('shadow-rendering')
            if shadow_el is not None and \
                    shadow_el.get('shadow-rendering-enabled') == '1':
                sopts.append('shadows=on')
            ao_el = qgis3d.find('screen-space-ambient-occlusion')
            if ao_el is not None and ao_el.get('enabled') == '1':
                sopts.append('ao=on')
            edl_el = qgis3d.find('eye-dome-lighting')
            if edl_el is not None and edl_el.get('enabled') == '1':
                sopts.append('edl=on')
            if sopts:
                out.append('scene3d: {0} | {1}'.format(
                    _kasc_escape(name), ' | '.join(sopts)))
            # 平行光源 → light: 行。QGIS 3D シーン座標は x=東, y=上,
            # z=南(-z が北)で、ベクトルは光源「へ向かう」方向
            # (Qt3D worldDirection)。方位/仰角へ変換して渡す
            lights = qgis3d.find('lights')
            if lights is not None:
                for dl in lights.findall('directional-light'):
                    try:
                        lx = float(dl.get('x') or 0)
                        ly = float(dl.get('y') or 0)
                        lz = float(dl.get('z') or 0)
                        norm = math.sqrt(lx * lx + ly * ly + lz * lz)
                        if norm <= 0:
                            continue
                        lopts = [
                            'az={0:.1f}'.format(
                                math.degrees(
                                    math.atan2(lx, -lz)) % 360),
                            'el={0:.1f}'.format(
                                math.degrees(math.asin(ly / norm)))]
                        try:
                            inten = float(dl.get('intensity') or 1.0)
                            if abs(inten - 1.0) > 0.001:
                                lopts.append(
                                    'intensity={0:g}'.format(inten))
                        except (TypeError, ValueError):
                            pass
                        col = _qgis3d_color_hex(dl.get('color'))
                        if col and col.upper() != '#FFFFFF':
                            lopts.append('color={0}'.format(col))
                        out.append('light: {0} | {1}'.format(
                            _kasc_escape(name), ' | '.join(lopts)))
                    except (TypeError, ValueError):
                        continue
    except Exception as e:
        warnings.append('3Dビュー設定の出力に失敗: {0}'.format(e))
    return out


def _theme_style_qml(layer, style_name, data_dir, slug, theme_slug,
                     warnings, used_names, copied):
    """テーマ記録の名前付きスタイル(styleManager の名前)を
    canvas_data/<slug>__<theme>.qml へ出力し 'canvas_data/...' を返す。
    styleManager に無い・無効なスタイルは None。
    xmlData() は .qml 同等の <qgis> 文書文字列(QGIS 4.0 実測)。"""
    try:
        mgr = layer.styleManager()
        st = mgr.style(style_name) if mgr is not None else None
        if st is None or not st.isValid():
            return None
        fname = '{0}__{1}.qml'.format(
            slug or 'layer', theme_slug or 'theme')
        fpath = os.path.join(data_dir, fname)
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(st.xmlData())
        _expand_user_funcs_in_qml(fpath, warnings)
        # メインスタイルと同様にシンボル画像(SVG/ラスタ)を
        # canvas_data/ へ複製して参照を書き換える(絶対パス残存を防ぐ)
        try:
            _export_qml_assets(
                fpath, slug or 'layer', data_dir, used_names, copied,
                warnings)
        except Exception as e:
            warnings.append(
                'theme style {0}: シンボル画像の複製失敗: {1}'.format(
                    style_name, e))
        return _dref(data_dir, fname)
    except Exception as e:
        warnings.append('theme style {0}: {1}'.format(style_name, e))
        return None


def _export_bookmarks_xml(path):
    """QGISブックマーク(プロジェクト+アプリケーション)を qgis_bookmarks
    形式の XML として path へ出力する。

    extent は全て EPSG:4326 へ正規化する(sr_id はQGIS内部srsidで
    EPSGと一致しないため、参照側が確実に度単位として読めるようにする)。
    戻り値は書き出した件数。失敗時・0件時は 0(ファイルは作らない)。
    """
    try:
        from qgis.core import (QgsApplication, QgsBookmark,
                               QgsBookmarkManager,
                               QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsProject,
                               QgsReferencedRectangle)
        project = QgsProject.instance()
        dest = QgsCoordinateReferenceSystem('EPSG:4326')
        # 変換済みブックマークを集める一時マネージャ(initialize しないので
        # ファイルへは書き出さない)
        tmp = QgsBookmarkManager()
        count = 0
        for mgr in (project.bookmarkManager(),
                    QgsApplication.bookmarkManager()):
            if mgr is None:
                continue
            for bm in mgr.bookmarks() or []:
                try:
                    ext = bm.extent()
                    if ext is None or ext.isNull() or ext.isEmpty():
                        continue
                    src = ext.crs()
                    if src is None or not src.isValid():
                        src = project.crs()
                    rect = QgsCoordinateTransform(
                        src, dest, project).transformBoundingBox(ext)
                    nb = QgsBookmark()
                    nb.setName(bm.name())
                    nb.setGroup(bm.group())
                    nb.setRotation(bm.rotation())
                    nb.setExtent(QgsReferencedRectangle(rect, dest))
                    tmp.addBookmark(nb)
                    count += 1
                except Exception:  # nosec B112  # 設計上の許容
                    continue
        if not count:
            return 0
        return count if QgsBookmarkManager.exportToFile(path, [tmp]) else 0
    except Exception:
        return 0


# ---- アトラス → fly_geojson: 行 -------------------------------------

# Canvas 側の正典カメラ高換算(web/shared/kasc.js の nadirVisibleExtent /
# zoomToCamHeightView と同じ球体幾何)。表示範囲 E[m] を収める直下視
# カメラ高 h を返す。fov は正典 60 度・ビューポートは正方形として扱う
_EARTH_R = 6371008.8
_MERC_R = 6378137.0


def _merc_y(lat):
    lat = max(-85.05, min(85.05, float(lat)))
    return _MERC_R * math.log(
        math.tan(math.pi / 4.0 + math.radians(lat) / 2.0))


def _extent_view_height(w, s, e, n, margin=1.08, fov_deg=60.0):
    """EPSG:4326 の bbox を収める正典カメラ高(m)を返す。

    Canvas の正典高さ ⇄ 表示範囲は ``E = 2αR`` (α は視線の中心角)。
    メルカトルメートルで範囲の大きい方を E に取り、margin で外周に
    余白を持たせる。戻り値は楕円体高(MSL基準で良い近似値)。
    """
    dx = abs(math.radians(float(e) - float(w))) * _MERC_R
    dy = abs(_merc_y(n) - _merc_y(s))
    ext = max(dx, dy, 1.0) * margin
    alpha = ext / (2.0 * _EARTH_R)
    th = math.radians(fov_deg) / 2.0
    return _EARTH_R * (math.sin(alpha + th) / math.sin(th) - 1.0)


def _fly_leg_dist_m(a, b):
    """[lon,lat] 2点間の地表距離(m)。Canvas flyLegDist と同じhaversine。"""
    d_lat = math.radians(b[1] - a[1])
    d_lng = math.radians(b[0] - a[0])
    s = (math.sin(d_lat / 2.0) ** 2 +
         math.cos(math.radians(a[1])) * math.cos(math.radians(b[1])) *
         math.sin(d_lng / 2.0) ** 2)
    return 2.0 * _EARTH_R * math.asin(min(1.0, math.sqrt(s)))


def _fly_auto_speed_ms(total_m):
    """ルート総距離から既定速度(m/s)を決める。

    Canvas shared/player-api.js の flyAutoSpeedKmh と同じ階段。
    ``.kasc`` の ``speed=`` は m/s 規約で書く(2Dプレイヤー側の解釈)。
    """
    if total_m < 5e3:
        return 16.7   # 60 km/h
    if total_m < 5e4:
        return 83.3   # 300 km/h
    return 250.0      # 900 km/h


def _atlas_page_frames(layout, warnings):
    """アトラス有効な印刷レイアウトの各ページ表示範囲を返す。

    ``atlas.beginRender() → seekTo(i) → 参照地図の extent()`` で
    実際のページ範囲を取り、EPSG:4326 bbox へ変換する。戻り値は
    ``{'coverage': レイヤ名, 'rotation': 地図回転角,
       'pages': [{'name':..., 'bbox':(w,s,e,n)}...]}``。
    アトラス無効・条件未達は None。
    """
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsLayoutItemMap,
                           QgsProject)
    atlas = layout.atlas()
    if atlas is None or not atlas.enabled():
        return None
    coverage = atlas.coverageLayer()
    if coverage is None:
        warnings.append('atlas {0}: カバレッジレイヤ無し'.format(
            layout.name()))
        return None
    ref_map = layout.referenceMap()
    if ref_map is None:
        for item in layout.items():
            if isinstance(item, QgsLayoutItemMap):
                ref_map = item
                break
    if ref_map is None:
        warnings.append('atlas {0}: 地図アイテム無し'.format(
            layout.name()))
        return None
    project = QgsProject.instance()
    map_crs = ref_map.crs()
    dest = QgsCoordinateReferenceSystem('EPSG:4326')
    to_wgs = (QgsCoordinateTransform(map_crs, dest, project)
              if map_crs is not None and map_crs.isValid()
              and map_crs != dest else None)
    pages = []
    try:
        if not atlas.beginRender():
            warnings.append('atlas {0}: beginRender失敗'.format(
                layout.name()))
            return None
        try:
            count = atlas.count()
        except Exception:
            count = 0
        for i in range(count):
            try:
                if not atlas.seekTo(i):
                    continue
            except Exception:  # nosec B112  # 設計上の許容
                continue
            try:
                ext = ref_map.extent()
            except Exception:  # nosec B112  # 設計上の許容
                continue
            if ext is None or ext.isNull() or ext.isEmpty():
                continue
            try:
                if to_wgs is not None:
                    ext = to_wgs.transformBoundingBox(ext)
            except Exception:  # nosec B112  # 設計上の許容
                continue
            name = ''
            # ページ名: ユーザー定義名 → ファイル名式 → 連番 の優先順。
            # メソッド有無・引数の違い(旧API)は個別に try で吸収する
            for call in (
                    lambda: atlas.nameForPage(i),
                    lambda: atlas.filenameForPage(i),
                    lambda: atlas.currentFilename()):
                try:
                    name = str(call() or '').strip()
                except Exception:  # nosec B112  # 設計上の許容
                    name = ''
                if name:
                    break
            w = min(ext.xMinimum(), ext.xMaximum())
            e = max(ext.xMinimum(), ext.xMaximum())
            s = min(ext.yMinimum(), ext.yMaximum())
            n = max(ext.yMinimum(), ext.yMaximum())
            pages.append({'name': name or 'page {0}'.format(i + 1),
                          'bbox': (w, s, e, n)})
    finally:
        try:
            atlas.endRender()
        except Exception:  # nosec B110  # 設計上の許容
            pass
    rotation = 0.0
    try:
        rotation = float(ref_map.mapRotation() or 0.0)
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return {'coverage': coverage.name(), 'rotation': rotation,
            'pages': pages}


def _export_atlas_fly(project, data_dir, used_names, warnings):
    """アトラス有効な印刷レイアウト → fly_geojson: 行 + canvas_data/atlas_*.geojson。

    各ページの表示範囲を巡回するフライパスを生成する。座標のZ値には
    そのページ範囲を収める正典カメラ高を焼き込み、GeoJSON properties の
    ``heightReference: "MSL"`` で地形加算を抑止する(Cesium復元規約)。
    ``properties.fly`` に speed/pitch/step 等も埋め込み、.kasc 行側と
    同じ設定がリロード後も維持されるようにする。
    戻り値は (fly_geojson行のリスト, atlas情報のリスト)。
    """
    lines, infos = [], []
    try:
        mgr = project.layoutManager()
        layouts = mgr.printLayouts() if mgr is not None else []
    except Exception:  # nosec B110  # 設計上の許容
        layouts = []
    for layout in layouts:
        try:
            frames = _atlas_page_frames(layout, warnings)
        except Exception as e:
            warnings.append('atlas {0}: {1}'.format(layout.name(), e))
            continue
        if not frames:
            continue
        pages = frames['pages']
        if not pages:
            warnings.append('atlas {0}: ページ0件'.format(layout.name()))
            continue
        if abs(frames['rotation'] or 0.0) > 0.01:
            warnings.append(
                'atlas {0}: 地図回転({1:.1f}°)はフライパスに反映'
                'できません'.format(layout.name(), frames['rotation']))
        coords = []
        for p in pages:
            w, s, e, n = p['bbox']
            lon = (w + e) / 2.0
            lat = (s + n) / 2.0
            height = _extent_view_height(w, s, e, n)
            coords.append([
                round(lon, 6), round(lat, 6),
                int(round(max(1.0, height)))])
        legs = [_fly_leg_dist_m(coords[i], coords[i + 1])
                for i in range(len(coords) - 1)]
        total = sum(legs)
        speed = _fly_auto_speed_ms(total)
        speed = round(speed, 1)
        step = int(round(total / len(legs))) if legs else 100
        name = 'Atlas: {0}'.format(layout.name())
        slug = _slugify('atlas_{0}'.format(layout.name()), used_names)
        gj = {
            'type': 'FeatureCollection',
            'features': [{
                'type': 'Feature',
                'properties': {
                    'name': name,
                    'source': 'qgisAtlas',
                    'layout': layout.name(),
                    'coverage': frames['coverage'],
                    'pages': [p['name'] for p in pages],
                    'pageCount': len(pages),
                    'heightReference': 'MSL',
                    'fly': {
                        'speed': speed, 'height': 0, 'pitch': -85,
                        'step': step, 'loop': False, 'view': 'camera',
                    },
                },
                'geometry': {
                    'type': 'LineString',
                    'coordinates': coords,
                },
            }],
        }
        path = os.path.join(data_dir, slug + '.geojson')
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(gj, f, ensure_ascii=False)
        except Exception as e:
            warnings.append('atlas {0}: geojson書込失敗: {1}'.format(
                layout.name(), e))
            continue
        line = ('fly_geojson: {0} | ' + _dref(data_dir, '{1}.geojson') + ' | speed={2} '
                '| pitch=-85 | height=0 | view=camera | step={3}'
                ).format(_kasc_escape(name), slug, speed, step)
        lines.append(line)
        infos.append({
            'layout': layout.name(), 'pages': len(pages),
            'coverage': frames['coverage'],
            'file': _dref(data_dir, '{0}.geojson'.format(slug)), 'title': name,
        })
    return lines, infos


def _attribution(layer):
    """レイヤの出典(attribution)文字列。失敗時は空文字。"""
    try:
        # QGIS 3.38+/4.x: attribution() は serverProperties() へ移行
        sp = layer.serverProperties() if hasattr(layer, 'serverProperties') else None
        if sp is not None:
            return (sp.attribution() or '').strip()
        return (layer.attribution() or '').strip()
    except Exception:  # nosec B110  # 設計上の許容
        return ''


def _write_engine_launchers(out_dir, kasc_name):
    """.kasc と同じ場所に <engine>.html 起動ページ一式を出力する。

    生成物:
        cesium.html / maplibre.html / openlayers.html / leaflet.html /
            gsimaps.html / navara.html —
            同名エンジンへ ``?kasc=<この .kasc の絶対URL>`` 付きで転送する
            自己完結ランチャー。エンジン本体(web/ の中身)は ./ ../ ../../ /
            の順に自動探索し、見つからなければHTML内の CANVAS_BASE を
            編集して使う
        index.html — 3系統の表示経路案内ページ(①KASUGAI Canvas登録
            ②ローカルHTTP配信で即表示 ③サーバレスWEB配信/パッケージ配置)
            ＋ kasugai_canvas_<ch>.zip ダウンロードリンク

    出力フォルダとエンジンを同じ静的 Web サーバーへアップするだけで
    動く、サーバレス配布のための部品。
    """
    written = []
    for engine in _LAUNCHER_ENGINES:
        html = (_localize_page(_ENGINE_LAUNCHER_HTML)
                .replace('__ENGINE__', engine)
                .replace('__HOSTED_BASE__', hosted_engine_base())
                .replace('__KASC__', kasc_name))
        path = os.path.join(out_dir, '{0}.html'.format(engine))
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html)
        written.append(path)
    idx_path = os.path.join(out_dir, 'index.html')
    with open(idx_path, 'w', encoding='utf-8') as f:
        f.write(_localize_page(_LAUNCHER_INDEX_HTML)
                .replace('__KASC__', kasc_name)
                .replace('__ZIP_NAME__', export_zip_name())
                .replace('__HOSTED_BASE__', hosted_engine_base()))
    written.append(idx_path)
    return written


class ExportCancelled(Exception):
    """progress_cb からの中断要求。

    進捗コールバック内でユーザーのキャンセル操作を検知した場合に
    送出する。レイヤ走査ループはこの例外を握り潰さずそのまま再送出
    し、呼び出し元で「キャンセル」として扱えるようにする。
    """


def export_kasugai_project(iface, out_dir=None, visible_only=True,
                           native_formats=True, hidden_as_off=False,
                           emit_themes=True, emit_bookmarks=True,
                           emit_launchers=None, emit_zip=False,
                           emit_atlas=True,
                           changed=None, live_url=None,
                           fields=None, where=None, limit=None,
                           link_files=True, vector_format=None,
                           visible_data_only=None, progress_cb=None,
                           site_control=None):
    """レイヤツリーを KASUGAI Canvas プロジェクトとして出力する。

    引数:
        visible_only: True なら非表示レイヤは出力しない(既定)。
        native_formats: True なら GPKG/GeoJSON/GeoParquet/FlatGeobuf
            ソース(ローカルファイル・http URL)をそのまま参照し、
            CSV/TSV(delimitedtext 等)は ``duckdb:`` 行(lon=/lat=/geom=)、
            フィルタ(subsetString)付きのネイティブ形式は ``where=``
            付きで出力する(``gpkg:``/``duckdb:`` 系は SQL 評価、
            ``geojson:``/``flatgeobuf:``/``geoparquet:`` は Canvas 側
            where-eval.js のクライアント評価。ローカル Parquet は
            ``duckdb:+format=parquet+where=`` へ切替)、
            3D Tiles レイヤは ``3dtiles:``、ローカル XYZ テンプレートは
            タイルツリー複製の ``xyz:`` 行として出力する。
            それ以外のベクターは FlatGeobuf(優先・空間インデックス付き。
            ドライバ非搭載時は GeoParquet→GeoJSON の順)へ EPSG:4326 で
            変換する。
            False なら全ベクターを同じ変換経路へ回す。
        hidden_as_off: True なら非表示レイヤも ``| off`` 付きで出力する
            (visible_only より優先。プロジェクト構成の丸ごと引越し用)。
            なお「背景図」「ベースマップ」「basemap」名
            (設定 ``kasugai_basemap_groups`` で追加可)のグループ内に
            ある XYZ レイヤは visible_only/hidden_as_off に関わらず
            全て ``base:`` 行(ベースマップ候補)として出力する。
            グループ名はタイトルから外し、配下のサブグループのみ
            ``サブグループ/レイヤ名`` として残す(Canvas 側の
            ベースマップ選択でグループ化表示される)。
        visible_data_only: True なら、非表示レイヤ(``| off`` で出る
            はずだったレイヤ)はレイヤ行を一切出力せず skipped へ記録
            する(背景図グループの XYZ など ``base:`` 候補のみ従来通り
            出力)。Canvas のレイヤ一覧に非表示レイヤが並ばず、
            変換・複写コストも掛からない(大きなプロジェクトの高速化)。
            False なら非表示レイヤも従来通り ``| off`` 行として出力し
            全データを変換・複製する(プロジェクトの丸ごと引越し用途)。
            None(既定)は QSettings ``kasugai_visible_data_only``
            (パネルの「表示中のみ変換」チェック、初期値 ON)に従う。
        progress_cb: ``progress_cb(done, total, name)`` 形式の
            コールバック。レイヤツリー走査の各レイヤ処理開始時に
            ``done`` 件目(0起算)/全 ``total`` 件・対象 ``name`` で呼ぶ。
            全レイヤ処理後に ``(total, total, '')`` で完了を通知する。
            変換の重いレイヤで「何件目/全何件の何を処理中か」を
            UI へ出す用途(パネルの進捗ダイアログ等)。
            コールバック内で ``ExportCancelled`` を送出するとエクスポートを
            中断できる(キャンセルボタン実装用)。
        site_control: True ならレイヤツリーのグループ名を
            ``site=<グループ>`` としてレイヤ行へ付け、custom-layer
            プラグインJSを canvas_data/ へ複製して ``plugin:`` 行を
            出力する(site ごとの一括 on/off タブが Canvas 側へ
            追加される。レイヤ customProperty ``kasugai_site`` /
            ``kasugai_order`` で個別上書き可)。None(既定)は
            QSettings ``kasugai_site_control``(パネルのチェック)に従う。
        emit_themes: True ならプロジェクトのマップテーマを ``theme:`` 行
            (Canvas の可視性プリセット)として出力する(既定)。
            テーマが存在する場合、非表示レイヤも ``| off`` で出力しないと
            テーマ側から表示へ戻せないため、hidden_as_off 同等に全レイヤを
            出力する。テーマが無ければ従来どおりの出力。
        emit_bookmarks: True ならプロジェクト+アプリケーションの
            ブックマークを ``bookmarks.xml``(qgis_bookmarks 形式・
            EPSG:4326 正規化)として出力し ``bookmark:`` 行を書く(既定)。
            Canvas 側ではカメラプリセットUIにそのまま並ぶ。
        emit_launchers: True なら .kasc と同じ場所に
            ``<engine>.html``(cesium/maplibre/openlayers/leaflet/gsimaps/
            navara)と
            ``index.html`` のエンジン起動ページを出力する(既定)。
            各HTMLは ``?kasc=<この .kasc の絶対URL>`` 付きでエンジンへ
            転送し、エンジン本体(web/ の中身)を ./ ../ ../../ / の順に
            自動探索する。出力フォルダとエンジンを同じ静的サーバーへ
            アップするだけで動くサーバレス配布の部品。
        emit_zip: True なら出力一式(.kasc+canvas_data/+bookmarks.xml等)を
            ``kasugai_canvas_<tag>.zip``(export_zip_name、CDNチャンネル反映)
            として同じ場所に固める(既定 False)。
            Re:Earth geo_suite の ``qgis: <zip URL>`` インスペクタ行が
            このZIPを直接取り込める(CMS等へアップするだけで再現可能)。
            ``/export-data/kasugai_canvas*.zip`` からも取得できる
            (未生成時はその場で固めて返す)。
        emit_atlas: True ならアトラス有効な印刷レイアウトを
            ``fly_geojson:`` 行 + ``canvas_data/atlas_*.geojson`` として
            出力する(既定)。各アトラスページの表示範囲を巡回する
            フライパスで、座標Z値にページを収めるカメラ高を焼き込む
            (``properties.heightReference="MSL"`` で地形加算を抑止)。
        fields: 出力する属性列の選択(QGIS「ベクタレイヤを保存」の
            フィールド選択、ogr2ogr の ``-select`` 相当)。全レイヤ共通の
            列名リスト/カンマ区切り文字列、または
            ``{レイヤ名 or layer.id(): 列名リスト}`` のレイヤ毎指定。
            存在しない列名はそのレイヤを errors へ記録して除外する。
        where: 出力地物を絞る QgsExpression 式(ogr2ogr ``-where`` 相当。
            ``"code" = '12'`` 等)。fields と同様に全レイヤ共通 or
            レイヤ毎 dict を受ける。レイヤのプロバイダフィルタ
            (subsetString)とは AND 適用。式のパースエラーは
            errors へ記録してそのレイヤを除外する。
        limit: レイヤ毎の出力地物数上限(ogr2ogr ``-limit`` 相当、
            1以上の整数)。同様に共通値 or レイヤ毎 dict を受ける
            (大容量レイヤの CDN 配信サイズ制御用)。
            fields/where/limit のいずれかが指定されたベクターレイヤは
            ネイティブ参照(``gpkg:``/``geojson:`` 等)を使わず、
            QgsFeatureRequest+materialize で条件適用済みの地物を
            FlatGeobuf 変換で焼き込む。どのソース形式でもフィルタが
            出力データへ確実に反映される(.kasc 行形式・Canvas 側の
            変更は不要)。
        vector_format: ベクターの出力モード。``None``(既定)は
            QSettings ``kasugai_vector_format`` の値(未設定は 'native')
            を使う。'native' は従来どおり参照優先。
            'recommended' は推奨形式スイッチ: FlatGeobuf/GeoParquet 系
            (``flatgeobuf:``/``geoparquet:``/``duckdb:+format=parquet``)
            以外のベクターソース(gpkg/geojson/shp/csv/kml/wfs 等)を
            すべて FlatGeobuf へ EPSG:4326 で変換し canvas_data/ へ配置する。
            'geojson' は WEB連携モード: 全ベクターを GeoJSON へ EPSG:4326
            で変換し canvas_data/ へ ``geojson:`` 行として配置する
            (KASUGAI Canvas 以外の WebGIS・GIS ツールでも canvas_data/
            をそのまま読める相互運用向け。推奨形式ソースも含め全て変換)。
            変換でフィルタ(subsetString)・fields/where/limit も
            そのまま焼き込まれる。
        link_files: True(既定)なら `.kasc` を QGIS プロジェクトファイル
            (.qgs/.qgz)と同じ場所へ出力し、参照可能なデータは**原本の
            相対パスのまま**複写せずに参照する「複写なし Web化」モード。
            プロジェクトdir配下または1階層上(ワークスペース)までの
            ファイルは相対パス参照、それより外(深い親・別ドライブ)と
            変換が必要なデータのみ ``canvas_data/`` サブフォルダへ出力。
            プロジェクト未保存の場合は ``get_output_dir()`` へフォール
            バック。False なら従来通り ``out_dir/canvas_data/`` へ全データ複写
            (サーバレス配布・ホスティング用)。

    戻り値: {"dir","kasc","data_dir","layers":[{name,file,features}],
             "tiles":[...],"skipped":[...],"errors":[...],"warnings":[...],
             "launchers":[...],"zip":...,"atlases":[{layout,pages,file}]}。
    layers が1件も無くても .kasc は出力する。
    """
    from qgis.core import QgsVectorLayer, QgsProject
    project = QgsProject.instance()
    # link_files: .kasc をプロジェクトファイルと同じ場所へ置き、原本を
    # 相対参照する。出力先の優先順位は 明示 out_dir > QSettings の
    # kasugai_output_path > (link時)プロジェクトdir > 既定出力先。
    if out_dir is None:
        saved = str(
            _qsettings().value(SETTINGS_KEY_OUTPUT, '') or '').strip()
        configured = bool(saved and saved != '__default__')
        if link_files and project.fileName() and not configured:
            out_dir = os.path.dirname(os.path.abspath(project.fileName()))
        else:
            out_dir = preferred_output_dir()
    out_dir = os.path.abspath(out_dir)
    data_dir = os.path.join(out_dir, 'canvas_data')
    os.makedirs(data_dir, exist_ok=True)
    global _last_export_dir, _LINK_FILES, _LINK_ROOT
    _last_export_dir = out_dir
    _LINK_FILES = bool(link_files)
    _LINK_ROOT = out_dir
    # link モードでは .kasc しかプロジェクト dir に置かないため、
    # 起動HTML群(サーバレス配布用)は明示指定時のみ生成する
    if emit_launchers is None:
        emit_launchers = not link_files
    # 旧世代の kasugai_canvas*.zip が残っていると /export-data/ で
    # 陳腐化したZIPが配信されるため除去する(emit_zip 時は後段で再生成)
    try:
        for name in os.listdir(out_dir):
            if _is_export_zip_name(name):
                os.remove(os.path.join(out_dir, name))
    except Exception:  # nosec B110  # 設計上の許容
        pass

    project_title = os.path.splitext(
        os.path.basename(project.fileName() or ''))[0] or 'QGIS Export'

    used_names = set()
    slug_by_id = {}  # layer.id() → canvas_data/ 用 slug(theme 行の ;style= で使う)
    emitted_ids = set()  # .kasc へレイヤ行を出力したレイヤ(theme 行の対象)
    copied = {}
    layers_out, tiles_out, skipped, errors, warnings = [], [], [], [], []
    kasc_lines = []
    # ベクター出力モード: None は QSettings kasugai_vector_format(既定
    # 'native')を解決。'recommended' は推奨形式スイッチで、推奨形式
    # (flatgeobuf/geoparquet 系)以外のネイティブ参照を FlatGeobuf 変換
    # (canvas_data/ 配置)へ回す。'geojson' は WEB連携モードで全ベクターを
    # GeoJSON 変換へ回す(ネイティブ参照を一切使わない)
    if vector_format is None:
        vector_format = get_vector_export_mode()
    _fmt = str(vector_format or '').strip().lower()
    vector_format = _fmt if _fmt in VECTOR_EXPORT_MODES else 'native'
    recommend_fmt = vector_format == 'recommended'
    geojson_fmt = vector_format == 'geojson'
    # 非表示レイヤのデータ変換スキップ: None は QSettings
    # kasugai_visible_data_only(パネルのチェック、初期値 ON)を解決
    if visible_data_only is None:
        visible_data_only = get_visible_data_only()
    # カスタムレイヤタブ(パネルのチェック、既定 OFF)を解決。
    # ON ならレイヤツリーのグループ名を site= としてレイヤ行へ付け、
    # custom-layer プラグインを canvas_data/ へ複製して plugin: 行を出す
    if site_control is None:
        site_control = get_site_control()
    # ライブ差分エクスポート: {layer.id(): {'data':bool,'style':bool}}。
    # changed 指定時は未変更レイヤのデータ/スタイル書き出しを
    # 既存ファイルがある場合に限りスキップし、live.json に変更一覧を書く
    live_changed = []
    detected_base = None  # 表示中の最下段 XYZ → base: 行
    group_bases = []      # ベースマップグループ内 XYZ の base: 行
    basemap_layer_ids = set()  # base: 行へ回したレイヤ(theme 行から除外)

    group_states = {}
    exclusive_groups = set()
    tree = _tree_layers(skipped, warnings, group_states, exclusive_groups)

    # カスタムレイヤー順(描画順オーバーライド)が有効ならその順へ並べ替える(#59)
    try:
        root = project.layerTreeRoot()
        if root.hasCustomLayerOrder():
            order_map = {id(l): i
                         for i, l in enumerate(root.customLayerOrder() or [])}
            tree = sorted(
                tree,
                key=lambda t: order_map.get(id(t[0]), len(order_map)))
    except Exception:  # nosec B110  # 設計上の許容
        pass

    # theme: 行(マップテーマ → Canvas 可視性プリセット)の素材。
    # テーマが存在する場合、非表示レイヤも | off で出さないとテーマ適用時に
    # 表示へ戻せないため、hidden_as_off 同等に全レイヤを出力対象にする
    theme_names = []
    if emit_themes:
        try:
            theme_names = sorted(
                project.mapThemeCollection().mapThemes() or [])
        except Exception:
            theme_names = []
    export_hidden_off = hidden_as_off or bool(theme_names)

    # base: 判定用に表示中の最下段 XYZ を先に特定する
    last_xyz_id = None
    for layer, _groups, vis, _tn in tree:
        if vis and _xyz_layer_info(layer):
            last_xyz_id = id(layer)

    # ベースマップグループ名(内蔵+ユーザー追加)はエクスポート中固定
    basemap_names = _basemap_group_names()

    # 進捗通知: レイヤツリー全件を処理単位として「N/全M件: 名前」を
    # progress_cb へ流す(スキップ対象も1件として数える)
    _progress_total = len(tree)
    for _li, (layer, groups, visible, tnode) in enumerate(tree):
        if progress_cb:
            try:
                progress_cb(_li, _progress_total, layer.name())
            except ExportCancelled:
                raise
            except Exception:  # nosec B110  # UI通知の失敗で中断しない
                pass
        # LIST 列(kasugai_export='off'): Canvas へ引き継がない
        # (.kasc へ出力しない。表示列の | off とは別扱い)
        if str(layer.customProperty(
                'kasugai_export', '') or '').strip() == 'off':
            skipped.append(
                '{0} (Canvasへ引き継がない設定のため出力対象外)'.format(
                    layer.name()))
            continue
        # 「背景図」「basemap」名のグループはベースマップ候補の入れ物。
        # 中の XYZ レイヤはレイヤ行ではなく base: 行として登録する
        # (グループ名はタイトルから外し、配下のサブグループは残す)
        bm_idx = _basemap_group_index(groups, basemap_names)
        title = _kasc_layer_title(groups, layer.name(), exclusive_groups)
        # レイヤ別オプション(site=/order=/list=off/追加opts)。
        # カスタムレイヤタブ ON のときグループ名を site= として自動付与、
        # customProperty(kasugai_site 等)は設定有無に関わらず常時有効
        site_opt = _canvas_layer_opts_suffix(
            layer, groups, bm_idx, site_control)
        # 表示列(kasugai_vis='off'): Canvas へ引き継ぐが初期状態は
        # 非表示(| off)。QGIS 上で非表示でも「引き継ぐ」意図が
        # 明示されているため visible_only スキップより優先する
        vis_off_opt = str(layer.customProperty(
            'kasugai_vis', '') or '').strip() == 'off'
        if not visible:
            if (bm_idx is not None
                    and not isinstance(layer, QgsVectorLayer)
                    and _xyz_layer_info(layer)):
                # ベースマップ候補は表示状態に関わらず全て登録する
                # (visible_only/hidden_as_off の対象外。非表示は | off で
                # 「初期選択しない候補」として出す)
                vis_flag = 'off'
            elif export_hidden_off or vis_off_opt:
                vis_flag = 'off'
            elif not visible_only:
                vis_flag = 'on'
            else:
                continue
        else:
            vis_flag = 'off' if vis_off_opt else 'on'

        # visible_data_only: 非表示レイヤはレイヤ行を一切出力しない
        # (背景図グループの base: 候補のみ従来通り出力。Canvas のレイヤ
        # 一覧に読み込めない「未読込」エントリが残るのを防ぐ。
        # theme: 行は出力済みレイヤのみを対象にするため整合する。
        # kasugai_vis で off にした「表示中」レイヤは引き続き対象)
        ref_only = (bool(visible_data_only)
                    and not visible and vis_flag == 'off')
        write_ok = not ref_only
        if ref_only and not (
                bm_idx is not None
                and not isinstance(layer, QgsVectorLayer)
                and _xyz_layer_info(layer)):
            skipped.append(
                '{0} (非表示レイヤのため出力対象外)'.format(layer.name()))
            continue

        kinds = changed.get(layer.id()) if isinstance(changed, dict) else None
        if kinds is not None:
            live_changed.append({
                'title': title,
                'data': bool(kinds.get('data')),
                'style': bool(kinds.get('style')),
            })

        if isinstance(layer, QgsVectorLayer):
            # ジオメトリを持たない属性テーブルは Canvas で描画できない
            try:
                from qgis.core import QgsWkbTypes
                if layer.wkbType() == QgsWkbTypes.NoGeometry:
                    skipped.append(
                        '{0} (属性テーブル)'.format(layer.name()))
                    continue
            except Exception:  # nosec B110  # 設計上の許容
                pass
            slug = _slugify(layer.name() or 'layer', used_names)
            slug_by_id[layer.id()] = slug
            qml_path = os.path.join(data_dir, slug + '.qml')
            style_opt = ''
            need_qml = (changed is None or (kinds or {}).get('style')
                        or not os.path.isfile(qml_path))
            if need_qml:
                try:
                    _export_qml(layer, qml_path)
                    _expand_user_funcs_in_qml(qml_path, warnings)
                    try:
                        _export_qml_assets(
                            qml_path, slug, data_dir, used_names, copied,
                            warnings)
                    except Exception as e:
                        warnings.append(
                            '{0}: シンボル画像の複製失敗: {1}'.format(
                                layer.name(), e))
                    style_opt = ' | style=' + _dref(data_dir, slug + '.qml')
                except Exception as e:
                    errors.append('{0}: qml {1}'.format(layer.name(), e))
            else:
                # 未変更レイヤ: 既存 .qml を再利用して書き出しをスキップ
                style_opt = ' | style=' + _dref(data_dir, slug + '.qml')
            feat_count = -1
            try:
                feat_count = int(layer.featureCount())
            except Exception:  # nosec B110  # 設計上の許容
                pass
            # 時間対応・ヒートマップ/クラスタ・透過度等の共通オプション
            vopt = _vector_opts_suffix(layer, warnings)

            # 大規模・複雑スタイルのベクターは QGIS レンダラで
            # XYZ タイルへ焼き付け、表示は xyz: 行(縮尺選択は
            # タイルズームに委譲)に任せる。照会・ベクタ表示用の
            # データ行(geojson: 等)は | off で併記する
            if _vector_needs_xyz(layer, feat_count):
                xyz_dir = os.path.join(data_dir, slug + '_xyz')
                # 差分管理下で変更のあるレイヤ・タイル未生成のレイヤのみ
                # 焼き付け直す。changed=None(差分情報なしのフル出力)は
                # 既存タイルを再利用(全件再描画はエクスポート時間を
                # 大幅に延ばすため。スタイル変更時は live 差分経由か
                # *_xyz ディレクトリ削除で再焼き付け)
                just_baked = False
                if (kinds is not None
                        or not _dir_has_pngs(xyz_dir)):
                    xyz_info = _render_vector_xyz(
                        layer, slug + '_xyz', data_dir, warnings)
                    just_baked = bool(xyz_info)
                else:
                    xyz_info = _reuse_vector_xyz(
                        layer, slug + '_xyz', data_dir)
                if xyz_info:
                    url, zmin, zmax, bb, n_tiles = xyz_info
                    line = 'xyz: {0} | {1} | {2}'.format(
                        title, _kasc_escape(url), vis_flag)
                    line += ' | maxZoom={0} | minZoom={1}'.format(
                        zmax, zmin)
                    op = _maplayer_opacity(layer)
                    if op is not None:
                        line += ' | opacity={0}'.format(op)
                    line += _scale_vis_opt(layer)
                    if bb:
                        line += ' | bbox={0}'.format(bb)
                    attr = _attribution(layer)
                    if attr:
                        line += ' | attr={0}'.format(
                            _kasc_escape(attr))
                    line += site_opt
                    kasc_lines.append(line)
                    # 単体確認用の最小 Leaflet ページをタイルツリー直下へ
                    try:
                        _bb = [float(v) for v in str(bb or '').split(',')]
                        _write_xyz_index(
                            data_dir, slug + '_xyz', zmin, zmax,
                            _bb if len(_bb) == 4 else None,
                            title=layer.name())
                    except Exception:  # nosec B110  # 設計上の許容
                        pass
                    tiles_out.append({
                        'name': layer.name(), 'url': url,
                        'type': 'xyz', 'baked': just_baked,
                        'tiles': n_tiles})
                    # データ行は照会用に off で引き続き出力
                    vis_flag = 'off'
                else:
                    warnings.append(
                        '{0}: XYZ焼き付け失敗のためベクター出力へ'.format(
                            layer.name()))

            # fields/where/limit 指定は .kasc 行オプションでは表現できず
            # 出力データへ焼き込む必要があるためベクター変換へ回す
            # (ネイティブ参照のままでは選択・絞り込みが反映されない)
            f_sel = _fields_list(_per_layer_opt(fields, layer))
            w_sel = _per_layer_opt(where, layer)
            w_sel = str(w_sel).strip() or None \
                if w_sel is not None else None
            l_sel = _per_layer_opt(limit, layer)
            bake = bool(f_sel) or bool(w_sel) or l_sel is not None
            native = None
            if native_formats and not bake and not geojson_fmt \
                    and (not recommend_fmt
                         or _recommended_source_kind(layer)):
                # 推奨形式モードでは fgb/parquet ソースのみ _native_ref へ
                # 進め、それ以外は直接 FlatGeobuf 変換へ回す(_native_ref
                # は行タイプ決定前にファイルを canvas_data/ へコピーするため)。
                # geojson モードはネイティブ参照を使わず全ベクターを
                # GeoJSON 変換へ回す
                native = _native_ref(
                    layer, slug, data_dir, copied, warnings)
                if recommend_fmt and isinstance(native, dict) \
                        and native.get('type') \
                        and not _is_recommended_native(native):
                    # fgb/parquet 以外の行タイプ(万が一の迂回)も変換へ回す
                    native = None
            if isinstance(native, dict) and native.get('skip_reason'):
                skipped.append(
                    '{0} ({1})'.format(layer.name(), native['skip_reason']))
                continue
            if native:
                line_type, ref = native['type'], native['ref']
                line = '{0}: {1} | {2} | {3}'.format(
                    line_type, title, _kasc_escape(ref), vis_flag)
                opts = dict(native.get('opts', {}))
                # where= は行の最終オプション(値は行末まで)なので
                # 他オプションの後ろへ分離してから出力する
                where_val = opts.pop('where', None)
                for key, val in opts.items():
                    line += ' | {0}={1}'.format(key, _kasc_escape(val))
                line += style_opt
                line += vopt
                line += _scale_vis_opt(layer)
                attr = _attribution(layer)
                if attr:
                    line += ' | attr={0}'.format(_kasc_escape(attr))
                line += site_opt
                if where_val:
                    line += ' | where={0}'.format(where_val)
                layers_out.append({
                    'name': layer.name(), 'title': title, 'file': ref,
                    'qml': _dref(data_dir, '{0}.qml'.format(slug)) if style_opt else None,
                    'features': feat_count, 'format': line_type,
                })
                kasc_lines.append(line)
                emitted_ids.add(id(layer))
                continue

            # ネイティブ参照できないベクター → FlatGeobuf(第1候補・
            # 空間インデックス付きで GeoJSON より軽量)等の高速形式へ
            # EPSG:4326 で変換。ドライバが無ければ Parquet→GeoJSON へ落ちる。
            # geojson モードは全ベクターを GeoJSON 固定で出力する
            if geojson_fmt:
                drv, out_ext, out_kind = 'GeoJSON', '.geojson', 'geojson'
            else:
                drv, out_ext, out_kind = _fallback_driver()
            out_path = os.path.join(data_dir, slug + out_ext)
            written = feat_count
            # 変換形式でも subsetString は where-eval 対応式なら where=
            # として引き継ぐ(全地物を出力し Canvas 側で絞り込み・
            # フィルタタブで値を再列挙できる。非対応式は従来通り
            # データへ焼き込む)
            subset_raw = _subset_raw(layer)
            subset_where = None
            if subset_raw and _subset_eval_ok(subset_raw):
                subset_where = _subset_filter(layer)
            if (changed is None
                    or (kinds or {}).get('data')
                    or not os.path.isfile(out_path)):
                if subset_where:
                    try:
                        layer.setSubsetString('')
                    except Exception:  # nosec B110  # 設計上の許容
                        subset_where = None
                try:
                    try:
                        written = _export_vector(
                            layer, out_path, fields=f_sel, where=w_sel,
                            limit=l_sel, driver=drv)
                    except Exception as e:
                        # FlatGeobuf/Parquet で失敗した場合は GeoJSON で再試行
                        if drv != 'GeoJSON':
                            warnings.append(
                                '{0}: {1} 変換失敗({2})のため GeoJSON へ'
                                .format(layer.name(), drv, e))
                            drv, out_ext, out_kind = \
                                'GeoJSON', '.geojson', 'geojson'
                            out_path = os.path.join(data_dir, slug + out_ext)
                            try:
                                written = _export_vector(
                                    layer, out_path, fields=f_sel,
                                    where=w_sel,
                                    limit=l_sel, driver=drv)
                            except Exception as e2:
                                errors.append(
                                    '{0}: geojson {1}'.format(
                                        layer.name(), e2))
                                continue
                        else:
                            errors.append(
                                '{0}: geojson {1}'.format(layer.name(), e))
                            continue
                finally:
                    if subset_where:
                        try:
                            layer.setSubsetString(subset_raw)
                        except Exception:  # nosec B110  # 設計上の許容
                            pass
            if not _geo_equiv_crs(layer):
                warnings.append(
                    '{0}: CRS {1} を EPSG:4326 へ再投影'.format(
                        layer.name(), layer.crs().authid() or ''))
            layer_entry = {
                'name': layer.name(), 'title': title,
                'file': _dref(data_dir, '{0}{1}'.format(slug, out_ext)),
                'qml': _dref(data_dir, '{0}.qml'.format(slug)) if style_opt else None,
                'features': written, 'format': out_kind,
            }
            if bake:
                layer_entry['filter'] = {
                    'fields': f_sel, 'where': w_sel, 'limit': l_sel}
            layers_out.append(layer_entry)
            attr = _attribution(layer)
            attr_opt = ' | attr={0}'.format(
                _kasc_escape(attr)) if attr else ''
            line = (
                '{7}: {0} | {9}{1}{8} | {2}{3}{4}{5}{6}'.format(
                    title, slug, vis_flag, style_opt, vopt,
                    _scale_vis_opt(layer), attr_opt, out_kind, out_ext,
                    os.path.basename(data_dir) + '/') + site_opt)
            # where= は行の最終オプション(値は行末まで)
            if subset_where:
                line += ' | where={0}'.format(subset_where)
            kasc_lines.append(line)
            emitted_ids.add(id(layer))
            ln_meta = _legend_node_line(tnode, title)
            if ln_meta:
                kasc_lines.append(ln_meta)
        else:
            vt_src = _vectortile_source(layer)
            if vt_src:
                line = '{0}: {1} | {2} | {3}'.format(
                    vt_src['kind'], title, _kasc_escape(vt_src['url']),
                    vis_flag)
                if vt_src['zmin'] is not None:
                    line += ' | minzoom={0}'.format(vt_src['zmin'])
                if vt_src['zmax'] is not None:
                    line += ' | maxzoom={0}'.format(vt_src['zmax'])
                line += _scale_vis_opt(layer)
                attr = _attribution(layer)
                if attr:
                    line += ' | attr={0}'.format(_kasc_escape(attr))
                line += site_opt
                kasc_lines.append(line)
                tiles_out.append({'name': layer.name(), 'url': vt_src['url'],
                                  'type': vt_src['kind']})
                emitted_ids.add(id(layer))
                continue
            if _is_tiled_scene(layer):
                slug = _slugify(layer.name() or 'scene', used_names)
                ref = _tiledscene_ref(layer, slug, data_dir, copied,
                                      warnings)
                if ref:
                    line = '3dtiles: {0} | {1} | {2}'.format(
                        title, _kasc_escape(ref), vis_flag)
                    line += _scale_vis_opt(layer)
                    attr = _attribution(layer)
                    if attr:
                        line += ' | attr={0}'.format(_kasc_escape(attr))
                    line += site_opt
                    kasc_lines.append(line)
                    tiles_out.append({'name': layer.name(), 'url': ref,
                                      'type': '3dtiles'})
                    emitted_ids.add(id(layer))
                else:
                    skipped.append(
                        '{0} (3dtiles参照不可)'.format(layer.name()))
                continue
            xyz = _xyz_layer_info(layer)
            if xyz:
                url, zmin, zmax = xyz
                if not re.match(r'https?://', url):
                    # file:/// 等のローカルタイルテンプレートは canvas_data/ へ複製
                    slug = _slugify(layer.name() or 'tiles', used_names)
                    ref = _local_xyz_template(url, slug, data_dir, copied,
                                              warnings, write=write_ok)
                    if ref:
                        url = ref
                    else:
                        skipped.append(
                            '{0} (ローカルタイル複製不可)'.format(
                                layer.name()))
                        continue
                opacity = _maplayer_opacity(layer)
                bbox = _layer_extent_bbox(layer)
                if bm_idx is not None:
                    # ベースマップグループ内の XYZ → base: 候補として登録。
                    # グループ名は外し、配下サブグループのみタイトルに残す
                    base_title = '/'.join(
                        [_kasc_escape(g)
                         for g in groups[bm_idx + 1:] if g] +
                        [_kasc_escape(layer.name())])
                    line = 'base: {0} | {1}'.format(
                        base_title, _kasc_escape(url))
                    attr = _attribution(layer)
                    if attr:
                        line += ' | {0}'.format(_kasc_escape(attr))
                    if zmax is not None:
                        line += ' | maxZoom={0}'.format(zmax)
                    if zmin is not None:
                        line += ' | minZoom={0}'.format(zmin)
                    if opacity is not None:
                        line += ' | opacity={0}'.format(opacity)
                    line += _scale_vis_opt(layer)
                    if not visible:
                        line += ' | off'
                    group_bases.append((visible, line))
                    basemap_layer_ids.add(id(layer))
                elif visible and id(layer) == last_xyz_id:
                    # QGIS の最下段タイルはベースマップとして出力
                    line = 'base: {0} | {1}'.format(title, _kasc_escape(url))
                    attr = _attribution(layer)
                    if attr:
                        line += ' | {0}'.format(_kasc_escape(attr))
                    if zmax is not None:
                        line += ' | maxZoom={0}'.format(zmax)
                    if zmin is not None:
                        line += ' | minZoom={0}'.format(zmin)
                    if opacity is not None:
                        line += ' | opacity={0}'.format(opacity)
                    line += _scale_vis_opt(layer)
                    detected_base = line
                else:
                    line = 'xyz: {0} | {1} | {2}'.format(
                        title, _kasc_escape(url), vis_flag)
                    if zmax is not None:
                        line += ' | maxZoom={0}'.format(zmax)
                    if zmin is not None:
                        line += ' | minZoom={0}'.format(zmin)
                    if opacity is not None:
                        line += ' | opacity={0}'.format(opacity)
                    line += _scale_vis_opt(layer)
                    if bbox is not None:
                        line += ' | bbox={0}'.format(bbox)
                    attr = _attribution(layer)
                    if attr:
                        line += ' | attr={0}'.format(_kasc_escape(attr))
                    line += site_opt
                    kasc_lines.append(line)
                    emitted_ids.add(id(layer))
                tiles_out.append({'name': layer.name(), 'url': url,
                                  'type': 'xyz'})
            else:
                wmts = _wmts_layer_info(layer)
                if wmts:
                    url, w_layers, w_styles, w_tms, w_fmt, w_tilesize = wmts
                    line = 'wmts: {0} | {1} | {2}'.format(
                        title, _kasc_escape(url), vis_flag)
                    if w_layers:
                        line += ' | layer={0}'.format(
                            _kasc_escape(w_layers))
                    if w_styles:
                        line += ' | style={0}'.format(
                            _kasc_escape(w_styles))
                    if w_tms:
                        line += ' | tilematrixset={0}'.format(
                            _kasc_escape(w_tms))
                    if w_fmt:
                        line += ' | format={0}'.format(
                            _kasc_escape(w_fmt))
                    if w_tilesize in (256, 512):
                        line += ' | tilesize={0}'.format(w_tilesize)
                    opacity = _maplayer_opacity(layer)
                    bbox = _layer_extent_bbox(layer)
                    if opacity is not None:
                        line += ' | opacity={0}'.format(opacity)
                    if bbox is not None:
                        line += ' | bbox={0}'.format(bbox)
                    line += _scale_vis_opt(layer)
                    attr = _attribution(layer)
                    if attr:
                        line += ' | attr={0}'.format(_kasc_escape(attr))
                    line += site_opt
                    kasc_lines.append(line)
                    tiles_out.append({'name': layer.name(), 'url': url,
                                      'type': 'wmts'})
                    emitted_ids.add(id(layer))
                    continue
                wms = _wms_layer_info(layer)
                if wms:
                    url, wms_layers, wms_styles, wms_fmt, wms_ver = wms
                    line = 'wms: {0} | {1} | {2}'.format(
                        title, _kasc_escape(url), vis_flag)
                    if wms_layers:
                        line += ' | layers={0}'.format(
                            _kasc_escape(wms_layers))
                    if wms_styles:
                        line += ' | styles={0}'.format(
                            _kasc_escape(wms_styles))
                    if wms_fmt:
                        line += ' | format={0}'.format(
                            _kasc_escape(wms_fmt))
                    if wms_ver:
                        line += ' | version={0}'.format(
                            _kasc_escape(wms_ver))
                    opacity = _maplayer_opacity(layer)
                    bbox = _layer_extent_bbox(layer)
                    if opacity is not None:
                        line += ' | opacity={0}'.format(opacity)
                    if bbox is not None:
                        line += ' | bbox={0}'.format(bbox)
                    line += _scale_vis_opt(layer)
                    attr = _attribution(layer)
                    if attr:
                        line += ' | attr={0}'.format(_kasc_escape(attr))
                    line += site_opt
                    kasc_lines.append(line)
                    tiles_out.append({'name': layer.name(), 'url': url,
                                      'type': 'wms'})
                    emitted_ids.add(id(layer))
                else:
                    # GDAL ラスタ: GeoTIFF/COG は geotiff: 行、
                    # それ以外の形式・再現不能なレンダラ設定は
                    # QGIS で描画済み PNG へ焼き付けて image: 行で出す
                    slug = _slugify(layer.name() or 'raster', used_names)
                    ref = _geotiff_layer_ref(
                        layer, slug, data_dir, copied)
                    need_bake = ref is None or _raster_needs_bake(layer)
                    baked_bbox = None
                    if need_bake:
                        png_path = os.path.join(data_dir, slug + '.png')
                        if (changed is None or kinds is not None
                                or not os.path.isfile(png_path)):
                            baked_bbox = _render_raster_png(
                                layer, png_path, warnings)
                        else:
                            # 未変更ラスタ: 既存PNG再利用(bboxは範囲から再現)
                            baked_bbox = _raster_bbox_str(layer)
                    if baked_bbox:
                        line = 'image: {0} | {1} | {2}'.format(
                            title, _dref(data_dir, '{0}.png'.format(slug)),
                            vis_flag)
                        line += ' | bbox={0}'.format(baked_bbox)
                        opacity = _maplayer_opacity(layer)
                        if opacity is not None:
                            line += ' | opacity={0}'.format(opacity)
                        line += _scale_vis_opt(layer)
                        attr = _attribution(layer)
                        if attr:
                            line += ' | attr={0}'.format(
                                _kasc_escape(attr))
                        line += site_opt
                        kasc_lines.append(line)
                        tiles_out.append({
                            'name': layer.name(),
                            'url': _dref(data_dir, '{0}.png'.format(slug)),
                            'type': 'image'})
                        emitted_ids.add(id(layer))
                    elif ref:
                        line = 'geotiff: {0} | {1} | {2}'.format(
                            title, _kasc_escape(ref), vis_flag)
                        bands = _raster_bands_opt(layer)
                        if bands:
                            line += ' | bands={0}'.format(bands)
                        line += _scale_vis_opt(layer)
                        opacity = _maplayer_opacity(layer)
                        if opacity is not None:
                            line += ' | opacity={0}'.format(opacity)
                        attr = _attribution(layer)
                        if attr:
                            line += ' | attr={0}'.format(
                                _kasc_escape(attr))
                        line += site_opt
                        kasc_lines.append(line)
                        tiles_out.append({'name': layer.name(), 'url': ref,
                                          'type': 'geotiff'})
                        emitted_ids.add(id(layer))
                    else:
                        skipped.append(
                            '{0} ({1})'.format(
                                layer.name(), _skip_reason(layer)))

    if progress_cb:
        try:
            progress_cb(_progress_total, _progress_total, '')
        except Exception:  # nosec B110  # UI通知の失敗で中断しない
            pass

    # カスタムレイヤ: site= 付きレイヤが1件でも出力されていれば
    # custom-layer プラグインJSを canvas_data/ へ複製し plugin: 行を出す
    # (url= プロジェクト相対なので CDN/静的ホスティング・全エンジンで
    # そのまま動く。site= レイヤが無ければタブ不要なので行も出さない)
    if any(' | site=' in kl for kl in kasc_lines):
        if _copy_site_control_plugin(data_dir, warnings):
            # Filter タブの選択状態を filter_* オプションとして付ける
            # (Canvas「フィルタ」タブの初期選択。適用済みフィルタ自体は
            # 各レイヤ行の where= で引き継がれる)
            fs = _filter_panel_state or {}
            plugin_opts = ''
            if fs.get('site'):
                plugin_opts += ' | filter_site={0}'.format(
                    _kasc_escape(fs['site']))
            if fs.get('field'):
                plugin_opts += ' | filter_field={0}'.format(
                    _kasc_escape(fs['field']))
            if fs.get('multi'):
                plugin_opts += ' | filter_multi=on'
            if fs.get('op'):
                plugin_opts += ' | filter_op={0}'.format(
                    _kasc_escape(fs['op']))
            if fs.get('multi'):
                vals = [_kasc_escape(v) for v in fs.get('values') or []
                        if str(v) != '']
                if vals:
                    plugin_opts += ' | filter_values={0}'.format(
                        ','.join(vals))
            elif str(fs.get('value') or '') != '':
                plugin_opts += ' | filter_value={0}'.format(
                    _kasc_escape(fs['value']))
            kasc_lines.append(
                'plugin: custom-layer | name=レイヤ | '
                'url=canvas_data/custom-layer.js | before=layers-panel'
                + plugin_opts)

    cam = _camera_line(iface)
    bookmark_count = 0
    if emit_bookmarks:
        bookmark_count = _export_bookmarks_xml(
            os.path.join(out_dir, 'bookmarks.xml'))
    default_bases = [
        'base: 地理院タイル 標準地図 | '
        'https://cyberjapandata.gsi.go.jp/xyz/std/{z}/{x}/{y}.png | '
        '出典：国土地理院 | maxZoom=18',
        'base: 地理院タイル 淡色地図 | '
        'https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png | '
        '出典：国土地理院 | maxZoom=18 | minZoom=2 | bbox=122,19,155,47',
        'base: 地理院タイル 全国最新写真 | '
        'https://cyberjapandata.gsi.go.jp/xyz/seamlessphoto/{z}/{x}/{y}.jpg | '
        '出典：国土地理院 | maxZoom=18 | minZoom=2 | bbox=122,19,155,47',
        'base: OpenStreetMap | https://tile.openstreetmap.org/{z}/{x}/{y}.png | '
        '(c) OpenStreetMap contributors | maxZoom=19',
    ]
    # ベースマップグループ由来の base: は表示中のものを先に並べ、
    # 非表示は | off 付きで後ろへ(先頭が Canvas の既定ベースマップ)
    ordered_group_bases = [line for vis, line in group_bases if vis] + \
        [line for vis, line in group_bases if not vis]
    # QGIS 側で表示中の XYZ があれば既定ベースマップとして先頭に置く。
    # 表示中が無い(全候補 | off)場合は「ベースマップなし」モード行を
    # 出し、既定候補が勝手に選択されるのを防ぐ
    no_base = [] if (detected_base or
                     any(v for v, _l in group_bases)) \
        else ['base: ベースマップなし | none']
    bases = no_base + ([detected_base] if detected_base else []) + \
        ordered_group_bases + default_bases
    header = [
        '# Exported from QGIS geo_webview -> KASUGAI Canvas',
    ] + bases
    if cam:
        header.append(cam)
    # ライブ双方向連携: QGIS 内蔵HTTPサーバの /live/* 起点URL。
    # Canvas は同梱の live.json をポーリングし、/live/camera・
    # /live/selection へカメラ/選択を逆通知する(live_sync 有効時のみ)
    if live_url:
        header.append('live: {0}'.format(_kasc_escape(str(live_url))))
    # QGISブックマーク → bookmarks.xml + bookmark: 行。
    # Canvas 側が XML を読み込んでカメラプリセットへ展開する
    if bookmark_count:
        header.append('bookmark: bookmarks.xml')

    # Canvas 側の既定は折りたたみのため、展開状態は明示的に受け渡す
    for gname, gstate in group_states.items():
        _exp, _cs = (gstate if isinstance(gstate, tuple)
                     else (gstate, 'checked'))
        _gl = 'group: {0} | {1}'.format(
            _kasc_escape(gname), 'expanded' if _exp else 'collapsed')
        if _cs != 'checked':
            _gl += ' | checked={0}'.format(_cs)
        header.append(_gl)

    # 保存済み3Dビュー → cam:QGIS3D 行 + terrain: 行
    # + アニメーション → fly_geojson: 行(#60)
    try:
        header.extend(_threed_lines(project, warnings, data_dir,
                                    used_names))
    except Exception as e:
        warnings.append('3Dビュー出力失敗: {0}'.format(e))

    # theme: 行(QGIS マップテーマ → Canvas 可視性プリセット)。
    # 表示レイヤは .kasc のレイヤタイトル(groups/名 のパンくず)と一致させる
    if theme_names:
        try:
            collection = project.mapThemeCollection()
            title_by_id = {}
            for layer, groups, _vis, _tn in tree:
                if id(layer) in basemap_layer_ids:
                    continue  # base: 行へ回したレイヤはテーマ対象外
                title_by_id[layer.id()] = _kasc_layer_title(
                    groups, layer.name(), exclusive_groups)
            for name in theme_names:
                try:
                    visible_ids = set(
                        collection.mapThemeVisibleLayerIds(name))
                    # テーマ記録の名前付きスタイル → ;style= で引き継ぐ
                    # (MapThemeLayerRecord: layer()=メソッド、
                    #  usingCurrentStyle/currentStyle=属性。QGIS 4.0 実測)
                    style_by_id = {}
                    try:
                        rec = collection.mapThemeState(name)
                        for lr in rec.layerRecords():
                            lyr = lr.layer()
                            if lyr is None or not lr.usingCurrentStyle:
                                continue
                            sname = lr.currentStyle or ''
                            if sname:
                                style_by_id[lyr.id()] = sname
                    except Exception as e:
                        warnings.append(
                            'theme {0}: スタイル記録の取得失敗: {1}'.format(
                                name, e))
                    theme_slug = _slugify(name, used_names)
                    parts = []
                    for layer, _g, _v, _tn in tree:
                        if layer.id() not in visible_ids \
                                or id(layer) not in emitted_ids:
                            # .kasc に行を出していないレイヤ(非表示で
                            # 変換スキップ等)はテーマからも操作できない
                            continue
                        title = title_by_id.get(layer.id())
                        if not title:
                            continue
                        tok = title
                        sname = style_by_id.get(layer.id())
                        if sname:
                            rel = _theme_style_qml(
                                layer, sname, data_dir,
                                slug_by_id.get(layer.id()),
                                theme_slug, warnings,
                                used_names, copied)
                            if rel:
                                tok = '{0};style={1}'.format(tok, rel)
                        parts.append(tok)
                    kasc_lines.append('theme: {0}{1}'.format(
                        _kasc_escape(name),
                        ''.join(' | ' + t for t in parts)))
                except Exception as e:
                    warnings.append('theme {0}: {1}'.format(name, e))
        except Exception as e:
            warnings.append('theme 行出力失敗: {0}'.format(e))

    # アトラス有効な印刷レイアウト → fly_geojson: 行。
    # 各ページ範囲を巡回するプレゼン用フライパス(座標Z=ページを収める高さ)
    atlases = []
    if emit_atlas:
        try:
            fly_lines, atlases = _export_atlas_fly(
                project, data_dir, used_names, warnings)
            kasc_lines.extend(fly_lines)
        except Exception as e:
            warnings.append('atlas 行出力失敗: {0}'.format(e))

    kasc_path = os.path.join(out_dir, 'kasugai_canvas.kasc')
    with open(kasc_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(header + kasc_lines) + '\n')
    with open(os.path.join(out_dir, 'project.json'), 'w',
              encoding='utf-8') as f:
        json.dump({'title': project_title}, f, ensure_ascii=False)

    # ライブ連携マニフェスト。Canvas は .kasc と同じ場所のこのファイルを
    # ポーリングし、rev 増加で .kasc/変更データを再取得する
    if live_url:
        try:
            from datetime import datetime as _dt
            with open(os.path.join(out_dir, 'live.json'), 'w',
                      encoding='utf-8') as f:
                json.dump({
                    'ok': True,
                    'rev': int(time.time() * 1000),
                    'updated': _dt.now().isoformat(timespec='seconds'),
                    'changed': live_changed,
                }, f, ensure_ascii=False)
        except Exception as e:
            warnings.append('live.json 出力失敗: {0}'.format(e))

    launchers = []
    if emit_launchers:
        try:
            launchers = _write_engine_launchers(
                out_dir, os.path.basename(kasc_path))
        except Exception as e:
            warnings.append('engine launcher html 生成失敗: {0}'.format(e))

    zip_path = None
    if emit_zip:
        try:
            zip_path = _write_export_zip(out_dir)
        except Exception as e:
            warnings.append('zip 生成失敗: {0}'.format(e))

    return {
        'dir': out_dir, 'kasc': kasc_path, 'data_dir': data_dir,
        'title': project_title, 'layers': layers_out,
        'tiles': tiles_out, 'skipped': skipped, 'errors': errors,
        'warnings': warnings, 'themes': theme_names,
        'bookmarks': bookmark_count, 'launchers': launchers,
        'zip': zip_path, 'atlases': atlases,
        'vector_format': vector_format,
    }


def _iter_export_files(root):
    """out_dir 配下の ZIP 格納対象を (実パス, zip内相対パス) で列挙する。

    ルートの kasugai_canvas*.zip 自身は除外する。
    """
    for r, _dirs, names in os.walk(root):
        for name in names:
            if os.path.abspath(r) == os.path.abspath(root) \
                    and _is_export_zip_name(name):
                continue
            full = os.path.join(r, name)
            arc = os.path.relpath(full, root).replace(os.sep, '/')
            yield full, arc


def _write_export_zip(out_dir):
    """出力フォルダ一式を kasugai_canvas_<tag>.zip として固める。

    ファイル名は CDN チャンネルを反映(export_zip_name)。
    展開時にルートへ .kasc+canvas_data/ が並ぶよう out_dir 相対パスで格納する
    (zip 自身は除外)。Re:Earth geo_suite の ``qgis:`` 取り込みは
    ZIP 内の .kasc を最短パス優先で検出するため、この配置で正しく解決する。
    """
    import zipfile
    zip_path = os.path.join(out_dir, export_zip_name())
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for full, arc in _iter_export_files(out_dir):
            zf.write(full, arc)
    return zip_path


def build_export_zip(out_dir=None):
    """エクスポート物一式を kasugai_canvas_<tag>.zip 相当の bytes で返す。

    /export-data/kasugai_canvas*.zip のオンデマンド生成用。
    ファイルは残さずメモリ上で固めて返すだけなので、内容は常に
    直近エクスポートの最新状態になる。
    """
    import io
    import zipfile
    root = os.path.abspath(out_dir or last_export_dir())
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for full, arc in _iter_export_files(root):
            zf.write(full, arc)
    return buf.getvalue()


def _http_json(url, payload=None, timeout=2.0, method=None):
    """小さなJSON HTTP呼び出し。payload無しはGET。"""
    if urllib.parse.urlparse(url).scheme not in ('http', 'https'):
        raise ValueError('unsupported URL scheme: {0}'.format(url))
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method=method)
    with urllib.request.urlopen(req, timeout=timeout) as res:  # nosec B310  # 直上でhttp/httpsスキームを検証済み
        body = res.read(65536)
    return json.loads(body.decode('utf-8'))


def detect_kasugai(port=None):
    """KASUGAIローカルサーバが稼働していればcapabilitiesを返す。"""
    port = int(port or get_kasugai_port())
    try:
        caps = _http_json(
            'http://127.0.0.1:{0}/api/capabilities'.format(port),
            timeout=1.5)
        if isinstance(caps, dict):
            caps['_port'] = port
            return caps
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return None


def build_kasugai_url(project_id, engine=None, port=None):
    """KASUGAI Canvas のプロジェクトURLを構築する。

    engine 指定時は ``/<engine>/?project=<id>`` 形式
    (cesium/maplibre/openlayers/leaflet/gsimaps/navara の実パスを直接指す。
    web/index.html の ?engine= リダイレクトに依存しないため、
    旧バージョンの Canvas でも確実にそのエンジンが開く)。
    engine=None/無効値は既定(cesium)の ``/?project=<id>``。
    """
    port = int(port or get_kasugai_port())
    base = 'http://127.0.0.1:{0}'.format(port)
    e = normalize_engine(engine)
    if e:
        base += '/{0}/'.format(e)
    return '{0}?project={1}'.format(
        base, urllib.parse.quote(str(project_id)))


def register_kasugai_project(kasc_path, port=None, engine=None):
    """POST /api/projects/register で.kascを外部プロジェクト登録する。

    戻り値: {"ok":True,"id":...,"url":...} または {"ok":False,"error":...}
    engine 指定時は url が /<engine>/?project=<id> 形式になる。
    """
    port = int(port or get_kasugai_port())
    try:
        res = _http_json(
            'http://127.0.0.1:{0}/api/projects/register'.format(port),
            payload={'path': os.path.abspath(kasc_path)}, timeout=4.0)
        pid = res.get('id')
        if res.get('ok') and pid:
            return {'ok': True, 'id': pid,
                    'url': build_kasugai_url(pid, engine, port)}
        return {'ok': False, 'error': str(res)}
    except Exception as e:
        return {'ok': False, 'error': str(e)}


def kasugai_command(name, args=None, port=None):
    """POST /api/command でチャットツールをキューイング(ベストエフォート)。"""
    port = int(port or get_kasugai_port())
    try:
        res = _http_json(
            'http://127.0.0.1:{0}/api/command'.format(port),
            payload={'name': name, 'args': args or {}}, timeout=4.0)
        return {'ok': bool(res.get('ok')), 'response': res}
    except Exception as e:
        return {'ok': False, 'error': str(e)}


def find_kasugai_exe():
    """起動可能な kasugai_canvas.exe のパスを返す（見つからなければ None）。

    detect_kasugai_install_dir()（設定→レジストリ）で特定した
    インストール先の ``<dir>/`` と ``<dir>/server/`` を見る。
    """
    install = detect_kasugai_install_dir()
    if not install:
        return None
    for cand in (os.path.join(install, KASUGAI_EXE_NAME),
                 os.path.join(install, 'server', KASUGAI_EXE_NAME)):
        if os.path.isfile(cand):
            return cand
    return None


def find_kasugai_web_dir():
    """インストール済み KASUGAI Canvas の配信用 ``web/`` ディレクトリを返す。

    Canvas サーバ(8510)未起動時に、geo_webview の HTTP サーバが
    エンジンHTMLを代わりに配信するフォールバックで使う。
    exe と同階層の ``web/`` を優先し、``<install>/web`` と
    ``<install>/server/web`` も見る。``web/index.html`` が存在する
    場合のみ絶対パスを返す（見つからなければ None）。
    """
    try:
        explicit = local_channel_web_dir()
    except Exception:  # nosec B110  # 判定失敗は自動検出へ
        explicit = None
    if explicit:
        return explicit
    cands = []
    exe = find_kasugai_exe()
    if exe:
        cands.append(os.path.join(os.path.dirname(exe), 'web'))
    install = detect_kasugai_install_dir()
    if install:
        cands.append(os.path.join(install, 'web'))
        cands.append(os.path.join(install, 'server', 'web'))
    for cand in cands:
        if os.path.isfile(os.path.join(cand, 'index.html')):
            return os.path.abspath(cand)
    return None


def find_kasugai_engine_dir(engine=None):
    """インストール済みCanvas web/ 内の ``<engine>/`` ディレクトリを返す。

    マルチエンジン構成(web/cesium/等)のインストールのみ有効。
    旧単一エンジン構成(web/直下にapp.js)や engine ディレクトリが無い
    場合は None(?kasc= 再生不可のため hosted フォールバックへ回す)。
    """
    web = find_kasugai_web_dir()
    if not web:
        return None
    e = normalize_engine(engine) or DEFAULT_ENGINE
    d = os.path.join(web, e)
    if os.path.isfile(os.path.join(d, 'index.html')):
        return os.path.abspath(d)
    return None


def build_local_view_url(kasc_path, engine=None, port=None):
    """geo_webview の HTTP サーバ経由で .kasc を開くURLを組み立てる。

    Canvas サーバ(8510)未起動時のフォールバック用。
    ``http://localhost:<port>/<engine>/?kasc=<export-data配下URL>``。
    サーバ側でインストール済みCanvasの web/ 配信(エンドポイントに
    一致しなかったパスの静的解決)が有効なことが前提。
    kasc_path が last_export_dir() 配下に無い場合は None。
    """
    if not port:
        return None
    try:
        rel = os.path.relpath(kasc_path, last_export_dir())
    except ValueError:
        return None
    rel = rel.replace('\\', '/')
    if rel.startswith('..'):
        return None
    kasc_url = 'http://127.0.0.1:{0}/export-data/{1}'.format(
        int(port), urllib.parse.quote(rel))
    e = normalize_engine(engine) or DEFAULT_ENGINE
    return 'http://127.0.0.1:{0}/{1}/?kasc={2}'.format(
        int(port), e, urllib.parse.quote(kasc_url, safe=''))


def launch_kasugai(kasc_path=None, open_browser=False):
    """kasugai_canvas.exe を起動する。起動要求に成功すれば True。

    open_browser=False(既定)では ``--no-browser`` でサーバーのみ起動し、
    ブラウザは呼び出し側がエンジン付きURLで開く。open_browser=True または
    .kasc パス指定でのみ exe 既定挙動(ブラウザ自動起動)を利用する。
    """
    exe = find_kasugai_exe()
    if not exe:
        return False
    args = [exe]
    if not open_browser:
        args.append('--no-browser')
    if kasc_path:
        args.append(os.path.abspath(kasc_path))
    try:
        subprocess.Popen(  # nosec B603  # 固定exe・シェル非経由
            args, cwd=os.path.dirname(exe))
        return True
    except Exception as e:
        print(f'⚠️ KASUGAI launch failed: {e}')
        return False


def wait_for_kasugai(timeout=12.0, interval=0.3, pump_events=True):
    """起動直後のローカルサーバ応答を待つ。応答があれば capabilities。

    pump_events=True のとき待機中に Qt イベントを回して UI を固めない
    （GUI スレッドからの呼び出し用）。HTTP ハンドラ等の別スレッドでは
    False を指定すること。
    """
    deadline = time.time() + timeout
    while True:
        caps = detect_kasugai()
        if caps or time.time() >= deadline:
            return caps
        if pump_events:
            try:
                from qgis.PyQt.QtWidgets import QApplication
                app = QApplication.instance()
                if app is not None:
                    app.processEvents()
            except Exception:  # nosec B110  # 設計上の許容
                pass
        time.sleep(interval)


def open_kasc_with_association(kasc_path):
    """.kasc ファイル関連付け経由で Canvas 起動を要求する（Windows）。

    インストーラが ``.kasc → kasugai_canvas.exe --open-browser %1`` を
    登録済みなら起動できる。この経路は既定エンジンでブラウザが開く。
    起動要求ができれば True（起動完了は保証しない）。
    """
    if not kasc_path or not hasattr(os, 'startfile'):
        return False
    try:
        os.startfile(os.path.abspath(kasc_path))  # nosec B606
        return True
    except OSError:
        return False


def ensure_kasugai_running(kasc_path=None, timeout=12.0,
                           pump_events=True):
    """KASUGAI Canvas ローカルサーバを使える状態にして capabilities を返す。

    1. 既に稼働中 → そのまま返す
    2. インストール済み exe を発見 → ``--no-browser`` で起動して待機
       （ブラウザは呼び出し側がエンジン付きURLで開く）
    3. exe 不明・未インストール → kasc_path をファイル関連付けで開いて待機
       （この経路は既定エンジンのブラウザが exe 側で開かれる）

    戻り値は ``(capabilities or None, opened_default_browser)``。
    第2戻り値が True のとき、関連付け起動により既定エンジンのタブが
    既に開かれている可能性が高い（二重オープン防止に利用）。
    """
    caps = detect_kasugai()
    if caps:
        return caps, False
    if launch_kasugai():
        caps = wait_for_kasugai(
            timeout=timeout, pump_events=pump_events)
        if caps:
            return caps, False
    if open_kasc_with_association(kasc_path):
        caps = wait_for_kasugai(
            timeout=timeout, pump_events=pump_events)
        return caps, True
    return None, False


# ---- 自動インストール（配布ZIPのダウンロード・展開） ----

# 公開チャンネル(main)の配布物を参照する
KASUGAI_LATEST_JSON_URL = (
    'https://raw.githubusercontent.com/yamamoto-ryuzo/kasugai_canvas'
    '/main/download/latest.json')
KASUGAI_ZIP_FALLBACK_URL = (
    'https://raw.githubusercontent.com/yamamoto-ryuzo/kasugai_canvas'
    '/main/download/kasugai_canvas.zip')


def kasugai_download_url():
    """latest.json から配布ZIPのURLを返す（取得失敗時は既定URL）。"""
    try:
        meta = _http_json(KASUGAI_LATEST_JSON_URL, timeout=5.0)
        url = ((meta.get('platforms') or {})
               .get('windows-x86_64') or {}).get('url')
        if url and str(url).startswith('https://'):
            return url
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return KASUGAI_ZIP_FALLBACK_URL


def default_install_dir():
    r"""既定インストール先。インストーラ既定の C:\kasugai\kasugai_canvas
    を優先し、作成できなければ %LOCALAPPDATA%\kasugai_canvas。"""
    if os.name == 'nt':
        cand = r'C:\kasugai\kasugai_canvas'
        try:
            os.makedirs(cand, exist_ok=True)
            return cand
        except OSError:
            pass
    import tempfile
    base = os.environ.get('LOCALAPPDATA') or tempfile.gettempdir()
    return os.path.join(base, 'kasugai_canvas')


def _safe_extractall(zf, dest_dir):
    """zip-slip 対策付き extractall。"""
    dest = os.path.abspath(dest_dir)
    for member in zf.namelist():
        target = os.path.abspath(os.path.join(dest, member))
        if not (target == dest or target.startswith(dest + os.sep)):
            raise RuntimeError('unsafe path in archive: {0}'.format(member))
    zf.extractall(dest)


def _download(url, tmp, progress_cb=None, cancel=None):
    """url を tmp へダウンロードする。

    progress_cb(stage, done, total) が渡されていれば
    ('download', 済みバイト, 総バイト) で進捗を逐次通知する
    (総バイト不明時は total=0)。cancel['cancelled'] が真なら中断する。
    """
    if urllib.parse.urlparse(url).scheme != 'https':
        raise ValueError('download URL must be https: {0}'.format(url))
    req = urllib.request.Request(
        url, headers={'User-Agent': 'geo_webview'})
    with (urllib.request.urlopen(req, timeout=300) as res,  # nosec B310  # 直上でhttpsスキームを検証済み
            open(tmp, 'wb') as out):
        try:
            total = int(res.headers.get('Content-Length') or 0)
        except Exception:  # nosec B110  # 設計上の許容
            total = 0
        done = 0
        while True:
            if cancel and cancel.get('cancelled'):
                raise RuntimeError('install cancelled by user')
            chunk = res.read(1 << 18)
            if not chunk:
                break
            out.write(chunk)
            done += len(chunk)
            if progress_cb:
                progress_cb('download', done, total)


def install_kasugai(dest_dir=None, progress_cb=None, cancel=None):
    """KASUGAI Canvas の配布ZIPをダウンロード・展開してインストール先を返す。

    dest_dir 既定は default_install_dir()。成功時は
    ``kasugai_install_path`` 設定へ自動登録する。
    progress_cb(stage, done, total) で進捗通知
    ('download'/'extract')。
    失敗時は例外を送出（呼び出し側でキャッチして通知する）。
    ブロッキングするため GUI スレッドではタスク経由で呼ぶこと。
    """
    import tempfile
    import zipfile
    dest_dir = os.path.abspath(dest_dir or default_install_dir())
    url = kasugai_download_url()
    fd, tmp = tempfile.mkstemp(suffix='.zip', prefix='kasugai_canvas_')
    os.close(fd)
    try:
        _download(url, tmp, progress_cb, cancel)
        if cancel and cancel.get('cancelled'):
            raise RuntimeError('install cancelled by user')
        if progress_cb:
            progress_cb('extract', 0, 0)
        os.makedirs(dest_dir, exist_ok=True)
        with zipfile.ZipFile(tmp) as zf:
            _safe_extractall(zf, dest_dir)
    finally:
        try:
            os.remove(tmp)
        except OSError:  # nosec B110  # 設計上の許容
            pass
    exe = os.path.join(dest_dir, KASUGAI_EXE_NAME)
    if not os.path.isfile(exe):
        raise RuntimeError(
            'kasugai_canvas.exe not found in downloaded archive')
    try:
        _qsettings().setValue('kasugai_install_path', dest_dir)
    except Exception:  # nosec B110  # 設計上の許容
        pass
    return dest_dir


KASUGAI_SETUP_FALLBACK_URL = (
    'https://raw.githubusercontent.com/yamamoto-ryuzo/kasugai_canvas'
    '/main/download/kasugai_canvas_setup.exe')


def kasugai_setup_url():
    """配布セットアップ(NSIS EXE)のURLを返す。

    ZIPと同じ配布ディレクトリの kasugai_canvas_setup.exe を指す
    (latest.json はZIPのみ公開するため basename 置換で求める)。
    """
    base = kasugai_download_url().split('?')[0].rsplit('/', 1)[0]
    if base.startswith(('https://', 'http://')):
        return base + '/kasugai_canvas_setup.exe'
    return KASUGAI_SETUP_FALLBACK_URL


def install_kasugai_setup(wait=True, progress_cb=None, cancel=None):
    """NSIS セットアップをダウンロード・実行する通常インストール経路。

    ポータブルZIP展開(install_kasugai)と違い、.kasc ファイル関連付け・
    スタートメニュー/アンインストーラ登録・InstallLocation レジストリ
    登録が行われる。NSIS ウィザードを対話表示し、wait=True で
    インストーラ終了まで待機する(ブロッキングのため GUI スレッドでは
    タスク経由で呼ぶこと)。終了後は InstallLocation レジストリから
    実インストール先を検出し kasugai_install_path へ登録する。
    progress_cb(stage, done, total) で進捗通知
    ('download'/'wizard')。cancel['cancelled'] が真なら
    DL中は中断、ウィザード待機中はプロセスを終了して中断する。
    ユーザがウィザードをキャンセルした場合は exe 不在で例外となる。
    """
    import tempfile
    import time
    url = kasugai_setup_url()
    fd, tmp = tempfile.mkstemp(
        suffix='.exe', prefix='kasugai_canvas_setup_')
    os.close(fd)
    try:
        _download(url, tmp, progress_cb, cancel)
        if progress_cb:
            progress_cb('wizard', 0, 0)
        proc = subprocess.Popen([tmp])  # nosec B603  # 自前配布物のみ
        if wait:
            # ×キャンセル時にウィザードプロセスを終了して抜ける
            while proc.poll() is None:
                if cancel and cancel.get('cancelled'):
                    try:
                        proc.kill()
                    except OSError:  # nosec B110  # 設計上の許容
                        pass
                    raise RuntimeError('install cancelled by user')
                time.sleep(0.5)
        dest = _registry_install_dir() or default_install_dir()
        exe = os.path.join(dest, KASUGAI_EXE_NAME)
        if not os.path.isfile(exe):
            raise RuntimeError(
                'setup wizard finished but {0} was not found — '
                'installation cancelled or the wizard was blocked'.format(
                    KASUGAI_EXE_NAME))
        try:
            _qsettings().setValue('kasugai_install_path', dest)
        except Exception:  # nosec B110  # 設計上の許容
            pass
        return dest
    finally:
        try:
            os.remove(tmp)
        except OSError:  # nosec B110  # 設計上の許容
            pass
